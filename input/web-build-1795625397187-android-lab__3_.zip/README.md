# Android Lab 2.0

A futuristic native Android developer studio built from scratch with **Kotlin**, **Jetpack Compose**, **Material 3**, **Room**, **DataStore**, **Android Keystore**, and the **official Gemini REST API**.

## Architecture

- **Pattern:** MVVM + Clean Repository Architecture
- **UI:** 100% Jetpack Compose with Material 3, adaptive `NavigationBar` / `NavigationRail`, custom bundled fonts (`Space Grotesk`, `Plus Jakarta Sans`, `JetBrains Mono`), and Deep Navy / Violet / Electric Blue glassmorphic theming (Dark, Light, System).
- **Local Persistence:**
  - **Room Database (`AndroidLabDatabase`):** Stores projects, multi-file source trees, AI Studio conversations & messages, custom prompt presets, project activity history, and diagnostic logs.
  - **DataStore Preferences:** Persists theme mode, language (`en`, `es`, `fr`, `de`), model selection, privacy guardrails, and encrypted Gemini API credentials.
- **Security:**
  - User-configured Gemini API keys are encrypted locally using **Android Keystore (`AES/GCM/NoPadding`, 256-bit)**.
  - Optional prompt & attachment secret redaction prevents accidental exposure of `AIza...` / `sk-...` / `Bearer` tokens.
  - Zero broad storage permissions: file import/export uses Android Storage Access Framework (`OpenDocument` / `CreateDocument`).

## Core Modules

1. **Home Dashboard:** Android Lab 2.0 branding, hero banner, quick project creation, AI Studio shortcuts, live Room statistics, recent projects, activity feed, and real system status.
2. **Projects Workspace:** Create from 4 multi-file templates, rename, edit metadata, inspect revision history, delete with confirmation, and import/export JSON bundles or individual source files.
3. **AI Studio:** 10 specialized Gemini modes (Assistant, App Gen, Kotlin Gen, Compose UI, XML Gen, Code Explanation, Bug Analysis, Error Debugging, Code Review, Architecture), model switching, active file context attachment, fenced code block extraction & save-to-project, prompt library, conversation history, and live connection testing.
4. **Developer Toolkit:** Project file browser, Kotlin/XML/JSON editors with syntax highlighting, JSON formatter/minifier, `XmlPullParser` well-formedness validation, snippet injector, live log viewer, and an honest static syntax/structure analyzer with clickable Error Viewer.
5. **Settings:** Theme mode, localization, Keystore-encrypted Gemini API setup & latency test, cache/history management, privacy toggles, app/version metadata, and changelog.

> **Note on Compilation:** Android Lab 2.0 performs genuine on-device static syntax, XML (`XmlPullParser`), JSON (`JSONTokener`), and manifest checks. It does not claim to compile APKs locally on-device.

## Installation Instructions

1. Open the project root in **Android Studio** (Ladybug or newer, AGP 9.x, JDK 17+).
2. Ensure Android SDK Platform **36** and Build-Tools are installed (`minSdk = 26`, Android 8.0+).
3. Sync Gradle and run the `app` configuration on an emulator or physical device, or build a debug APK via:
   ```bash
   gradle :app:assembleDebug
   ```
4. Launch **Android Lab**, open **Settings → Gemini API & Keystore**, enter your Gemini API key, and tap **Encrypt & Save** followed by **Test**.
