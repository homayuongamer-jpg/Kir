# Changelog — Android Lab 2.0 (Build 200)

## v2.0.0
- **Brand New Architecture:** Built cleanly from zero using Kotlin, Jetpack Compose, Material 3, Navigation Compose, Room, DataStore, Retrofit, and Moshi.
- **Futuristic Studio Design System:** Deep navy backdrop, purple/violet/electric-blue gradients, glassmorphic cards, animated splash screen, custom adaptive launcher icon, and Dark/Light/System themes.
- **Custom Typography:** Bundled `Space Grotesk`, `Plus Jakarta Sans`, and `JetBrains Mono` locally in `res/font/`.
- **Gemini AI Studio:** Added 10 specialized engineering modes, live Gemini v1beta REST API integration, token/latency telemetry, prompt library, conversation history, active file context attachment, and direct code-block saving into projects.
- **Android Keystore Security:** Added `KeystoreCryptoManager` (`AES/GCM/NoPadding`) for encrypting user-provided Gemini API keys plus connection testing and error diagnostics.
- **Project Workspace Manager:** Added multi-file templates, metadata editing, revision history, confirmation-guarded deletion, and SAF JSON bundle import/export.
- **Developer Toolkit:** Added File Browser, Kotlin/XML/JSON Editors, JSON formatter/minifier, `XmlPullParser` XML validator, Snippet Library, Diagnostic Log Viewer, and Static Analyzer / Error Viewer.
- **Localization & Settings:** Added English, Spanish, French, and German localization plus cache management and privacy guardrails.
