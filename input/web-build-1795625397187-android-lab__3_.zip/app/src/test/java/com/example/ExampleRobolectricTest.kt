package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.analyzer.ProjectStaticAnalyzer
import com.example.data.local.ProjectFileEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `app name matches Android Lab`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Android Lab", appName)
  }

  @Test
  fun `xml pull parser detects malformed xml`() {
    val badXml =
      ProjectFileEntity(
        id = 1L,
        projectId = 1L,
        name = "layout.xml",
        relativePath = "layout.xml",
        fileType = "xml",
        content = "<LinearLayout><TextView></LinearLayout>",
      )
    val issues = ProjectStaticAnalyzer.analyzeXml(badXml)
    assertTrue(issues.isNotEmpty())
  }
}
