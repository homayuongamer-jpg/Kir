package com.example

import com.example.core.analyzer.IssueSeverity
import com.example.core.analyzer.ProjectStaticAnalyzer
import com.example.core.templates.ExportedFileDto
import com.example.core.templates.ExportedProjectBundle
import com.example.core.templates.ProjectBundleSerializer
import com.example.data.local.ProjectFileEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun staticAnalyzer_detectsUnclosedBrace() {
    val files =
      listOf(
        ProjectFileEntity(
          id = 1L,
          projectId = 1L,
          name = "Broken.kt",
          relativePath = "Broken.kt",
          fileType = "kotlin",
          content = "package com.example\nclass Broken {\n",
        ),
        ProjectFileEntity(
          id = 2L,
          projectId = 1L,
          name = "AndroidManifest.xml",
          relativePath = "AndroidManifest.xml",
          fileType = "xml",
          content = "<manifest/>",
        ),
      )
    val report = ProjectStaticAnalyzer.analyzeProject("TestProj", files)
    assertEquals(1, report.errorCount)
    assertTrue(report.issues.any { it.severity == IssueSeverity.ERROR && it.ruleId == "KT_BRACE_UNCLOSED" })
  }

  @Test
  fun staticAnalyzer_detectsMalformedXmlFallback() {
    val badXml =
      ProjectFileEntity(
        id = 1L,
        projectId = 1L,
        name = "layout.xml",
        relativePath = "layout.xml",
        fileType = "xml",
        content = "<LinearLayout><TextView></LinearLayout>",
      )
    val issues = ProjectStaticAnalyzer.analyzeXml(badXml)
    assertTrue(issues.any { it.severity == IssueSeverity.ERROR && it.ruleId == "XML_SYNTAX" })
  }

  @Test
  fun bundleSerializer_roundTripsProjectBundle() {
    val bundle =
      ExportedProjectBundle(
        name = "StudioDemo",
        packageName = "com.androidlab.demo",
        description = "Demo",
        templateType = "compose_m3",
        minSdk = 26,
        versionName = "1.0",
        exportedAtMs = 123456L,
        files =
          listOf(
            ExportedFileDto(
              name = "MainActivity.kt",
              relativePath = "MainActivity.kt",
              fileType = "kotlin",
              content = "package com.androidlab.demo",
            )
          ),
      )
    val encoded = ProjectBundleSerializer.encode(bundle)
    val decoded = ProjectBundleSerializer.decode(encoded).getOrThrow()
    assertEquals("StudioDemo", decoded.name)
    assertEquals(1, decoded.files.size)
  }
}
