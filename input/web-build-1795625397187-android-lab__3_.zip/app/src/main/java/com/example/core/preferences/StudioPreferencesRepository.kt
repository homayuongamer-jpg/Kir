package com.example.core.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.core.security.KeystoreCryptoManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.studioDataStore: DataStore<Preferences> by
  preferencesDataStore(name = "android_lab_studio_prefs")

enum class ThemeMode(val label: String) {
  DARK("Dark"),
  LIGHT("Light"),
  SYSTEM("System"),
}

enum class AppLanguage(val code: String, val displayName: String) {
  ENGLISH("en", "English"),
  SPANISH("es", "Español"),
  FRENCH("fr", "Français"),
  GERMAN("de", "Deutsch"),
}

enum class GeminiModelOption(
  val modelId: String,
  val displayName: String,
  val tierNote: String,
) {
  GEMINI_2_5_FLASH(
    modelId = "gemini-2.5-flash",
    displayName = "Gemini 2.5 Flash",
    tierNote = "Fast & balanced for code generation and debugging",
  ),
  GEMINI_2_5_PRO(
    modelId = "gemini-2.5-pro",
    displayName = "Gemini 2.5 Pro",
    tierNote = "Deep architectural reasoning and complex code review",
  ),
  GEMINI_2_0_FLASH(
    modelId = "gemini-2.0-flash",
    displayName = "Gemini 2.0 Flash",
    tierNote = "Low-latency companion model",
  ),
}

enum class ApiConnectionState {
  NOT_CONFIGURED,
  CONFIGURED_UNTESTED,
  VERIFIED,
  ERROR,
}

data class StudioPreferences(
  val themeMode: ThemeMode = ThemeMode.DARK,
  val language: AppLanguage = AppLanguage.ENGLISH,
  val selectedModel: GeminiModelOption = GeminiModelOption.GEMINI_2_5_FLASH,
  val hasGeminiKey: Boolean = false,
  val maskedGeminiKey: String = "",
  val apiConnectionState: ApiConnectionState = ApiConnectionState.NOT_CONFIGURED,
  val lastConnectionMessage: String = "",
  val lastLatencyMs: Long = 0L,
  val activeProjectId: Long = 1L,
  val attachActiveFileContext: Boolean = true,
  val redactSecretsBeforeSend: Boolean = true,
  val logAiMetadataLocally: Boolean = true,
)

class StudioPreferencesRepository(
  private val context: Context,
  private val cryptoManager: KeystoreCryptoManager,
) {
  private object Keys {
    val THEME_MODE = stringPreferencesKey("theme_mode")
    val LANGUAGE_CODE = stringPreferencesKey("language_code")
    val SELECTED_MODEL = stringPreferencesKey("selected_model")
    val ENCRYPTED_GEMINI_KEY = stringPreferencesKey("encrypted_gemini_key")
    val MASKED_GEMINI_KEY = stringPreferencesKey("masked_gemini_key")
    val API_CONNECTION_STATE = stringPreferencesKey("api_connection_state")
    val LAST_CONNECTION_MESSAGE = stringPreferencesKey("last_connection_message")
    val LAST_LATENCY_MS = longPreferencesKey("last_latency_ms")
    val ACTIVE_PROJECT_ID = longPreferencesKey("active_project_id")
    val ATTACH_ACTIVE_FILE_CONTEXT = booleanPreferencesKey("attach_active_file_context")
    val REDACT_SECRETS = booleanPreferencesKey("redact_secrets")
    val LOG_AI_METADATA = booleanPreferencesKey("log_ai_metadata")
  }

  val preferencesFlow: Flow<StudioPreferences> =
    context.studioDataStore.data.map { prefs ->
      val theme =
        prefs[Keys.THEME_MODE]?.let { name -> ThemeMode.entries.find { it.name == name } }
          ?: ThemeMode.DARK
      val language =
        prefs[Keys.LANGUAGE_CODE]?.let { code -> AppLanguage.entries.find { it.code == code } }
          ?: AppLanguage.ENGLISH
      val model =
        prefs[Keys.SELECTED_MODEL]?.let { id ->
          GeminiModelOption.entries.find { it.modelId == id }
        } ?: GeminiModelOption.GEMINI_2_5_FLASH
      val encryptedKey = prefs[Keys.ENCRYPTED_GEMINI_KEY].orEmpty()
      val hasKey = encryptedKey.isNotBlank()
      val connState =
        if (!hasKey) {
          ApiConnectionState.NOT_CONFIGURED
        } else {
          prefs[Keys.API_CONNECTION_STATE]?.let { s ->
            ApiConnectionState.entries.find { it.name == s }
          } ?: ApiConnectionState.CONFIGURED_UNTESTED
        }

      StudioPreferences(
        themeMode = theme,
        language = language,
        selectedModel = model,
        hasGeminiKey = hasKey,
        maskedGeminiKey = prefs[Keys.MASKED_GEMINI_KEY].orEmpty(),
        apiConnectionState = connState,
        lastConnectionMessage = prefs[Keys.LAST_CONNECTION_MESSAGE].orEmpty(),
        lastLatencyMs = prefs[Keys.LAST_LATENCY_MS] ?: 0L,
        activeProjectId = prefs[Keys.ACTIVE_PROJECT_ID] ?: 1L,
        attachActiveFileContext = prefs[Keys.ATTACH_ACTIVE_FILE_CONTEXT] ?: true,
        redactSecretsBeforeSend = prefs[Keys.REDACT_SECRETS] ?: true,
        logAiMetadataLocally = prefs[Keys.LOG_AI_METADATA] ?: true,
      )
    }

  suspend fun setThemeMode(mode: ThemeMode) {
    context.studioDataStore.edit { it[Keys.THEME_MODE] = mode.name }
  }

  suspend fun setLanguage(language: AppLanguage) {
    context.studioDataStore.edit { it[Keys.LANGUAGE_CODE] = language.code }
  }

  suspend fun setSelectedModel(model: GeminiModelOption) {
    context.studioDataStore.edit { it[Keys.SELECTED_MODEL] = model.modelId }
  }

  suspend fun setActiveProjectId(projectId: Long) {
    context.studioDataStore.edit { it[Keys.ACTIVE_PROJECT_ID] = projectId }
  }

  suspend fun setAttachActiveFileContext(enabled: Boolean) {
    context.studioDataStore.edit { it[Keys.ATTACH_ACTIVE_FILE_CONTEXT] = enabled }
  }

  suspend fun setRedactSecretsBeforeSend(enabled: Boolean) {
    context.studioDataStore.edit { it[Keys.REDACT_SECRETS] = enabled }
  }

  suspend fun setLogAiMetadataLocally(enabled: Boolean) {
    context.studioDataStore.edit { it[Keys.LOG_AI_METADATA] = enabled }
  }

  suspend fun saveGeminiApiKey(rawKey: String): Result<String> {
    val trimmed = rawKey.trim()
    if (trimmed.isEmpty()) {
      return Result.failure(IllegalArgumentException("API key cannot be empty."))
    }
    val encryptedResult = cryptoManager.encrypt(trimmed)
    return encryptedResult.map { cipherText ->
      val masked = cryptoManager.maskKey(trimmed)
      context.studioDataStore.edit { prefs ->
        prefs[Keys.ENCRYPTED_GEMINI_KEY] = cipherText
        prefs[Keys.MASKED_GEMINI_KEY] = masked
        prefs[Keys.API_CONNECTION_STATE] = ApiConnectionState.CONFIGURED_UNTESTED.name
        prefs[Keys.LAST_CONNECTION_MESSAGE] = "Key encrypted in Android Keystore. Ready to test."
        prefs[Keys.LAST_LATENCY_MS] = 0L
      }
      masked
    }
  }

  suspend fun getDecryptedGeminiApiKey(): String? {
    val prefs = context.studioDataStore.data.first()
    val encrypted = prefs[Keys.ENCRYPTED_GEMINI_KEY] ?: return null
    if (encrypted.isBlank()) return null
    return cryptoManager.decrypt(encrypted).getOrNull()
  }

  suspend fun clearGeminiApiKey() {
    context.studioDataStore.edit { prefs ->
      prefs.remove(Keys.ENCRYPTED_GEMINI_KEY)
      prefs.remove(Keys.MASKED_GEMINI_KEY)
      prefs[Keys.API_CONNECTION_STATE] = ApiConnectionState.NOT_CONFIGURED.name
      prefs[Keys.LAST_CONNECTION_MESSAGE] = "No Gemini API key configured."
      prefs[Keys.LAST_LATENCY_MS] = 0L
    }
  }

  suspend fun updateConnectionStatus(
    state: ApiConnectionState,
    message: String,
    latencyMs: Long = 0L,
  ) {
    context.studioDataStore.edit { prefs ->
      prefs[Keys.API_CONNECTION_STATE] = state.name
      prefs[Keys.LAST_CONNECTION_MESSAGE] = message
      prefs[Keys.LAST_LATENCY_MS] = latencyMs
    }
  }
}
