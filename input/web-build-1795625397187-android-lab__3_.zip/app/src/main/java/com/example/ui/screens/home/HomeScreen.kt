package com.example.ui.screens.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.RateReview
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.core.preferences.ApiConnectionState
import com.example.core.templates.ProjectTemplateType
import com.example.data.local.ActivityLogEntity
import com.example.data.local.ProjectEntity
import com.example.data.repository.AiStudioMode
import com.example.ui.components.GlassCard
import com.example.ui.components.GradientActionButton
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.LocalStudioColors
import com.example.ui.theme.PurpleGlow
import com.example.ui.theme.VioletNeon
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
  viewModel: HomeViewModel,
  onNavigateToProjects: () -> Unit,
  onNavigateToAiStudio: (AiStudioMode?) -> Unit,
  onNavigateToTools: () -> Unit,
  onNavigateToSettings: () -> Unit,
) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val studio = LocalStudioColors.current
  var showQuickCreate by remember { mutableStateOf(false) }

  BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
    val isWide = maxWidth >= 720.dp

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      // Top Branding Bar
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
              painter = painterResource(id = R.drawable.img_studio_logo),
              contentDescription = "Android Lab 2.0 Logo",
              contentScale = ContentScale.Crop,
              modifier =
                Modifier
                  .size(46.dp)
                  .clip(RoundedCornerShape(14.dp))
                  .border(
                    width = 1.5.dp,
                    brush = Brush.linearGradient(listOf(VioletNeon, ElectricBlue)),
                    shape = RoundedCornerShape(14.dp),
                  ),
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = "Android Lab",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground,
              )
              Text(
                text = stringResource(R.string.studio_tagline),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
          StatusPill(
            text = "v2.0",
            dotColor = ElectricBlue,
            containerColor = VioletNeon.copy(alpha = 0.16f),
          )
        }
      }

      // Hero Welcome Banner + Quick Actions
      item {
        Box(
          modifier =
            Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(24.dp))
              .border(
                width = 1.dp,
                brush = Brush.linearGradient(listOf(VioletNeon.copy(0.6f), ElectricBlue.copy(0.5f))),
                shape = RoundedCornerShape(24.dp),
              )
        ) {
          Image(
            painter = painterResource(id = R.drawable.img_hero_banner),
            contentDescription = "Studio workspace banner",
            contentScale = ContentScale.Crop,
            modifier = Modifier.matchParentSize(),
          )
          Box(
            modifier =
              Modifier
                .matchParentSize()
                .background(
                  Brush.verticalGradient(
                    colors = listOf(Color(0xB8060A18), Color(0xEC090F24))
                  )
                )
          )
          Column(modifier = Modifier.padding(20.dp)) {
            val apiDot =
              when (uiState.preferences.apiConnectionState) {
                ApiConnectionState.VERIFIED -> studio.success
                ApiConnectionState.CONFIGURED_UNTESTED -> studio.warning
                ApiConnectionState.ERROR -> studio.error
                ApiConnectionState.NOT_CONFIGURED -> Color(0xFF94A3B8)
              }
            val apiLabel =
              when (uiState.preferences.apiConnectionState) {
                ApiConnectionState.VERIFIED -> "Gemini Connected"
                ApiConnectionState.CONFIGURED_UNTESTED -> "Key Saved (Untested)"
                ApiConnectionState.ERROR -> "Gemini Key Error"
                ApiConnectionState.NOT_CONFIGURED -> "API Key Needed"
              }
            StatusPill(
              text = apiLabel,
              dotColor = apiDot,
              containerColor = Color(0xAA0F172A),
            )
            Spacer(modifier = Modifier.height(14.dp))
            Text(
              text = stringResource(R.string.welcome_title),
              style = MaterialTheme.typography.headlineMedium,
              color = Color.White,
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = stringResource(R.string.welcome_subtitle),
              style = MaterialTheme.typography.bodyMedium,
              color = Color(0xFFCBD5E1),
            )
            Spacer(modifier = Modifier.height(18.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              GradientActionButton(
                text = stringResource(R.string.quick_new_project),
                icon = Icons.Filled.Add,
                onClick = { showQuickCreate = true },
                modifier = Modifier.weight(1f),
                testTag = "home_quick_new_project",
              )
              OutlinedButton(
                onClick = { onNavigateToAiStudio(null) },
                modifier = Modifier.height(48.dp).testTag("home_open_ai_studio"),
                shape = RoundedCornerShape(16.dp),
              ) {
                Icon(
                  imageVector = Icons.Filled.AutoAwesome,
                  contentDescription = null,
                  tint = ElectricBlue,
                  modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(stringResource(R.string.open_ai_studio), color = Color.White)
              }
            }
          }
        }
      }

      // AI Studio Shortcut Card
      item {
        GlassCard(
          onClick = { onNavigateToAiStudio(AiStudioMode.CODING_ASSISTANT) },
          testTag = "home_ai_shortcut_card",
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              Box(
                modifier =
                  Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Brush.linearGradient(listOf(VioletNeon, ElectricBlue))),
                contentAlignment = Alignment.Center,
              ) {
                Icon(
                  imageVector = Icons.Filled.AutoAwesome,
                  contentDescription = null,
                  tint = Color.White,
                )
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(
                  text = "Gemini AI Studio Shortcut",
                  style = MaterialTheme.typography.titleMedium,
                  color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                  text = "Model: ${uiState.preferences.selectedModel.displayName}",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowForward,
              contentDescription = "Open AI Studio",
              tint = MaterialTheme.colorScheme.primary,
            )
          }
          Spacer(modifier = Modifier.height(12.dp))
          LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val shortcuts =
              listOf(
                Triple(AiStudioMode.COMPOSE_UI, "Compose UI", Icons.Filled.Bolt),
                Triple(AiStudioMode.APP_GEN, "App Gen", Icons.Filled.RocketLaunch),
                Triple(AiStudioMode.DEBUG_ERROR, "Debug Error", Icons.Filled.BugReport),
                Triple(AiStudioMode.CODE_REVIEW, "Code Review", Icons.Filled.RateReview),
              )
            items(shortcuts) { (mode, label, icon) ->
              AssistChip(
                onClick = { onNavigateToAiStudio(mode) },
                label = { Text(label, style = MaterialTheme.typography.labelMedium) },
                leadingIcon = {
                  Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp))
                },
                colors =
                  AssistChipDefaults.assistChipColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                  ),
              )
            }
          }
        }
      }

      // Development Statistics
      item {
        SectionHeader(
          title = stringResource(R.string.dev_statistics),
          subtitle = "Live Room workspace & AI telemetry",
        )
        Spacer(modifier = Modifier.height(10.dp))
        if (isWide) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            StatGlassTile("Projects", uiState.projectCount.toString(), Icons.Filled.FolderOpen, VioletNeon, Modifier.weight(1f))
            StatGlassTile("Source Files", uiState.totalFiles.toString(), Icons.Filled.Description, ElectricBlue, Modifier.weight(1f))
            StatGlassTile("AI Prompts", uiState.totalAiPrompts.toString(), Icons.Filled.AutoAwesome, PurpleGlow, Modifier.weight(1f))
            StatGlassTile("Target API", "API 36", Icons.Filled.Memory, studio.success, Modifier.weight(1f))
          }
        } else {
          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              StatGlassTile("Projects", uiState.projectCount.toString(), Icons.Filled.FolderOpen, VioletNeon, Modifier.weight(1f))
              StatGlassTile("Source Files", uiState.totalFiles.toString(), Icons.Filled.Description, ElectricBlue, Modifier.weight(1f))
            }
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              StatGlassTile("AI Prompts", uiState.totalAiPrompts.toString(), Icons.Filled.AutoAwesome, PurpleGlow, Modifier.weight(1f))
              StatGlassTile("Min / Target", "26 / 36", Icons.Filled.Memory, studio.success, Modifier.weight(1f))
            }
          }
        }
      }

      // Recent Projects
      item {
        SectionHeader(
          title = stringResource(R.string.recent_projects),
          subtitle = "Tap any workspace to open in Developer Tools",
          actionLabel = "All Projects",
          onAction = onNavigateToProjects,
        )
      }

      if (uiState.recentProjects.isEmpty()) {
        item {
          GlassCard {
            Text(
              text = "No projects in workspace yet. Create one from a template to begin.",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(10.dp))
            Button(onClick = { showQuickCreate = true }) {
              Text("Create First Project")
            }
          }
        }
      } else {
        items(uiState.recentProjects, key = { it.id }) { project ->
          RecentProjectCard(
            project = project,
            isActive = project.id == uiState.preferences.activeProjectId,
            onOpen = { viewModel.openProject(project.id) { onNavigateToTools() } },
          )
        }
      }

      // Application Status
      item {
        SectionHeader(
          title = stringResource(R.string.application_status),
          subtitle = "Real security, storage & diagnostics state",
          actionLabel = "Configure",
          onAction = onNavigateToSettings,
        )
        Spacer(modifier = Modifier.height(10.dp))
        GlassCard {
          StatusRowItem(
            icon = Icons.Filled.Lock,
            label = "Android Keystore AES-256-GCM",
            status = if (uiState.keystoreReady) "Hardware Ready" else "Unavailable",
            dotColor = if (uiState.keystoreReady) studio.success else studio.error,
          )
          Spacer(modifier = Modifier.height(10.dp))
          StatusRowItem(
            icon = Icons.Filled.AutoAwesome,
            label = "Gemini API Key",
            status =
              if (uiState.preferences.hasGeminiKey) {
                uiState.preferences.maskedGeminiKey
              } else {
                "Not Configured"
              },
            dotColor =
              when (uiState.preferences.apiConnectionState) {
                ApiConnectionState.VERIFIED -> studio.success
                ApiConnectionState.CONFIGURED_UNTESTED -> studio.warning
                ApiConnectionState.ERROR -> studio.error
                ApiConnectionState.NOT_CONFIGURED -> Color(0xFF94A3B8)
              },
          )
          Spacer(modifier = Modifier.height(10.dp))
          StatusRowItem(
            icon = Icons.Filled.Storage,
            label = "Room Local Persistence",
            status = "Active (${uiState.projectCount} projects)",
            dotColor = studio.success,
          )
          Spacer(modifier = Modifier.height(10.dp))
          StatusRowItem(
            icon = Icons.Filled.Code,
            label = "Static Syntax & XML/JSON Analyzer",
            status = "Ready (No local APK compiler)",
            dotColor = ElectricBlue,
          )
        }
      }

      // Recent Activities
      item {
        SectionHeader(
          title = stringResource(R.string.recent_activities),
          subtitle = "Workspace & AI audit trail",
        )
      }

      if (uiState.recentActivities.isEmpty()) {
        item {
          GlassCard {
            Text(
              text = "Activity feed will populate as you create projects, edit code, and run Gemini queries.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      } else {
        items(uiState.recentActivities, key = { it.id }) { activity ->
          ActivityFeedItem(activity)
        }
      }

      item { Spacer(modifier = Modifier.height(12.dp)) }
    }
  }

  if (showQuickCreate) {
    QuickCreateProjectDialog(
      onDismiss = { showQuickCreate = false },
      onCreate = { name, pkg, template ->
        viewModel.quickCreateProject(name, pkg, template) {
          showQuickCreate = false
          onNavigateToTools()
        }
      },
    )
  }
}

@Composable
private fun StatGlassTile(
  label: String,
  value: String,
  icon: ImageVector,
  accent: Color,
  modifier: Modifier = Modifier,
) {
  GlassCard(modifier = modifier, contentPadding = PaddingValues(14.dp)) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(
        modifier =
          Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(accent.copy(alpha = 0.18f)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(18.dp))
      }
      Spacer(modifier = Modifier.width(10.dp))
      Column {
        Text(
          text = value,
          style = MaterialTheme.typography.titleLarge,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
          text = label,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
    }
  }
}

@Composable
private fun RecentProjectCard(
  project: ProjectEntity,
  isActive: Boolean,
  onOpen: () -> Unit,
) {
  val studio = LocalStudioColors.current
  GlassCard(onClick = onOpen, testTag = "home_project_${project.id}") {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = project.name,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
          )
          if (isActive) {
            Spacer(modifier = Modifier.width(8.dp))
            StatusPill(text = "ACTIVE", dotColor = studio.success)
          }
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = project.packageName,
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.secondary,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = project.description,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )
      }
      Spacer(modifier = Modifier.width(8.dp))
      Icon(
        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
        contentDescription = "Open ${project.name}",
        tint = MaterialTheme.colorScheme.primary,
      )
    }
  }
}

@Composable
private fun StatusRowItem(
  icon: ImageVector,
  label: String,
  status: String,
  dotColor: Color,
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
      Icon(
        icon,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(18.dp),
      )
      Spacer(modifier = Modifier.width(10.dp))
      Text(
        text = label,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
    Spacer(modifier = Modifier.width(8.dp))
    StatusPill(text = status, dotColor = dotColor)
  }
}

@Composable
private fun ActivityFeedItem(activity: ActivityLogEntity) {
  val formattedTime =
    remember(activity.timestampMs) {
      SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(activity.timestampMs))
    }
  val accent =
    when (activity.category) {
      "AI" -> VioletNeon
      "SECURITY" -> LocalStudioColors.current.success
      "TOOLKIT" -> ElectricBlue
      else -> PurpleGlow
    }

  GlassCard(contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = accent.copy(alpha = 0.16f),
        ) {
          Text(
            text = activity.category,
            style = MaterialTheme.typography.labelSmall,
            color = accent,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
          )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = activity.title,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Text(
            text = activity.detail,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }
      Text(
        text = formattedTime,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}

@Composable
fun QuickCreateProjectDialog(
  onDismiss: () -> Unit,
  onCreate: (String, String, ProjectTemplateType) -> Unit,
) {
  var name by remember { mutableStateOf("NovaCompose") }
  var packageName by remember { mutableStateOf("com.androidlab.nova") }
  var selectedTemplate by remember { mutableStateOf(ProjectTemplateType.COMPOSE_M3) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Quick Create Project") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("Project Name") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("quick_project_name_input"),
        )
        OutlinedTextField(
          value = packageName,
          onValueChange = { packageName = it },
          label = { Text("Package Name") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        Text("Template", style = MaterialTheme.typography.labelMedium)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(ProjectTemplateType.entries) { tpl ->
            FilterChip(
              selected = selectedTemplate == tpl,
              onClick = { selectedTemplate = tpl },
              label = { Text(tpl.title) },
            )
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = { onCreate(name, packageName, selectedTemplate) },
        enabled = name.isNotBlank(),
        modifier = Modifier.testTag("quick_create_confirm_btn"),
      ) {
        Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("Create & Open")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Cancel") }
    },
  )
}
