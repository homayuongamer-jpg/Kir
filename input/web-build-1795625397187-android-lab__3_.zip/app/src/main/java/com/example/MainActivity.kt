package com.example

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.core.preferences.AppLanguage
import com.example.core.preferences.StudioPreferences
import com.example.data.repository.AiStudioMode
import com.example.di.AppContainer
import com.example.di.StudioViewModelFactory
import com.example.ui.components.AiStudioRoute
import com.example.ui.components.HomeRoute
import com.example.ui.components.ProjectsRoute
import com.example.ui.components.SettingsRoute
import com.example.ui.components.SplashScreenOverlay
import com.example.ui.components.StudioBackdrop
import com.example.ui.components.StudioBottomBar
import com.example.ui.components.StudioNavigationRail
import com.example.ui.components.StudioRoute
import com.example.ui.components.ToolsRoute
import com.example.ui.screens.aistudio.AiStudioScreen
import com.example.ui.screens.aistudio.AiStudioViewModel
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.home.HomeViewModel
import com.example.ui.screens.projects.ProjectsScreen
import com.example.ui.screens.projects.ProjectsViewModel
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.settings.SettingsViewModel
import com.example.ui.screens.tools.ToolsScreen
import com.example.ui.screens.tools.ToolsViewModel
import com.example.ui.theme.AndroidLabTheme
import java.util.Locale
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    val container = (application as AndroidLabApplication).container
    setContent { AndroidLabAppRoot(container = container) }
  }
}

@Composable
fun AndroidLabAppRoot(container: AppContainer) {
  val preferences by
    container.preferencesRepository.preferencesFlow.collectAsStateWithLifecycle(
      initialValue = StudioPreferences()
    )

  var showSplash by remember { mutableStateOf(true) }
  LaunchedEffect(Unit) {
    delay(1150L)
    showSplash = false
  }

  val baseContext = LocalContext.current
  val localizedContext =
    remember(baseContext, preferences.language) {
      createLocalizedContext(baseContext, preferences.language)
    }

  CompositionLocalProvider(LocalContext provides localizedContext) {
    AndroidLabTheme(themeMode = preferences.themeMode) {
      Box(modifier = Modifier.fillMaxSize()) {
        AndroidLabShell(container = container)
        SplashScreenOverlay(visible = showSplash, onSkip = { showSplash = false })
      }
    }
  }
}

private fun createLocalizedContext(base: Context, language: AppLanguage): Context {
  val locale = Locale.forLanguageTag(language.code)
  val config = Configuration(base.resources.configuration)
  config.setLocale(locale)
  return base.createConfigurationContext(config)
}

@Composable
private fun AndroidLabShell(container: AppContainer) {
  val navController = rememberNavController()
  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentDestination = navBackStackEntry?.destination

  var pendingAiMode by remember { mutableStateOf<AiStudioMode?>(null) }
  var pendingAiPrompt by remember { mutableStateOf<String?>(null) }

  val homeViewModel: HomeViewModel =
    viewModel(
      factory =
        StudioViewModelFactory {
          HomeViewModel(
            projectRepository = container.projectRepository,
            aiStudioRepository = container.aiStudioRepository,
            diagnosticsRepository = container.diagnosticsRepository,
            preferencesRepository = container.preferencesRepository,
            cryptoManager = container.cryptoManager,
          )
        }
    )

  val projectsViewModel: ProjectsViewModel =
    viewModel(
      factory =
        StudioViewModelFactory {
          ProjectsViewModel(
            projectRepository = container.projectRepository,
            preferencesRepository = container.preferencesRepository,
            diagnosticsRepository = container.diagnosticsRepository,
          )
        }
    )

  val aiStudioViewModel: AiStudioViewModel =
    viewModel(
      factory =
        StudioViewModelFactory {
          AiStudioViewModel(
            aiStudioRepository = container.aiStudioRepository,
            projectRepository = container.projectRepository,
            preferencesRepository = container.preferencesRepository,
          )
        }
    )

  val toolsViewModel: ToolsViewModel =
    viewModel(
      factory =
        StudioViewModelFactory {
          ToolsViewModel(
            projectRepository = container.projectRepository,
            preferencesRepository = container.preferencesRepository,
            diagnosticsRepository = container.diagnosticsRepository,
          )
        }
    )

  val settingsViewModel: SettingsViewModel =
    viewModel(
      factory =
        StudioViewModelFactory {
          SettingsViewModel(
            appContext = container.appContext,
            preferencesRepository = container.preferencesRepository,
            aiStudioRepository = container.aiStudioRepository,
            diagnosticsRepository = container.diagnosticsRepository,
            cryptoManager = container.cryptoManager,
          )
        }
    )

  fun navigateToTab(route: StudioRoute) {
    navController.navigate(route) {
      popUpTo(navController.graph.findStartDestination().id) { saveState = true }
      launchSingleTop = true
      restoreState = true
    }
  }

  StudioBackdrop {
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
      val useNavRail = maxWidth >= 720.dp

      Scaffold(
        containerColor = Color.Transparent,
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
          if (!useNavRail) {
            Box(modifier = Modifier.navigationBarsPadding()) {
              StudioBottomBar(
                currentDestination = currentDestination,
                onSelectTab = { navigateToTab(it) },
              )
            }
          }
        },
      ) { innerPadding ->
        Row(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
          if (useNavRail) {
            StudioNavigationRail(
              currentDestination = currentDestination,
              onSelectTab = { navigateToTab(it) },
            )
          }
          NavHost(
            navController = navController,
            startDestination = HomeRoute,
            modifier = Modifier.weight(1f).fillMaxSize(),
          ) {
            composable<HomeRoute> {
              HomeScreen(
                viewModel = homeViewModel,
                onNavigateToProjects = { navigateToTab(ProjectsRoute) },
                onNavigateToAiStudio = { mode ->
                  pendingAiMode = mode
                  navigateToTab(AiStudioRoute)
                },
                onNavigateToTools = { navigateToTab(ToolsRoute) },
                onNavigateToSettings = { navigateToTab(SettingsRoute) },
              )
            }
            composable<ProjectsRoute> {
              ProjectsScreen(
                viewModel = projectsViewModel,
                onOpenProjectInToolkit = { navigateToTab(ToolsRoute) },
              )
            }
            composable<AiStudioRoute> {
              AiStudioScreen(
                viewModel = aiStudioViewModel,
                initialMode = pendingAiMode,
                initialPrompt = pendingAiPrompt,
              )
            }
            composable<ToolsRoute> {
              ToolsScreen(
                viewModel = toolsViewModel,
                onSendErrorToAi = { prompt ->
                  pendingAiMode = AiStudioMode.DEBUG_ERROR
                  pendingAiPrompt = prompt
                  navigateToTab(AiStudioRoute)
                },
              )
            }
            composable<SettingsRoute> {
              SettingsScreen(viewModel = settingsViewModel)
            }
          }
        }
      }
    }
  }
}
