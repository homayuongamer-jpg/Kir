package com.example.di

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.core.preferences.StudioPreferencesRepository
import com.example.core.security.KeystoreCryptoManager
import com.example.data.local.AndroidLabDatabase
import com.example.data.remote.GeminiApiService
import com.example.data.remote.GeminiClientFactory
import com.example.data.repository.AiStudioRepository
import com.example.data.repository.DiagnosticsRepository
import com.example.data.repository.ProjectRepository

class AppContainer(context: Context) {
  val appContext: Context = context.applicationContext

  val cryptoManager: KeystoreCryptoManager by lazy { KeystoreCryptoManager() }

  val preferencesRepository: StudioPreferencesRepository by lazy {
    StudioPreferencesRepository(appContext, cryptoManager)
  }

  val database: AndroidLabDatabase by lazy { AndroidLabDatabase.build(appContext) }

  val diagnosticsRepository: DiagnosticsRepository by lazy {
    DiagnosticsRepository(
      activityLogDao = database.activityLogDao(),
      diagnosticLogDao = database.diagnosticLogDao(),
    )
  }

  val projectRepository: ProjectRepository by lazy {
    ProjectRepository(
      projectDao = database.projectDao(),
      projectFileDao = database.projectFileDao(),
      preferencesRepository = preferencesRepository,
      diagnosticsRepository = diagnosticsRepository,
    )
  }

  val geminiApiService: GeminiApiService by lazy { GeminiClientFactory.create() }

  val aiStudioRepository: AiStudioRepository by lazy {
    AiStudioRepository(
      aiStudioDao = database.aiStudioDao(),
      geminiApiService = geminiApiService,
      preferencesRepository = preferencesRepository,
      diagnosticsRepository = diagnosticsRepository,
    )
  }
}

class StudioViewModelFactory<T : ViewModel>(private val creator: () -> T) :
  ViewModelProvider.Factory {
  @Suppress("UNCHECKED_CAST")
  override fun <VM : ViewModel> create(modelClass: Class<VM>): VM = creator() as VM
}
