package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioColors
import com.example.ui.theme.PurpleGlow
import com.example.ui.theme.VioletNeon

@Composable
fun StudioBackdrop(
  modifier: Modifier = Modifier,
  content: @Composable BoxScope.() -> Unit,
) {
  val studio = LocalStudioColors.current
  Box(
    modifier =
      modifier
        .fillMaxSize()
        .drawBehind {
          drawRect(
            brush =
              Brush.verticalGradient(
                colors = listOf(studio.backdropStart, studio.backdropMid, studio.backdropEnd)
              )
          )
          // Subtle ambient violet & electric blue glow orbs
          drawCircle(
            brush =
              Brush.radialGradient(
                colors =
                  listOf(
                    VioletNeon.copy(alpha = if (studio.isDark) 0.16f else 0.08f),
                    Color.Transparent,
                  ),
                center = Offset(size.width * 0.85f, size.height * 0.12f),
                radius = size.maxDimension * 0.45f,
              ),
            center = Offset(size.width * 0.85f, size.height * 0.12f),
            radius = size.maxDimension * 0.45f,
          )
          drawCircle(
            brush =
              Brush.radialGradient(
                colors =
                  listOf(
                    ElectricBlue.copy(alpha = if (studio.isDark) 0.12f else 0.06f),
                    Color.Transparent,
                  ),
                center = Offset(size.width * 0.12f, size.height * 0.78f),
                radius = size.maxDimension * 0.42f,
              ),
            center = Offset(size.width * 0.12f, size.height * 0.78f),
            radius = size.maxDimension * 0.42f,
          )
        },
    content = content,
  )
}

@Composable
fun GlassCard(
  modifier: Modifier = Modifier,
  cornerRadius: Dp = 22.dp,
  contentPadding: PaddingValues = PaddingValues(16.dp),
  onClick: (() -> Unit)? = null,
  testTag: String? = null,
  content: @Composable ColumnScope.() -> Unit,
) {
  val studio = LocalStudioColors.current
  val shape = RoundedCornerShape(cornerRadius)
  val borderBrush =
    Brush.linearGradient(colors = listOf(studio.glassBorderStart, studio.glassBorderEnd))

  val baseModifier =
    modifier
      .then(if (testTag != null) Modifier.testTag(testTag) else Modifier)
      .clip(shape)
      .background(studio.glassFill)
      .border(width = 1.dp, brush = borderBrush, shape = shape)
      .then(
        if (onClick != null) {
          Modifier.clickable(role = Role.Button, onClick = onClick)
        } else {
          Modifier
        }
      )

  Column(modifier = baseModifier.padding(contentPadding), content = content)
}

@Composable
fun GradientActionButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  icon: ImageVector? = null,
  enabled: Boolean = true,
  testTag: String? = null,
) {
  val studio = LocalStudioColors.current
  val shape = RoundedCornerShape(16.dp)
  val gradient =
    Brush.horizontalGradient(
      colors =
        if (enabled) {
          listOf(studio.accentGradientStart, studio.accentGradientMid, studio.accentGradientEnd)
        } else {
          listOf(Color.Gray.copy(alpha = 0.4f), Color.Gray.copy(alpha = 0.4f))
        }
    )

  Button(
    onClick = onClick,
    enabled = enabled,
    shape = shape,
    colors =
      ButtonDefaults.buttonColors(
        containerColor = Color.Transparent,
        disabledContainerColor = Color.Transparent,
        contentColor = Color.White,
        disabledContentColor = Color.White.copy(alpha = 0.6f),
      ),
    contentPadding = PaddingValues(0.dp),
    modifier =
      modifier
        .height(48.dp)
        .then(if (testTag != null) Modifier.testTag(testTag) else Modifier)
        .clip(shape)
        .background(gradient),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 18.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.Center,
    ) {
      if (icon != null) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          modifier = Modifier.size(18.dp),
          tint = Color.White,
        )
        Spacer(modifier = Modifier.width(8.dp))
      }
      Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        color = Color.White,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
fun StatusPill(
  text: String,
  dotColor: Color,
  modifier: Modifier = Modifier,
  containerColor: Color = dotColor.copy(alpha = 0.14f),
) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(50),
    color = containerColor,
    border = BorderStroke(1.dp, dotColor.copy(alpha = 0.35f)),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(dotColor))
      Text(
        text = text,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
fun SectionHeader(
  title: String,
  subtitle: String? = null,
  actionLabel: String? = null,
  onAction: (() -> Unit)? = null,
  modifier: Modifier = Modifier,
) {
  Row(
    modifier = modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = title,
        style = MaterialTheme.typography.titleLarge,
        color = MaterialTheme.colorScheme.onBackground,
      )
      if (!subtitle.isNullOrBlank()) {
        Text(
          text = subtitle,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    }
    if (actionLabel != null && onAction != null) {
      Surface(
        onClick = onAction,
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
      ) {
        Text(
          text = actionLabel,
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.primary,
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
        )
      }
    }
  }
}

fun highlightCodeSyntax(code: String, fileType: String): AnnotatedString {
  return buildAnnotatedString {
    append(code)
    val commentColor = Color(0xFF64748B)
    val keywordColor = Color(0xFFC084FC)
    val stringColor = Color(0xFF34D399)
    val typeOrTagColor = Color(0xFF38BDF8)
    val numberColor = Color(0xFFFBBF24)

    // Strings
    Regex("\"([^\"\\\\]|\\\\.)*\"").findAll(code).forEach { match ->
      addStyle(SpanStyle(color = stringColor), match.range.first, match.range.last + 1)
    }

    when (fileType.lowercase()) {
      "xml" -> {
        Regex("</?[A-Za-z0-9_.:-]+|/?>").findAll(code).forEach { match ->
          addStyle(SpanStyle(color = typeOrTagColor, fontWeight = FontWeight.Medium), match.range.first, match.range.last + 1)
        }
        Regex("\\b[a-zA-Z0-9_]+:[a-zA-Z0-9_]+").findAll(code).forEach { match ->
          addStyle(SpanStyle(color = keywordColor), match.range.first, match.range.last + 1)
        }
        Regex("<!--[\\s\\S]*?-->").findAll(code).forEach { match ->
          addStyle(SpanStyle(color = commentColor), match.range.first, match.range.last + 1)
        }
      }
      "json" -> {
        Regex("\"([^\"]+)\"\\s*:").findAll(code).forEach { match ->
          addStyle(SpanStyle(color = typeOrTagColor, fontWeight = FontWeight.Medium), match.range.first, match.range.last + 1)
        }
        Regex("\\b(true|false|null)\\b").findAll(code).forEach { match ->
          addStyle(SpanStyle(color = keywordColor), match.range.first, match.range.last + 1)
        }
        Regex("\\b\\d+(\\.\\d+)?\\b").findAll(code).forEach { match ->
          addStyle(SpanStyle(color = numberColor), match.range.first, match.range.last + 1)
        }
      }
      else -> {
        val keywords =
          Regex(
            "\\b(package|import|class|interface|object|data|sealed|enum|fun|val|var|return|if|else|when|for|while|suspend|override|private|public|internal|companion|by|lazy|true|false|null|try|catch|throw)\\b"
          )
        keywords.findAll(code).forEach { match ->
          addStyle(
            SpanStyle(color = keywordColor, fontWeight = FontWeight.Medium),
            match.range.first,
            match.range.last + 1,
          )
        }
        Regex("@[A-Za-z_][A-Za-z0-9_]*").findAll(code).forEach { match ->
          addStyle(SpanStyle(color = numberColor), match.range.first, match.range.last + 1)
        }
        Regex("//.*").findAll(code).forEach { match ->
          addStyle(SpanStyle(color = commentColor), match.range.first, match.range.last + 1)
        }
      }
    }
  }
}

@Composable
fun CodeDisplayBox(
  code: String,
  fileType: String,
  modifier: Modifier = Modifier,
  showLineNumbers: Boolean = true,
) {
  val studio = LocalStudioColors.current
  val lines = code.lines()
  val highlighted = highlightCodeSyntax(code, fileType)

  Surface(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    color = studio.codeSurface,
    border = BorderStroke(1.dp, studio.codeBorder),
  ) {
    Row(modifier = Modifier.padding(12.dp)) {
      if (showLineNumbers) {
        Column(modifier = Modifier.padding(end = 10.dp)) {
          lines.forEachIndexed { idx, _ ->
            Text(
              text = (idx + 1).toString().padStart(2, ' '),
              fontFamily = JetBrainsMonoFontFamily,
              fontSize = 12.sp,
              lineHeight = 19.sp,
              color = Color(0xFF475569),
            )
          }
        }
      }
      Text(
        text = highlighted,
        fontFamily = JetBrainsMonoFontFamily,
        fontSize = 12.sp,
        lineHeight = 19.sp,
        color = Color(0xFFE2E8F0),
      )
    }
  }
}

@Composable
fun SplashScreenOverlay(
  visible: Boolean,
  onSkip: () -> Unit,
) {
  val infiniteTransition = rememberInfiniteTransition(label = "splash_pulse")
  val pulseScale by
    infiniteTransition.animateFloat(
      initialValue = 0.96f,
      targetValue = 1.05f,
      animationSpec =
        infiniteRepeatable(
          animation = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
          repeatMode = RepeatMode.Reverse,
        ),
      label = "logo_scale",
    )
  val alpha by
    animateFloatAsState(
      targetValue = if (visible) 1f else 0f,
      animationSpec = tween(400),
      label = "splash_alpha",
    )

  AnimatedVisibility(
    visible = visible,
    enter = fadeIn(tween(250)),
    exit = fadeOut(tween(420)),
  ) {
    Box(
      modifier =
        Modifier
          .fillMaxSize()
          .alpha(alpha)
          .background(
            Brush.verticalGradient(
              colors = listOf(Color(0xFF050814), Color(0xFF0E1535), Color(0xFF070C1E))
            )
          )
          .clickable(onClick = onSkip),
      contentAlignment = Alignment.Center,
    ) {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.padding(32.dp),
      ) {
        Box(
          modifier =
            Modifier
              .size(124.dp)
              .scale(pulseScale)
              .clip(RoundedCornerShape(32.dp))
              .border(
                width = 2.dp,
                brush = Brush.linearGradient(listOf(VioletNeon, ElectricBlue, PurpleGlow)),
                shape = RoundedCornerShape(32.dp),
              ),
          contentAlignment = Alignment.Center,
        ) {
          Image(
            painter = painterResource(id = R.drawable.img_studio_logo),
            contentDescription = "Android Lab 2.0 Logo",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
          )
        }
        Spacer(modifier = Modifier.height(24.dp))
        Text(
          text = "ANDROID LAB",
          style = MaterialTheme.typography.displayLarge,
          color = Color.White,
        )
        Spacer(modifier = Modifier.height(6.dp))
        StatusPill(
          text = "STUDIO 2.0 • GEMINI ENGINE",
          dotColor = ElectricBlue,
          containerColor = VioletNeon.copy(alpha = 0.22f),
        )
        Spacer(modifier = Modifier.height(18.dp))
        Text(
          text = "Initializing Keystore & Room Workspace...",
          style = MaterialTheme.typography.bodySmall,
          color = Color(0xFF94A3B8),
        )
      }
    }
  }
}
