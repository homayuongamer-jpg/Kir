package com.example.core.templates

enum class ProjectTemplateType(
  val id: String,
  val title: String,
  val subtitle: String,
  val badge: String,
) {
  COMPOSE_M3(
    id = "compose_m3",
    title = "Compose M3 Starter",
    subtitle = "Edge-to-edge Material 3 scaffold, StateFlow ViewModel & custom Theme",
    badge = "UI + M3",
  ),
  MVVM_ROOM(
    id = "mvvm_room",
    title = "MVVM + Room Offline",
    subtitle = "Clean Entity, DAO, Repository, and Lifecycle-aware Compose screen",
    badge = "DATABASE",
  ),
  RETROFIT_API(
    id = "retrofit_api",
    title = "Retrofit REST Client",
    subtitle = "Coroutines API service, Moshi DTOs, and sealed Result state",
    badge = "NETWORK",
  ),
  EMPTY_STUDIO(
    id = "empty_studio",
    title = "Blank Kotlin Workspace",
    subtitle = "Minimal manifest, Gradle config, and MainActivity entry point",
    badge = "MINIMAL",
  ),
}

data class TemplateFileSpec(
  val name: String,
  val relativePath: String,
  val fileType: String,
  val content: String,
)

data class SnippetItem(
  val id: String,
  val title: String,
  val category: String,
  val fileType: String,
  val description: String,
  val code: String,
)

data class PromptPreset(
  val id: String,
  val title: String,
  val modeKey: String,
  val category: String,
  val prompt: String,
)

object ProjectTemplates {

  fun generateFilesForTemplate(
    template: ProjectTemplateType,
    projectName: String,
    packageName: String,
    minSdk: Int,
  ): List<TemplateFileSpec> {
    val cleanPkg = packageName.ifBlank { "com.androidlab.app" }
    val pkgPath = cleanPkg.replace('.', '/')

    val manifest =
      TemplateFileSpec(
        name = "AndroidManifest.xml",
        relativePath = "app/src/main/AndroidManifest.xml",
        fileType = "xml",
        content =
          """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />

    <application
        android:allowBackup="true"
        android:label="$projectName"
        android:supportsRtl="true"
        android:theme="@android:style/Theme.Material.NoActionBar">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>"""
            .trimIndent(),
      )

    val buildGradle =
      TemplateFileSpec(
        name = "build.gradle.kts",
        relativePath = "app/build.gradle.kts",
        fileType = "gradle",
        content =
          """plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "$cleanPkg"
    compileSdk = 36

    defaultConfig {
        applicationId = "$cleanPkg"
        minSdk = $minSdk
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
}"""
            .trimIndent(),
      )

    val configJson =
      TemplateFileSpec(
        name = "studio-config.json",
        relativePath = "studio-config.json",
        fileType = "json",
        content =
          """{
  "project": "$projectName",
  "packageName": "$cleanPkg",
  "template": "${template.id}",
  "minSdk": $minSdk,
  "targetSdk": 36,
  "compose": true
}"""
            .trimIndent(),
      )

    return when (template) {
      ProjectTemplateType.COMPOSE_M3 ->
        listOf(
          TemplateFileSpec(
            name = "MainActivity.kt",
            relativePath = "app/src/main/java/$pkgPath/MainActivity.kt",
            fileType = "kotlin",
            content =
              """package $cleanPkg

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    StudioStarterScreen(title = "$projectName")
                }
            }
        }
    }
}

@Composable
fun StudioStarterScreen(title: String) {
    var count by remember { mutableIntStateOf(0) }
    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = title, style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(12.dp))
            Text(text = "Build iterations: ${'$'}count")
            Spacer(modifier = Modifier.height(20.dp))
            Button(onClick = { count++ }) {
                Text("Increment Counter")
            }
        }
    }
}"""
                .trimIndent(),
          ),
          manifest,
          buildGradle,
          configJson,
        )

      ProjectTemplateType.MVVM_ROOM ->
        listOf(
          TemplateFileSpec(
            name = "MainActivity.kt",
            relativePath = "app/src/main/java/$pkgPath/MainActivity.kt",
            fileType = "kotlin",
            content =
              """package $cleanPkg

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme {
                val vm: NotesViewModel = viewModel()
                NotesScreen(viewModel = vm)
            }
        }
    }
}"""
                .trimIndent(),
          ),
          TemplateFileSpec(
            name = "NoteEntity.kt",
            relativePath = "app/src/main/java/$pkgPath/data/NoteEntity.kt",
            fileType = "kotlin",
            content =
              """package $cleanPkg.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<NoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(note: NoteEntity)
}"""
                .trimIndent(),
          ),
          TemplateFileSpec(
            name = "NotesViewModel.kt",
            relativePath = "app/src/main/java/$pkgPath/ui/NotesViewModel.kt",
            fileType = "kotlin",
            content =
              """package $cleanPkg.ui

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class NotesUiState(
    val notes: List<String> = listOf("Architecture ready"),
    val isLoading: Boolean = false
)

class NotesViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(NotesUiState())
    val uiState: StateFlow<NotesUiState> = _uiState.asStateFlow()

    fun addQuickNote(text: String) {
        if (text.isBlank()) return
        _uiState.value = _uiState.value.copy(notes = _uiState.value.notes + text.trim())
    }
}"""
                .trimIndent(),
          ),
          manifest,
          buildGradle,
          configJson,
        )

      ProjectTemplateType.RETROFIT_API ->
        listOf(
          TemplateFileSpec(
            name = "ApiService.kt",
            relativePath = "app/src/main/java/$pkgPath/network/ApiService.kt",
            fileType = "kotlin",
            content =
              """package $cleanPkg.network

import retrofit2.http.GET
import retrofit2.http.Path

data class RepoDto(
    val id: Long,
    val name: String,
    val description: String?
)

interface ApiService {
    @GET("users/{user}/repos")
    suspend fun listRepos(@Path("user") user: String): List<RepoDto>
}"""
                .trimIndent(),
          ),
          TemplateFileSpec(
            name = "NetworkResult.kt",
            relativePath = "app/src/main/java/$pkgPath/network/NetworkResult.kt",
            fileType = "kotlin",
            content =
              """package $cleanPkg.network

sealed interface NetworkResult<out T> {
    data object Loading : NetworkResult<Nothing>
    data class Success<T>(val data: T) : NetworkResult<T>
    data class Error(val message: String, val code: Int? = null) : NetworkResult<Nothing>
}"""
                .trimIndent(),
          ),
          manifest,
          buildGradle,
          configJson,
        )

      ProjectTemplateType.EMPTY_STUDIO ->
        listOf(
          TemplateFileSpec(
            name = "MainActivity.kt",
            relativePath = "app/src/main/java/$pkgPath/MainActivity.kt",
            fileType = "kotlin",
            content =
              """package $cleanPkg

import android.os.Bundle
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}"""
                .trimIndent(),
          ),
          manifest,
          buildGradle,
          configJson,
        )
    }
  }

  val builtInSnippets: List<SnippetItem> =
    listOf(
      SnippetItem(
        id = "m3_scaffold",
        title = "Material 3 Edge-to-Edge Scaffold",
        category = "Jetpack Compose",
        fileType = "kotlin",
        description = "TopAppBar + WindowInsets + LazyColumn boilerplate",
        code =
          """@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioScaffold(title: String, content: @Composable (PaddingValues) -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(title = { Text(title) })
        },
        contentWindowInsets = WindowInsets.safeDrawing,
        content = content
    )
}""",
      ),
      SnippetItem(
        id = "stateflow_vm",
        title = "StateFlow ViewModel Pattern",
        category = "Architecture",
        fileType = "kotlin",
        description = "Sealed UiState with MutableStateFlow & update",
        code =
          """sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Ready<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

class FeatureViewModel : ViewModel() {
    private val _state = MutableStateFlow<UiState<String>>(UiState.Loading)
    val state: StateFlow<UiState<String>> = _state.asStateFlow()
}""",
      ),
      SnippetItem(
        id = "room_dao",
        title = "Reactive Room DAO",
        category = "Persistence",
        fileType = "kotlin",
        description = "Flow queries with suspend upsert/delete",
        code =
          """@Dao
interface RecordDao {
    @Query("SELECT * FROM records ORDER BY updatedAt DESC")
    fun observeRecords(): Flow<List<RecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(record: RecordEntity)

    @Query("DELETE FROM records WHERE id = :id")
    suspend fun deleteById(id: Long)
}""",
      ),
      SnippetItem(
        id = "keystore_aes",
        title = "Android Keystore AES-GCM Cipher",
        category = "Security",
        fileType = "kotlin",
        description = "Hardware-backed KeyGenParameterSpec snippet",
        code =
          """val keyGen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
val spec = KeyGenParameterSpec.Builder(
    "my_secret_alias",
    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
)
    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
    .setKeySize(256)
    .build()
keyGen.init(spec)
val secretKey = keyGen.generateKey()""",
      ),
      SnippetItem(
        id = "xml_vector_badge",
        title = "Adaptive Vector Shape XML",
        category = "Resources",
        fileType = "xml",
        description = "Rounded gradient card background drawable",
        code =
          """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="20dp" />
    <gradient
        android:angle="135"
        android:startColor="#7C3AED"
        android:endColor="#2563EB" />
</shape>""",
      ),
      SnippetItem(
        id = "json_manifest_meta",
        title = "Project Metadata JSON",
        category = "Config",
        fileType = "json",
        description = "Structured app telemetry descriptor",
        code =
          """{
  "appName": "Android Lab Module",
  "minSdk": 26,
  "targetSdk": 36,
  "features": ["compose", "room", "coroutines"]
}""",
      ),
    )

  val builtInPrompts: List<PromptPreset> =
    listOf(
      PromptPreset(
        id = "p_compose_card",
        title = "Glassmorphic Dashboard Card",
        modeKey = "COMPOSE_UI",
        category = "Compose UI",
        prompt =
          "Create a reusable Material 3 Jetpack Compose glassmorphic metric card with an animated gradient border, icon badge, delta pill, and accessible semantics.",
      ),
      PromptPreset(
        id = "p_app_scaffold",
        title = "Offline-First Habit Tracker App",
        modeKey = "APP_GEN",
        category = "App Generator",
        prompt =
          "Design and generate a clean multi-file Kotlin + Jetpack Compose Habit Tracker app using MVVM, StateFlow, Room DAO, and Material 3 components.",
      ),
      PromptPreset(
        id = "p_debug_crash",
        title = "Analyze Compose Recomposition / Crash",
        modeKey = "DEBUG_ERROR",
        category = "Debugging",
        prompt =
          "Explain why IllegalStateException: Reading a state that was read after it was disposed or unstable lambda recomposition happens in Jetpack Compose, and show the exact fix.",
      ),
      PromptPreset(
        id = "p_arch_review",
        title = "Clean Architecture Layering Audit",
        modeKey = "ARCHITECTURE",
        category = "Architecture",
        prompt =
          "Recommend a scalable Clean Architecture + MVVM package structure for a modular Android Studio app with Room, DataStore, Retrofit, and Keystore security.",
      ),
      PromptPreset(
        id = "p_xml_motion",
        title = "Animated Vector & Adaptive Icon XML",
        modeKey = "XML_GEN",
        category = "XML",
        prompt =
          "Generate a clean Android XML adaptive icon configuration and gradient shape drawable following Material 3 safe-zone sizing (66dp inside 108dp).",
      ),
      PromptPreset(
        id = "p_code_review",
        title = "Coroutines & Lifecycle Safety Review",
        modeKey = "CODE_REVIEW",
        category = "Code Review",
        prompt =
          "Review the attached Kotlin code for structured concurrency leaks, main-thread blocking I/O, missing CancellationException handling, and Compose state anti-patterns.",
      ),
    )
}
