package com.example.ui.screens.projects

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.preferences.StudioPreferencesRepository
import com.example.core.templates.ProjectTemplateType
import com.example.data.local.ActivityLogEntity
import com.example.data.local.ProjectEntity
import com.example.data.local.ProjectFileEntity
import com.example.data.repository.DiagnosticsRepository
import com.example.data.repository.ProjectRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ProjectsUiState(
  val projects: List<ProjectEntity> = emptyList(),
  val activeProjectId: Long = 1L,
  val inspectedProject: ProjectEntity? = null,
  val inspectedProjectFiles: List<ProjectFileEntity> = emptyList(),
  val inspectedProjectHistory: List<ActivityLogEntity> = emptyList(),
  val statusBanner: String? = null,
)

class ProjectsViewModel(
  private val projectRepository: ProjectRepository,
  private val preferencesRepository: StudioPreferencesRepository,
  private val diagnosticsRepository: DiagnosticsRepository,
) : ViewModel() {

  private val inspectedProjectId = MutableStateFlow<Long?>(null)
  private val statusBanner = MutableStateFlow<String?>(null)

  @OptIn(ExperimentalCoroutinesApi::class)
  private val inspectedFilesFlow =
    inspectedProjectId.flatMapLatest { id ->
      if (id == null) flowOf(emptyList()) else projectRepository.observeProjectFiles(id)
    }

  @OptIn(ExperimentalCoroutinesApi::class)
  private val inspectedHistoryFlow =
    inspectedProjectId.flatMapLatest { id ->
      if (id == null) flowOf(emptyList()) else diagnosticsRepository.observeProjectHistory(id)
    }

  val uiState: StateFlow<ProjectsUiState> =
    combine(
        projectRepository.allProjects,
        preferencesRepository.preferencesFlow,
        inspectedProjectId,
        inspectedFilesFlow,
        inspectedHistoryFlow,
        statusBanner,
      ) { values ->
        @Suppress("UNCHECKED_CAST")
        val projects = values[0] as List<ProjectEntity>
        val prefs = values[1] as com.example.core.preferences.StudioPreferences
        val inspId = values[2] as Long?
        @Suppress("UNCHECKED_CAST")
        val inspFiles = values[3] as List<ProjectFileEntity>
        @Suppress("UNCHECKED_CAST")
        val inspHistory = values[4] as List<ActivityLogEntity>
        val banner = values[5] as String?

        ProjectsUiState(
          projects = projects,
          activeProjectId = prefs.activeProjectId,
          inspectedProject = projects.find { it.id == inspId },
          inspectedProjectFiles = inspFiles,
          inspectedProjectHistory = inspHistory,
          statusBanner = banner,
        )
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = ProjectsUiState(),
      )

  fun createProject(
    name: String,
    packageName: String,
    description: String,
    template: ProjectTemplateType,
    minSdk: Int,
  ) {
    viewModelScope.launch {
      projectRepository.createProjectFromTemplate(name, packageName, description, template, minSdk)
      statusBanner.value = "Created project '$name'."
    }
  }

  fun renameProject(project: ProjectEntity, newName: String) {
    viewModelScope.launch {
      projectRepository.renameProject(project, newName)
      statusBanner.value = "Renamed project to '${newName.trim()}'."
    }
  }

  fun updateMetadata(
    project: ProjectEntity,
    newName: String,
    newPackage: String,
    newDescription: String,
    newVersion: String,
    newMinSdk: Int,
  ) {
    viewModelScope.launch {
      projectRepository.updateProjectMetadata(
        project,
        newName,
        newPackage,
        newDescription,
        newVersion,
        newMinSdk,
      )
      statusBanner.value = "Updated metadata for '${newName.trim()}'."
    }
  }

  fun deleteProject(project: ProjectEntity) {
    viewModelScope.launch {
      projectRepository.deleteProject(project)
      if (inspectedProjectId.value == project.id) inspectedProjectId.value = null
      statusBanner.value = "Deleted project '${project.name}'."
    }
  }

  fun openProject(projectId: Long, onOpened: () -> Unit) {
    viewModelScope.launch {
      projectRepository.openProject(projectId)
      onOpened()
    }
  }

  fun inspectProject(projectId: Long?) {
    inspectedProjectId.value = projectId
  }

  fun clearBanner() {
    statusBanner.value = null
  }

  fun prepareExportBundle(projectId: Long, onReady: (fileName: String, json: String) -> Unit) {
    viewModelScope.launch {
      projectRepository
        .exportProjectBundleJson(projectId)
        .onSuccess { (fileName, json) -> onReady(fileName, json) }
        .onFailure { statusBanner.value = "Export failed: ${it.message}" }
    }
  }

  fun writeExportToUri(context: Context, uri: Uri, content: String) {
    viewModelScope.launch {
      val result =
        withContext(Dispatchers.IO) {
          runCatching {
            context.contentResolver.openOutputStream(uri)?.use { out ->
              out.write(content.toByteArray(Charsets.UTF_8))
            } ?: error("Unable to open destination file stream.")
          }
        }
      statusBanner.value =
        if (result.isSuccess) {
          "Project bundle exported successfully."
        } else {
          "Export error: ${result.exceptionOrNull()?.message}"
        }
    }
  }

  fun importFromUri(context: Context, uri: Uri) {
    viewModelScope.launch {
      val readResult =
        withContext(Dispatchers.IO) {
          runCatching {
            val fileName = resolveFileName(context, uri)
            val content =
              context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: error("Unable to read selected file.")
            fileName to content
          }
        }
      readResult
        .onSuccess { (name, text) ->
          projectRepository
            .importContentIntoWorkspace(name, text, uiState.value.activeProjectId)
            .onSuccess { msg -> statusBanner.value = msg }
            .onFailure { statusBanner.value = "Import error: ${it.message}" }
        }
        .onFailure { statusBanner.value = "Failed to open file: ${it.message}" }
    }
  }

  private fun resolveFileName(context: Context, uri: Uri): String {
    context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
      val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
      if (idx >= 0 && cursor.moveToFirst()) {
        return cursor.getString(idx) ?: "imported_file.kt"
      }
    }
    return uri.lastPathSegment?.substringAfterLast('/') ?: "imported_file.kt"
  }
}
