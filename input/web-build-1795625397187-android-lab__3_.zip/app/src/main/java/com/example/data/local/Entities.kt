package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val name: String,
  val packageName: String,
  val description: String,
  val templateType: String,
  val minSdk: Int = 26,
  val versionName: String = "1.0",
  val createdAtMs: Long = System.currentTimeMillis(),
  val updatedAtMs: Long = System.currentTimeMillis(),
)

@Entity(
  tableName = "project_files",
  foreignKeys =
    [
      ForeignKey(
        entity = ProjectEntity::class,
        parentColumns = ["id"],
        childColumns = ["projectId"],
        onDelete = ForeignKey.CASCADE,
      )
    ],
  indices = [Index("projectId")],
)
data class ProjectFileEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val projectId: Long,
  val name: String,
  val relativePath: String,
  val fileType: String, // kotlin, xml, json, gradle, markdown
  val content: String,
  val updatedAtMs: Long = System.currentTimeMillis(),
)

@Entity(
  tableName = "activity_logs",
  indices = [Index("projectId"), Index("timestampMs")],
)
data class ActivityLogEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val projectId: Long? = null,
  val category: String, // PROJECT, AI, TOOLKIT, SECURITY, SYSTEM
  val title: String,
  val detail: String,
  val timestampMs: Long = System.currentTimeMillis(),
)

@Entity(tableName = "ai_conversations")
data class AiConversationEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val modeKey: String,
  val modelId: String,
  val projectId: Long? = null,
  val createdAtMs: Long = System.currentTimeMillis(),
  val updatedAtMs: Long = System.currentTimeMillis(),
)

@Entity(
  tableName = "ai_messages",
  foreignKeys =
    [
      ForeignKey(
        entity = AiConversationEntity::class,
        parentColumns = ["id"],
        childColumns = ["conversationId"],
        onDelete = ForeignKey.CASCADE,
      )
    ],
  indices = [Index("conversationId")],
)
data class AiMessageEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val conversationId: Long,
  val role: String, // user, model, error
  val content: String,
  val modeKey: String,
  val modelId: String,
  val tokenCount: Int = 0,
  val latencyMs: Long = 0L,
  val timestampMs: Long = System.currentTimeMillis(),
)

@Entity(tableName = "custom_prompts")
data class CustomPromptEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val modeKey: String,
  val promptText: String,
  val createdAtMs: Long = System.currentTimeMillis(),
)

@Entity(tableName = "diagnostic_logs")
data class DiagnosticLogEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val level: String, // INFO, WARN, ERROR, AI
  val tag: String,
  val message: String,
  val timestampMs: Long = System.currentTimeMillis(),
)
