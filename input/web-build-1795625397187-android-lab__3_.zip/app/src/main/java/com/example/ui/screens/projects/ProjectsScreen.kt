package com.example.ui.screens.projects

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.core.templates.ProjectTemplateType
import com.example.data.local.ProjectEntity
import com.example.ui.components.GlassCard
import com.example.ui.components.GradientActionButton
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.LocalStudioColors
import com.example.ui.theme.VioletNeon
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectsScreen(
  viewModel: ProjectsViewModel,
  onOpenProjectInToolkit: () -> Unit,
) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val context = LocalContext.current
  val studio = LocalStudioColors.current

  var showCreateDialog by remember { mutableStateOf(false) }
  var preselectedTemplate by remember { mutableStateOf(ProjectTemplateType.COMPOSE_M3) }
  var renameTarget by remember { mutableStateOf<ProjectEntity?>(null) }
  var deleteTarget by remember { mutableStateOf<ProjectEntity?>(null) }
  var pendingExportJson by remember { mutableStateOf<String?>(null) }

  val importLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
      if (uri != null) {
        viewModel.importFromUri(context, uri)
      }
    }

  val exportLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
      val payload = pendingExportJson
      if (uri != null && payload != null) {
        viewModel.writeExportToUri(context, uri, payload)
      }
      pendingExportJson = null
    }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = stringResource(R.string.projects_title),
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground,
          )
          Text(
            text = "${uiState.projects.size} workspace(s) stored in Room",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedButton(
            onClick = { importLauncher.launch(arrayOf("*/*")) },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.height(48.dp).testTag("projects_import_btn"),
          ) {
            Icon(Icons.Filled.FileUpload, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(stringResource(R.string.import_bundle))
          }
          GradientActionButton(
            text = "New",
            icon = Icons.Filled.Add,
            onClick = {
              preselectedTemplate = ProjectTemplateType.COMPOSE_M3
              showCreateDialog = true
            },
            testTag = "projects_create_btn",
          )
        }
      }
    }

    if (!uiState.statusBanner.isNullOrBlank()) {
      item {
        GlassCard(contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = uiState.statusBanner.orEmpty(),
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.primary,
              modifier = Modifier.weight(1f),
            )
            TextButton(onClick = { viewModel.clearBanner() }) { Text("Dismiss") }
          }
        }
      }
    }

    // Project Templates Carousel
    item {
      SectionHeader(
        title = stringResource(R.string.templates_title),
        subtitle = "Instant multi-file Kotlin & Compose scaffolds",
      )
      Spacer(modifier = Modifier.height(10.dp))
      LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items(ProjectTemplateType.entries) { tpl ->
          GlassCard(
            onClick = {
              preselectedTemplate = tpl
              showCreateDialog = true
            },
            modifier = Modifier.width(230.dp),
            testTag = "template_${tpl.id}",
          ) {
            StatusPill(text = tpl.badge, dotColor = ElectricBlue)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = tpl.title,
              style = MaterialTheme.typography.titleMedium,
              color = MaterialTheme.colorScheme.onSurface,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = tpl.subtitle,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              maxLines = 2,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      }
    }

    item {
      SectionHeader(
        title = "Your Projects",
        subtitle = "Open, inspect metadata/history, export JSON bundles, or manage files",
      )
    }

    if (uiState.projects.isEmpty()) {
      item {
        GlassCard {
          Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            Icon(
              Icons.Filled.FolderOpen,
              contentDescription = null,
              tint = VioletNeon,
              modifier = Modifier.size(44.dp),
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text("No projects yet", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Create a project from a template or import a JSON/Kotlin file.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(14.dp))
            GradientActionButton(
              text = stringResource(R.string.create_project),
              icon = Icons.Filled.Add,
              onClick = { showCreateDialog = true },
            )
          }
        }
      }
    } else {
      items(uiState.projects, key = { it.id }) { project ->
        val isActive = project.id == uiState.activeProjectId
        val updatedLabel =
          remember(project.updatedAtMs) {
            SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()).format(Date(project.updatedAtMs))
          }
        GlassCard(testTag = "project_card_${project.id}") {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = project.name,
                  style = MaterialTheme.typography.titleLarge,
                  color = MaterialTheme.colorScheme.onSurface,
                )
                if (isActive) {
                  Spacer(modifier = Modifier.width(8.dp))
                  StatusPill(text = "ACTIVE", dotColor = studio.success)
                }
              }
              Text(
                text = "${project.packageName} • minSdk ${project.minSdk} • v${project.versionName}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.secondary,
              )
            }
            Text(
              text = updatedLabel,
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = project.description,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
          Spacer(modifier = Modifier.height(14.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Button(
              onClick = { viewModel.openProject(project.id) { onOpenProjectInToolkit() } },
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.height(48.dp).testTag("open_project_${project.id}"),
            ) {
              Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Open")
            }
            Row {
              IconButton(
                onClick = { viewModel.inspectProject(project.id) },
                modifier = Modifier.testTag("inspect_project_${project.id}"),
              ) {
                Icon(Icons.Filled.Info, contentDescription = "Metadata & History")
              }
              IconButton(
                onClick = { renameTarget = project },
                modifier = Modifier.testTag("rename_project_${project.id}"),
              ) {
                Icon(Icons.Filled.DriveFileRenameOutline, contentDescription = "Rename Project")
              }
              IconButton(
                onClick = {
                  viewModel.prepareExportBundle(project.id) { suggestedName, json ->
                    pendingExportJson = json
                    exportLauncher.launch(suggestedName)
                  }
                },
                modifier = Modifier.testTag("export_project_${project.id}"),
              ) {
                Icon(Icons.Filled.FileDownload, contentDescription = "Export Project Bundle")
              }
              IconButton(
                onClick = { deleteTarget = project },
                modifier = Modifier.testTag("delete_project_${project.id}"),
              ) {
                Icon(
                  Icons.Filled.Delete,
                  contentDescription = "Delete Project",
                  tint = studio.error,
                )
              }
            }
          }
        }
      }
    }

    item { Spacer(modifier = Modifier.height(12.dp)) }
  }

  if (showCreateDialog) {
    CreateProjectFullDialog(
      initialTemplate = preselectedTemplate,
      onDismiss = { showCreateDialog = false },
      onCreate = { name, pkg, desc, tpl, minSdk ->
        viewModel.createProject(name, pkg, desc, tpl, minSdk)
        showCreateDialog = false
      },
    )
  }

  renameTarget?.let { target ->
    var newName by remember(target.id) { mutableStateOf(target.name) }
    AlertDialog(
      onDismissRequest = { renameTarget = null },
      title = { Text("Rename Project") },
      text = {
        OutlinedTextField(
          value = newName,
          onValueChange = { newName = it },
          label = { Text("Project Name") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("rename_project_input"),
        )
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.renameProject(target, newName)
            renameTarget = null
          },
          enabled = newName.isNotBlank(),
        ) {
          Text("Save")
        }
      },
      dismissButton = {
        TextButton(onClick = { renameTarget = null }) { Text("Cancel") }
      },
    )
  }

  deleteTarget?.let { target ->
    AlertDialog(
      onDismissRequest = { deleteTarget = null },
      title = { Text("Delete '${target.name}'?") },
      text = {
        Text(
          "This permanently removes the project and all of its Kotlin, XML, and JSON files from your local Room workspace."
        )
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.deleteProject(target)
            deleteTarget = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = studio.error),
          modifier = Modifier.testTag("confirm_delete_project_btn"),
        ) {
          Text("Delete")
        }
      },
      dismissButton = {
        TextButton(onClick = { deleteTarget = null }) { Text("Cancel") }
      },
    )
  }

  uiState.inspectedProject?.let { project ->
    ModalBottomSheet(onDismissRequest = { viewModel.inspectProject(null) }) {
      ProjectMetadataAndHistorySheet(
        project = project,
        filesCount = uiState.inspectedProjectFiles.size,
        totalLines = uiState.inspectedProjectFiles.sumOf { it.content.lines().size },
        history = uiState.inspectedProjectHistory,
        onSaveMetadata = { name, pkg, desc, ver, minSdk ->
          viewModel.updateMetadata(project, name, pkg, desc, ver, minSdk)
        },
        onClose = { viewModel.inspectProject(null) },
      )
    }
  }
}

@Composable
private fun CreateProjectFullDialog(
  initialTemplate: ProjectTemplateType,
  onDismiss: () -> Unit,
  onCreate: (String, String, String, ProjectTemplateType, Int) -> Unit,
) {
  var name by remember { mutableStateOf("") }
  var pkg by remember { mutableStateOf("com.androidlab.app") }
  var description by remember { mutableStateOf("") }
  var template by remember { mutableStateOf(initialTemplate) }
  var minSdkText by remember { mutableStateOf("26") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Create Studio Project") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("Project Name *") },
          placeholder = { Text("e.g. QuantumWeather") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("create_project_name_input"),
        )
        OutlinedTextField(
          value = pkg,
          onValueChange = { pkg = it },
          label = { Text("Package Name") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          label = { Text("Description") },
          maxLines = 2,
          modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
          value = minSdkText,
          onValueChange = { minSdkText = it.filter(Char::isDigit).take(2) },
          label = { Text("Min SDK (e.g. 26)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        Text("Template", style = MaterialTheme.typography.labelMedium)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(ProjectTemplateType.entries) { tpl ->
            FilterChip(
              selected = template == tpl,
              onClick = { template = tpl },
              label = { Text(tpl.title) },
            )
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onCreate(
            name,
            pkg,
            description,
            template,
            minSdkText.toIntOrNull()?.coerceIn(21, 36) ?: 26,
          )
        },
        enabled = name.isNotBlank(),
        modifier = Modifier.testTag("create_project_submit_btn"),
      ) {
        Text("Create")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Cancel") }
    },
  )
}

@Composable
private fun ProjectMetadataAndHistorySheet(
  project: ProjectEntity,
  filesCount: Int,
  totalLines: Int,
  history: List<com.example.data.local.ActivityLogEntity>,
  onSaveMetadata: (String, String, String, String, Int) -> Unit,
  onClose: () -> Unit,
) {
  var name by remember(project.id) { mutableStateOf(project.name) }
  var pkg by remember(project.id) { mutableStateOf(project.packageName) }
  var desc by remember(project.id) { mutableStateOf(project.description) }
  var ver by remember(project.id) { mutableStateOf(project.versionName) }
  var minSdk by remember(project.id) { mutableStateOf(project.minSdk.toString()) }

  LazyColumn(
    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
    contentPadding = PaddingValues(bottom = 28.dp),
  ) {
    item {
      Text("Project Metadata & History", style = MaterialTheme.typography.headlineSmall)
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = "$filesCount file(s) • $totalLines lines of code • Template: ${project.templateType}",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.secondary,
      )
    }
    item {
      OutlinedTextField(
        value = name,
        onValueChange = { name = it },
        label = { Text("Name") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
      )
    }
    item {
      OutlinedTextField(
        value = pkg,
        onValueChange = { pkg = it },
        label = { Text("Package Name") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
      )
    }
    item {
      Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
          value = ver,
          onValueChange = { ver = it },
          label = { Text("Version") },
          singleLine = true,
          modifier = Modifier.weight(1f),
        )
        OutlinedTextField(
          value = minSdk,
          onValueChange = { minSdk = it.filter(Char::isDigit).take(2) },
          label = { Text("Min SDK") },
          singleLine = true,
          modifier = Modifier.weight(1f),
        )
      }
    }
    item {
      OutlinedTextField(
        value = desc,
        onValueChange = { desc = it },
        label = { Text("Description") },
        maxLines = 3,
        modifier = Modifier.fillMaxWidth(),
      )
    }
    item {
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedButton(onClick = onClose, modifier = Modifier.weight(1f).height(48.dp)) {
          Text("Close")
        }
        Button(
          onClick = {
            onSaveMetadata(name, pkg, desc, ver, minSdk.toIntOrNull() ?: 26)
            onClose()
          },
          modifier = Modifier.weight(1f).height(48.dp),
        ) {
          Text("Save Metadata")
        }
      }
    }
    item {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.History, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("Revision History", style = MaterialTheme.typography.titleMedium)
      }
    }
    if (history.isEmpty()) {
      item {
        Text(
          "No recorded revisions for this project yet.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    } else {
      items(history) { entry ->
        val ts =
          SimpleDateFormat("MMM dd HH:mm:ss", Locale.getDefault()).format(Date(entry.timestampMs))
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Text(entry.title, style = MaterialTheme.typography.labelLarge)
              Text(ts, style = MaterialTheme.typography.labelSmall)
            }
            Text(
              entry.detail,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      }
    }
  }
}
