package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
  entities =
    [
      ProjectEntity::class,
      ProjectFileEntity::class,
      ActivityLogEntity::class,
      AiConversationEntity::class,
      AiMessageEntity::class,
      CustomPromptEntity::class,
      DiagnosticLogEntity::class,
    ],
  version = 1,
  exportSchema = false,
)
abstract class AndroidLabDatabase : RoomDatabase() {
  abstract fun projectDao(): ProjectDao

  abstract fun projectFileDao(): ProjectFileDao

  abstract fun activityLogDao(): ActivityLogDao

  abstract fun aiStudioDao(): AiStudioDao

  abstract fun diagnosticLogDao(): DiagnosticLogDao

  companion object {
    fun build(context: Context): AndroidLabDatabase {
      return Room.databaseBuilder(
          context.applicationContext,
          AndroidLabDatabase::class.java,
          "android_lab_studio_v2.db",
        )
        .fallbackToDestructiveMigration(dropAllTables = true)
        .build()
    }
  }
}
