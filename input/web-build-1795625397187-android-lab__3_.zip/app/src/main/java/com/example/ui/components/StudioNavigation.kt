package com.example.ui.components

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.FolderCopy
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.FolderCopy
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination
import androidx.navigation.NavDestination.Companion.hasRoute
import com.example.R
import com.example.ui.theme.LocalStudioColors
import kotlinx.serialization.Serializable

@Serializable sealed interface StudioRoute

@Serializable data object HomeRoute : StudioRoute

@Serializable data object ProjectsRoute : StudioRoute

@Serializable data object AiStudioRoute : StudioRoute

@Serializable data object ToolsRoute : StudioRoute

@Serializable data object SettingsRoute : StudioRoute

data class StudioNavTab(
  val route: StudioRoute,
  val labelRes: Int,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
  val testTag: String,
)

val StudioNavTabs =
  listOf(
    StudioNavTab(
      route = HomeRoute,
      labelRes = R.string.nav_home,
      selectedIcon = Icons.Filled.Home,
      unselectedIcon = Icons.Outlined.Home,
      testTag = "nav_home",
    ),
    StudioNavTab(
      route = ProjectsRoute,
      labelRes = R.string.nav_projects,
      selectedIcon = Icons.Filled.FolderCopy,
      unselectedIcon = Icons.Outlined.FolderCopy,
      testTag = "nav_projects",
    ),
    StudioNavTab(
      route = AiStudioRoute,
      labelRes = R.string.nav_ai_studio,
      selectedIcon = Icons.Filled.AutoAwesome,
      unselectedIcon = Icons.Outlined.AutoAwesome,
      testTag = "nav_ai_studio",
    ),
    StudioNavTab(
      route = ToolsRoute,
      labelRes = R.string.nav_tools,
      selectedIcon = Icons.Filled.Code,
      unselectedIcon = Icons.Outlined.Code,
      testTag = "nav_tools",
    ),
    StudioNavTab(
      route = SettingsRoute,
      labelRes = R.string.nav_settings,
      selectedIcon = Icons.Filled.Settings,
      unselectedIcon = Icons.Outlined.Settings,
      testTag = "nav_settings",
    ),
  )

@Composable
fun StudioBottomBar(
  currentDestination: NavDestination?,
  onSelectTab: (StudioRoute) -> Unit,
) {
  val studio = LocalStudioColors.current
  NavigationBar(
    containerColor = studio.glassFill,
    tonalElevation = 0.dp,
    windowInsets = WindowInsets(0, 0, 0, 0),
    modifier =
      Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        .clip(RoundedCornerShape(24.dp)),
  ) {
    StudioNavTabs.forEach { tab ->
      val selected = currentDestination?.hasRoute(tab.route::class) == true
      val label = stringResource(tab.labelRes)
      NavigationBarItem(
        selected = selected,
        onClick = { onSelectTab(tab.route) },
        modifier = Modifier.testTag(tab.testTag),
        icon = {
          Icon(
            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
            contentDescription = label,
            modifier = Modifier.size(22.dp),
          )
        },
        label = {
          Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        },
        colors =
          NavigationBarItemDefaults.colors(
            selectedIconColor = MaterialTheme.colorScheme.primary,
            selectedTextColor = MaterialTheme.colorScheme.primary,
            indicatorColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
          ),
      )
    }
  }
}

@Composable
fun StudioNavigationRail(
  currentDestination: NavDestination?,
  onSelectTab: (StudioRoute) -> Unit,
) {
  val studio = LocalStudioColors.current
  NavigationRail(
    containerColor = studio.glassFill,
    modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
  ) {
    StudioNavTabs.forEach { tab ->
      val selected = currentDestination?.hasRoute(tab.route::class) == true
      val label = stringResource(tab.labelRes)
      NavigationRailItem(
        selected = selected,
        onClick = { onSelectTab(tab.route) },
        modifier = Modifier.testTag(tab.testTag),
        icon = {
          Icon(
            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
            contentDescription = label,
          )
        },
        label = { Text(text = label, maxLines = 1) },
        colors =
          NavigationRailItemDefaults.colors(
            selectedIconColor = MaterialTheme.colorScheme.primary,
            selectedTextColor = MaterialTheme.colorScheme.primary,
            indicatorColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
          ),
      )
    }
  }
}
