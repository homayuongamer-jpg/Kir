package com.example.data.repository

import com.example.core.preferences.StudioPreferencesRepository
import com.example.core.templates.ExportedFileDto
import com.example.core.templates.ExportedProjectBundle
import com.example.core.templates.ProjectBundleSerializer
import com.example.core.templates.ProjectTemplateType
import com.example.core.templates.ProjectTemplates
import com.example.data.local.ProjectDao
import com.example.data.local.ProjectEntity
import com.example.data.local.ProjectFileDao
import com.example.data.local.ProjectFileEntity
import kotlinx.coroutines.flow.Flow

class ProjectRepository(
  private val projectDao: ProjectDao,
  private val projectFileDao: ProjectFileDao,
  private val preferencesRepository: StudioPreferencesRepository,
  private val diagnosticsRepository: DiagnosticsRepository,
) {
  val allProjects: Flow<List<ProjectEntity>> = projectDao.observeAllProjects()
  val projectCount: Flow<Int> = projectDao.observeProjectCount()
  val totalFileCount: Flow<Int> = projectFileDao.observeTotalFileCount()

  fun observeProject(projectId: Long): Flow<ProjectEntity?> =
    projectDao.observeProjectById(projectId)

  fun observeProjectFiles(projectId: Long): Flow<List<ProjectFileEntity>> =
    projectFileDao.observeFilesForProject(projectId)

  suspend fun getProjectFiles(projectId: Long): List<ProjectFileEntity> =
    projectFileDao.getFilesForProject(projectId)

  suspend fun ensureInitialSeed() {
    if (projectDao.countProjects() == 0) {
      val id =
        createProjectFromTemplate(
          name = "PulseCompose",
          packageName = "com.androidlab.pulse",
          description = "Futuristic Material 3 starter workspace created for Android Lab 2.0",
          template = ProjectTemplateType.COMPOSE_M3,
          minSdk = 26,
          silent = true,
        )
      preferencesRepository.setActiveProjectId(id)
      diagnosticsRepository.logDiagnostic(
        level = "INFO",
        tag = "Workspace",
        message = "Initialized starter workspace 'PulseCompose' (API 26+)",
      )
    }
  }

  suspend fun createProjectFromTemplate(
    name: String,
    packageName: String,
    description: String,
    template: ProjectTemplateType,
    minSdk: Int = 26,
    silent: Boolean = false,
  ): Long {
    val cleanName = name.trim().ifBlank { "UntitledStudioApp" }
    val cleanPkg = packageName.trim().ifBlank { "com.androidlab.app" }
    val now = System.currentTimeMillis()
    val projectId =
      projectDao.insertProject(
        ProjectEntity(
          name = cleanName,
          packageName = cleanPkg,
          description = description.trim().ifBlank { template.subtitle },
          templateType = template.id,
          minSdk = minSdk,
          versionName = "1.0",
          createdAtMs = now,
          updatedAtMs = now,
        )
      )

    val specs = ProjectTemplates.generateFilesForTemplate(template, cleanName, cleanPkg, minSdk)
    val entities =
      specs.map { spec ->
        ProjectFileEntity(
          projectId = projectId,
          name = spec.name,
          relativePath = spec.relativePath,
          fileType = spec.fileType,
          content = spec.content,
          updatedAtMs = now,
        )
      }
    projectFileDao.insertFiles(entities)
    preferencesRepository.setActiveProjectId(projectId)

    if (!silent) {
      diagnosticsRepository.logActivity(
        category = "PROJECT",
        title = "Created $cleanName",
        detail = "Template: ${template.title} (${entities.size} files)",
        projectId = projectId,
      )
      diagnosticsRepository.logDiagnostic(
        level = "INFO",
        tag = "ProjectManager",
        message = "Created project '$cleanName' [$cleanPkg] with ${entities.size} files",
      )
    }
    return projectId
  }

  suspend fun updateProjectMetadata(
    project: ProjectEntity,
    newName: String,
    newPackage: String,
    newDescription: String,
    newVersion: String,
    newMinSdk: Int,
  ) {
    val updated =
      project.copy(
        name = newName.trim().ifBlank { project.name },
        packageName = newPackage.trim().ifBlank { project.packageName },
        description = newDescription.trim(),
        versionName = newVersion.trim().ifBlank { project.versionName },
        minSdk = newMinSdk.coerceIn(21, 36),
        updatedAtMs = System.currentTimeMillis(),
      )
    projectDao.updateProject(updated)
    diagnosticsRepository.logActivity(
      category = "PROJECT",
      title = "Updated ${updated.name}",
      detail = "Metadata updated (v${updated.versionName}, minSdk ${updated.minSdk})",
      projectId = updated.id,
    )
  }

  suspend fun renameProject(project: ProjectEntity, newName: String) {
    val trimmed = newName.trim()
    if (trimmed.isEmpty() || trimmed == project.name) return
    val oldName = project.name
    projectDao.updateProject(project.copy(name = trimmed, updatedAtMs = System.currentTimeMillis()))
    diagnosticsRepository.logActivity(
      category = "PROJECT",
      title = "Renamed project",
      detail = "$oldName → $trimmed",
      projectId = project.id,
    )
  }

  suspend fun deleteProject(project: ProjectEntity) {
    projectDao.deleteProjectById(project.id)
    diagnosticsRepository.logActivity(
      category = "PROJECT",
      title = "Deleted ${project.name}",
      detail = "Removed workspace and associated source files",
      projectId = null,
    )
    diagnosticsRepository.logDiagnostic(
      level = "WARN",
      tag = "ProjectManager",
      message = "Deleted project '${project.name}'",
    )
  }

  suspend fun openProject(projectId: Long) {
    preferencesRepository.setActiveProjectId(projectId)
    val project = projectDao.getProjectById(projectId)
    if (project != null) {
      diagnosticsRepository.logActivity(
        category = "PROJECT",
        title = "Opened ${project.name}",
        detail = "Loaded into Developer Toolkit",
        projectId = projectId,
      )
    }
  }

  suspend fun createOrUpdateFile(
    projectId: Long,
    fileName: String,
    relativePath: String,
    fileType: String,
    content: String,
  ): Long {
    val existing =
      projectFileDao.getFilesForProject(projectId).find {
        it.name.equals(fileName.trim(), ignoreCase = true)
      }
    val now = System.currentTimeMillis()
    val fileId =
      if (existing != null) {
        projectFileDao.updateFile(existing.copy(content = content, updatedAtMs = now))
        existing.id
      } else {
        projectFileDao.insertFile(
          ProjectFileEntity(
            projectId = projectId,
            name = fileName.trim(),
            relativePath = relativePath.trim().ifBlank { fileName.trim() },
            fileType = fileType,
            content = content,
            updatedAtMs = now,
          )
        )
      }
    projectDao.getProjectById(projectId)?.let { proj ->
      projectDao.updateProject(proj.copy(updatedAtMs = now))
    }
    diagnosticsRepository.logActivity(
      category = "TOOLKIT",
      title = if (existing != null) "Saved ${fileName.trim()}" else "Added ${fileName.trim()}",
      detail = "Updated ${content.lines().size} lines in workspace",
      projectId = projectId,
    )
    return fileId
  }

  suspend fun saveFileContent(file: ProjectFileEntity, newContent: String) {
    val now = System.currentTimeMillis()
    projectFileDao.updateFile(file.copy(content = newContent, updatedAtMs = now))
    projectDao.getProjectById(file.projectId)?.let { proj ->
      projectDao.updateProject(proj.copy(updatedAtMs = now))
    }
    diagnosticsRepository.logActivity(
      category = "TOOLKIT",
      title = "Edited ${file.name}",
      detail = "${newContent.lines().size} lines • ${newContent.length} chars",
      projectId = file.projectId,
    )
  }

  suspend fun deleteFile(file: ProjectFileEntity) {
    projectFileDao.deleteFileById(file.id)
    diagnosticsRepository.logActivity(
      category = "TOOLKIT",
      title = "Removed ${file.name}",
      detail = "Deleted from project workspace",
      projectId = file.projectId,
    )
  }

  suspend fun exportProjectBundleJson(projectId: Long): Result<Pair<String, String>> = runCatching {
    val project = projectDao.getProjectById(projectId) ?: error("Project not found")
    val files = projectFileDao.getFilesForProject(projectId)
    val bundle =
      ExportedProjectBundle(
        name = project.name,
        packageName = project.packageName,
        description = project.description,
        templateType = project.templateType,
        minSdk = project.minSdk,
        versionName = project.versionName,
        exportedAtMs = System.currentTimeMillis(),
        files =
          files.map {
            ExportedFileDto(
              name = it.name,
              relativePath = it.relativePath,
              fileType = it.fileType,
              content = it.content,
            )
          },
      )
    val json = ProjectBundleSerializer.encode(bundle)
    diagnosticsRepository.logActivity(
      category = "PROJECT",
      title = "Exported ${project.name}",
      detail = "Bundle JSON with ${files.size} files",
      projectId = projectId,
    )
    val safeName = project.name.replace(Regex("[^A-Za-z0-9_-]"), "_").lowercase()
    "${safeName}_androidlab_bundle.json" to json
  }

  suspend fun importContentIntoWorkspace(
    fileName: String,
    rawContent: String,
    targetProjectId: Long?,
  ): Result<String> = runCatching {
    val trimmed = rawContent.trim()
    // Check if it is an Android Lab bundle JSON first
    if (fileName.endsWith(".json", ignoreCase = true) && trimmed.contains("\"exportedBy\"")) {
      val bundleResult = ProjectBundleSerializer.decode(trimmed)
      if (bundleResult.isSuccess) {
        val bundle = bundleResult.getOrThrow()
        val now = System.currentTimeMillis()
        val newProjId =
          projectDao.insertProject(
            ProjectEntity(
              name = bundle.name,
              packageName = bundle.packageName,
              description = bundle.description,
              templateType = bundle.templateType,
              minSdk = bundle.minSdk,
              versionName = bundle.versionName,
              createdAtMs = now,
              updatedAtMs = now,
            )
          )
        val importedFiles =
          bundle.files.map { dto ->
            ProjectFileEntity(
              projectId = newProjId,
              name = dto.name,
              relativePath = dto.relativePath,
              fileType = dto.fileType,
              content = dto.content,
              updatedAtMs = now,
            )
          }
        projectFileDao.insertFiles(importedFiles)
        preferencesRepository.setActiveProjectId(newProjId)
        diagnosticsRepository.logActivity(
          category = "PROJECT",
          title = "Imported ${bundle.name}",
          detail = "Bundle restored with ${importedFiles.size} files",
          projectId = newProjId,
        )
        return@runCatching "Imported project '${bundle.name}' (${importedFiles.size} files)."
      }
    }

    // Otherwise import as a source file into targetProjectId
    val projId =
      targetProjectId
        ?: projectDao.getProjectById(1L)?.id
        ?: createProjectFromTemplate(
          name = "ImportedWorkspace",
          packageName = "com.androidlab.imported",
          description = "Workspace created for imported file",
          template = ProjectTemplateType.EMPTY_STUDIO,
        )
    val inferredType = inferFileType(fileName)
    createOrUpdateFile(
      projectId = projId,
      fileName = fileName,
      relativePath = fileName,
      fileType = inferredType,
      content = rawContent,
    )
    "Imported '$fileName' into active project."
  }

  fun inferFileType(fileName: String): String {
    val lower = fileName.lowercase()
    return when {
      lower.endsWith(".kt") || lower.endsWith(".java") -> "kotlin"
      lower.endsWith(".kts") || lower.endsWith(".gradle") -> "gradle"
      lower.endsWith(".xml") -> "xml"
      lower.endsWith(".json") -> "json"
      else -> "markdown"
    }
  }
}
