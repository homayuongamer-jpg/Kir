package com.example.ui.screens.tools

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.FormatAlignLeft
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.core.analyzer.IssueSeverity
import com.example.core.templates.ProjectTemplates
import com.example.ui.components.CodeDisplayBox
import com.example.ui.components.GlassCard
import com.example.ui.components.StatusPill
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioColors
import com.example.ui.theme.VioletNeon
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ToolsScreen(
  viewModel: ToolsViewModel,
  onSendErrorToAi: (String) -> Unit,
) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val studio = LocalStudioColors.current
  val clipboard = LocalClipboardManager.current

  var showProjectSwitcher by remember { mutableStateOf(false) }
  var showNewFileDialog by remember { mutableStateOf(false) }
  var logFilter by remember { mutableStateOf("ALL") }
  var logSearch by remember { mutableStateOf("") }

  LaunchedEffect(uiState.activeProject?.id) {
    if (uiState.activeProject != null && uiState.analysisReport == null) {
      viewModel.runStaticAnalysis()
    }
  }

  Column(modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp)) {
    // Top Header + Project Switcher
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = stringResource(R.string.tools_title),
          style = MaterialTheme.typography.headlineMedium,
          color = MaterialTheme.colorScheme.onBackground,
        )
        Box {
          AssistChip(
            onClick = { showProjectSwitcher = true },
            label = {
              Text(
                text = uiState.activeProject?.name ?: "No Project",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            },
            leadingIcon = {
              Icon(Icons.Filled.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
            },
          )
          DropdownMenu(
            expanded = showProjectSwitcher,
            onDismissRequest = { showProjectSwitcher = false },
          ) {
            uiState.projects.forEach { proj ->
              DropdownMenuItem(
                text = { Text("${proj.name} (${proj.packageName})") },
                onClick = {
                  viewModel.switchProject(proj.id)
                  showProjectSwitcher = false
                },
              )
            }
          }
        }
      }
      OutlinedButton(
        onClick = {
          viewModel.runStaticAnalysis()
          viewModel.selectTab(ToolkitTab.BUILD_ERRORS)
        },
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.height(48.dp).testTag("tools_run_checks_btn"),
      ) {
        Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("Check")
      }
    }

    // Toolkit Sub-Tabs
    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.padding(vertical = 8.dp),
    ) {
      items(ToolkitTab.entries) { tab ->
        val badgeCount =
          when (tab) {
            ToolkitTab.BUILD_ERRORS -> uiState.analysisReport?.issues?.size ?: 0
            ToolkitTab.FILES -> uiState.projectFiles.size
            else -> 0
          }
        FilterChip(
          selected = uiState.selectedTab == tab,
          onClick = { viewModel.selectTab(tab) },
          label = {
            Text(if (badgeCount > 0) "${tab.label} ($badgeCount)" else tab.label)
          },
          modifier = Modifier.testTag("toolkit_tab_${tab.name}"),
        )
      }
    }

    if (!uiState.statusMessage.isNullOrBlank()) {
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.secondaryContainer,
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = uiState.statusMessage.orEmpty(),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSecondaryContainer,
            modifier = Modifier.weight(1f),
          )
          TextButton(onClick = { viewModel.clearStatus() }) { Text("OK") }
        }
      }
    }

    // Active Toolkit Panel
    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
      when (uiState.selectedTab) {
        ToolkitTab.FILES -> {
          FileBrowserPane(
            uiState = uiState,
            onCreateFile = { showNewFileDialog = true },
            onSelectFile = { viewModel.openFile(it, switchToEditor = true) },
            onDeleteFile = { viewModel.deleteFile(it) },
          )
        }
        ToolkitTab.EDITOR -> {
          CodeEditorPane(
            uiState = uiState,
            onSelectFile = { viewModel.openFile(it, switchToEditor = false) },
            onDraftChange = { viewModel.updateDraft(it) },
            onSave = { viewModel.saveActiveFile() },
            onTogglePreview = { viewModel.togglePreviewMode() },
            onCopy = {
              clipboard.setText(AnnotatedString(uiState.editorDraft))
            },
            onFormatJson = { minify -> viewModel.formatCurrentJson(minify) },
            onValidateXml = { viewModel.validateCurrentXml() },
            onAskAi = {
              val file = uiState.selectedFile
              if (file != null) {
                onSendErrorToAi(
                  "Review or improve `${file.name}`:\n```${file.fileType}\n${uiState.editorDraft.take(2000)}\n```"
                )
              }
            },
          )
        }
        ToolkitTab.SNIPPETS -> {
          SnippetsPane(
            onCopy = { code -> clipboard.setText(AnnotatedString(code)) },
            onInsert = { code -> viewModel.insertSnippetIntoEditor(code) },
          )
        }
        ToolkitTab.LOGS -> {
          LogsViewerPane(
            logs = uiState.diagnosticLogs,
            selectedLevel = logFilter,
            searchQuery = logSearch,
            onLevelChange = { logFilter = it },
            onSearchChange = { logSearch = it },
            onClear = { viewModel.clearDiagnosticLogs() },
          )
        }
        ToolkitTab.BUILD_ERRORS -> {
          BuildStatusAndErrorsPane(
            uiState = uiState,
            onRunChecks = { viewModel.runStaticAnalysis() },
            onJumpToFile = { fileId ->
              uiState.projectFiles.find { it.id == fileId }?.let { file ->
                viewModel.openFile(file, switchToEditor = true)
              }
            },
            onDebugWithAi = { issueText -> onSendErrorToAi(issueText) },
          )
        }
      }
    }
  }

  if (showNewFileDialog) {
    NewWorkspaceFileDialog(
      onDismiss = { showNewFileDialog = false },
      onCreate = { name, type ->
        viewModel.createNewFile(name, type)
        showNewFileDialog = false
      },
    )
  }
}

@Composable
private fun FileBrowserPane(
  uiState: ToolsUiState,
  onCreateFile: () -> Unit,
  onSelectFile: (com.example.data.local.ProjectFileEntity) -> Unit,
  onDeleteFile: (com.example.data.local.ProjectFileEntity) -> Unit,
) {
  val studio = LocalStudioColors.current
  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(10.dp),
    contentPadding = PaddingValues(bottom = 16.dp),
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "Workspace File Tree (${uiState.projectFiles.size})",
          style = MaterialTheme.typography.titleMedium,
        )
        Button(
          onClick = onCreateFile,
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.height(48.dp).testTag("tools_add_file_btn"),
        ) {
          Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("New File")
        }
      }
    }
    items(uiState.projectFiles, key = { it.id }) { file ->
      val isSelected = file.id == uiState.selectedFile?.id
      val typeColor =
        when (file.fileType) {
          "kotlin" -> VioletNeon
          "xml" -> ElectricBlue
          "json" -> studio.warning
          else -> studio.success
        }
      GlassCard(onClick = { onSelectFile(file) }, contentPadding = PaddingValues(14.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Icon(Icons.Filled.Description, contentDescription = null, tint = typeColor)
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(file.name, style = MaterialTheme.typography.titleSmall)
                if (isSelected) {
                  Spacer(modifier = Modifier.width(6.dp))
                  StatusPill("OPEN", studio.success)
                }
              }
              Text(
                text = "${file.relativePath} • ${file.content.lines().size} lines • ${file.fileType.uppercase()}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
          IconButton(onClick = { onDeleteFile(file) }) {
            Icon(Icons.Filled.Delete, contentDescription = "Delete ${file.name}", tint = studio.error)
          }
        }
      }
    }
  }
}

@Composable
private fun CodeEditorPane(
  uiState: ToolsUiState,
  onSelectFile: (com.example.data.local.ProjectFileEntity) -> Unit,
  onDraftChange: (String) -> Unit,
  onSave: () -> Unit,
  onTogglePreview: () -> Unit,
  onCopy: () -> Unit,
  onFormatJson: (Boolean) -> Unit,
  onValidateXml: () -> Unit,
  onAskAi: () -> Unit,
) {
  val studio = LocalStudioColors.current
  val activeFile = uiState.selectedFile

  if (activeFile == null) {
    GlassCard {
      Text("No file selected. Open or create a file in the Files tab.")
    }
    return
  }

  Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    // Quick open file tabs
    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
      items(uiState.projectFiles, key = { it.id }) { file ->
        FilterChip(
          selected = file.id == activeFile.id,
          onClick = { onSelectFile(file) },
          label = { Text(file.name) },
        )
      }
    }

    // Toolbar for Kotlin / XML / JSON actions
    Row(
      modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(6.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Button(
        onClick = onSave,
        enabled = uiState.hasUnsavedChanges,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.height(44.dp).testTag("editor_save_btn"),
      ) {
        Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(if (uiState.hasUnsavedChanges) "Save*" else "Saved")
      }
      OutlinedButton(
        onClick = onTogglePreview,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.height(44.dp),
      ) {
        Icon(
          if (uiState.isPreviewMode) Icons.Filled.Edit else Icons.Filled.Visibility,
          contentDescription = null,
          modifier = Modifier.size(16.dp),
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(if (uiState.isPreviewMode) "Edit" else "Syntax View")
      }
      if (activeFile.fileType.equals("json", ignoreCase = true)) {
        OutlinedButton(
          onClick = { onFormatJson(false) },
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.height(44.dp),
        ) {
          Icon(Icons.Filled.FormatAlignLeft, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Format")
        }
        OutlinedButton(
          onClick = { onFormatJson(true) },
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.height(44.dp),
        ) {
          Text("Minify")
        }
      }
      if (activeFile.fileType.equals("xml", ignoreCase = true)) {
        OutlinedButton(
          onClick = onValidateXml,
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.height(44.dp),
        ) {
          Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Validate XML")
        }
      }
      OutlinedButton(
        onClick = onCopy,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.height(44.dp),
      ) {
        Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
      }
      OutlinedButton(
        onClick = onAskAi,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.height(44.dp),
      ) {
        Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("AI")
      }
    }

    // Editor or Syntax Preview Surface
    if (uiState.isPreviewMode) {
      Box(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {
        CodeDisplayBox(code = uiState.editorDraft, fileType = activeFile.fileType)
      }
    } else {
      Surface(
        modifier = Modifier.weight(1f).fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = studio.codeSurface,
        border = BorderStroke(1.dp, studio.codeBorder),
      ) {
        val scrollState = rememberScrollState()
        val linesCount = uiState.editorDraft.lines().size.coerceAtLeast(1)
        Row(modifier = Modifier.fillMaxSize().verticalScroll(scrollState).padding(12.dp)) {
          Column(modifier = Modifier.padding(end = 10.dp)) {
            for (lineNum in 1..linesCount) {
              Text(
                text = lineNum.toString().padStart(2, ' '),
                fontFamily = JetBrainsMonoFontFamily,
                fontSize = 13.sp,
                lineHeight = 20.sp,
                color = Color(0xFF475569),
              )
            }
          }
          BasicTextField(
            value = uiState.editorDraft,
            onValueChange = onDraftChange,
            textStyle =
              TextStyle(
                fontFamily = JetBrainsMonoFontFamily,
                fontSize = 13.sp,
                lineHeight = 20.sp,
                color = Color(0xFFE2E8F0),
              ),
            cursorBrush = SolidColor(ElectricBlue),
            modifier = Modifier.weight(1f).testTag("code_editor_textfield"),
          )
        }
      }

      // Quick symbol bar for coding comfort on mobile
      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        listOf("{ }", "( )", "->", "val ", "fun ", "    ", "< />").forEach { sym ->
          AssistChip(
            onClick = { onDraftChange(uiState.editorDraft + sym) },
            label = { Text(sym.trim().ifEmpty { "TAB" }, fontFamily = JetBrainsMonoFontFamily) },
          )
        }
      }
    }
  }
}

@Composable
private fun SnippetsPane(
  onCopy: (String) -> Unit,
  onInsert: (String) -> Unit,
) {
  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(12.dp),
    contentPadding = PaddingValues(bottom = 16.dp),
  ) {
    items(ProjectTemplates.builtInSnippets, key = { it.id }) { snippet ->
      GlassCard {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            StatusPill(text = snippet.category, dotColor = ElectricBlue)
            Spacer(modifier = Modifier.height(6.dp))
            Text(snippet.title, style = MaterialTheme.typography.titleMedium)
            Text(
              snippet.description,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
        Spacer(modifier = Modifier.height(10.dp))
        CodeDisplayBox(code = snippet.code, fileType = snippet.fileType, showLineNumbers = false)
        Spacer(modifier = Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedButton(
            onClick = { onCopy(snippet.code) },
            modifier = Modifier.height(44.dp),
          ) {
            Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Copy")
          }
          Button(
            onClick = { onInsert(snippet.code) },
            modifier = Modifier.height(44.dp),
          ) {
            Icon(Icons.Filled.Code, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Insert in Editor")
          }
        }
      }
    }
  }
}

@Composable
private fun LogsViewerPane(
  logs: List<com.example.data.local.DiagnosticLogEntity>,
  selectedLevel: String,
  searchQuery: String,
  onLevelChange: (String) -> Unit,
  onSearchChange: (String) -> Unit,
  onClear: () -> Unit,
) {
  val studio = LocalStudioColors.current
  val filtered =
    remember(logs, selectedLevel, searchQuery) {
      logs.filter { log ->
        (selectedLevel == "ALL" || log.level.equals(selectedLevel, ignoreCase = true)) &&
          (searchQuery.isBlank() ||
            log.message.contains(searchQuery, ignoreCase = true) ||
            log.tag.contains(searchQuery, ignoreCase = true))
      }
    }

  Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = onSearchChange,
        placeholder = { Text("Filter logs...") },
        singleLine = true,
        modifier = Modifier.weight(1f),
      )
      OutlinedButton(onClick = onClear, modifier = Modifier.height(48.dp)) { Text("Clear") }
    }
    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
      items(listOf("ALL", "INFO", "AI", "WARN", "ERROR")) { lvl ->
        FilterChip(
          selected = selectedLevel == lvl,
          onClick = { onLevelChange(lvl) },
          label = { Text(lvl) },
        )
      }
    }
    LazyColumn(
      modifier = Modifier.weight(1f).fillMaxWidth(),
      verticalArrangement = Arrangement.spacedBy(6.dp),
      contentPadding = PaddingValues(bottom = 16.dp),
    ) {
      if (filtered.isEmpty()) {
        item {
          GlassCard {
            Text(
              "No diagnostic logs match the current filter.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      } else {
        items(filtered, key = { it.id }) { log ->
          val lvlColor =
            when (log.level) {
              "ERROR" -> studio.error
              "WARN" -> studio.warning
              "AI" -> VioletNeon
              else -> studio.success
            }
          val ts =
            SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(log.timestampMs))
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = studio.codeSurface,
            border = BorderStroke(1.dp, studio.codeBorder),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Text(
                  text = "[${log.level}] ${log.tag}",
                  fontFamily = JetBrainsMonoFontFamily,
                  fontSize = 11.sp,
                  color = lvlColor,
                )
                Text(
                  text = ts,
                  fontFamily = JetBrainsMonoFontFamily,
                  fontSize = 11.sp,
                  color = Color(0xFF64748B),
                )
              }
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = log.message,
                fontFamily = JetBrainsMonoFontFamily,
                fontSize = 12.sp,
                color = Color(0xFFE2E8F0),
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun BuildStatusAndErrorsPane(
  uiState: ToolsUiState,
  onRunChecks: () -> Unit,
  onJumpToFile: (Long) -> Unit,
  onDebugWithAi: (String) -> Unit,
) {
  val studio = LocalStudioColors.current
  val report = uiState.analysisReport

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(10.dp),
    contentPadding = PaddingValues(bottom = 16.dp),
  ) {
    item {
      GlassCard {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text("Static Build & Syntax Status", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text =
                "On-device static verification (Kotlin brace/structure, XmlPullParser, JSONTokener, and Manifest checks). Local APK compilation is not claimed on-device.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Button(onClick = onRunChecks, modifier = Modifier.height(48.dp)) { Text("Run") }
        }
        if (report != null) {
          Spacer(modifier = Modifier.height(12.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusPill("${report.filesChecked} Files", ElectricBlue)
            StatusPill(
              "${report.errorCount} Errors",
              if (report.errorCount > 0) studio.error else studio.success,
            )
            StatusPill(
              "${report.warningCount} Warn",
              if (report.warningCount > 0) studio.warning else studio.success,
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
          Text(report.summary, style = MaterialTheme.typography.bodySmall)
        }
      }
    }

    if (report != null && report.issues.isEmpty()) {
      item {
        GlassCard {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = studio.success)
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              "Zero syntax or structural issues detected across ${report.filesChecked} file(s).",
              style = MaterialTheme.typography.bodyMedium,
            )
          }
        }
      }
    } else if (report != null) {
      items(report.issues) { issue ->
        val color =
          when (issue.severity) {
            IssueSeverity.ERROR -> studio.error
            IssueSeverity.WARNING -> studio.warning
            IssueSeverity.INFO -> ElectricBlue
          }
        GlassCard(onClick = { if (issue.fileId > 0) onJumpToFile(issue.fileId) }) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            StatusPill("${issue.severity.name} • ${issue.ruleId}", color)
            Text(
              text = "${issue.fileName}:${issue.line}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.secondary,
            )
          }
          Spacer(modifier = Modifier.height(6.dp))
          Text(issue.message, style = MaterialTheme.typography.bodyMedium)
          Spacer(modifier = Modifier.height(8.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (issue.fileId > 0) {
              OutlinedButton(onClick = { onJumpToFile(issue.fileId) }) {
                Text("Open File")
              }
            }
            OutlinedButton(
              onClick = {
                onDebugWithAi(
                  "Fix this ${issue.severity.name} (${issue.ruleId}) in ${issue.fileName} at line ${issue.line}: ${issue.message}"
                )
              }
            ) {
              Icon(Icons.Filled.BugReport, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Debug with AI")
            }
          }
        }
      }
    }
  }
}

@Composable
private fun NewWorkspaceFileDialog(
  onDismiss: () -> Unit,
  onCreate: (String, String) -> Unit,
) {
  var fileName by remember { mutableStateOf("") }
  var fileType by remember { mutableStateOf("kotlin") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Create Workspace File") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
          value = fileName,
          onValueChange = { fileName = it },
          label = { Text("File Name (e.g. ProfileScreen.kt)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          items(listOf("kotlin", "xml", "json", "gradle")) { t ->
            FilterChip(
              selected = fileType == t,
              onClick = { fileType = t },
              label = { Text(t.uppercase()) },
            )
          }
        }
      }
    },
    confirmButton = {
      Button(onClick = { onCreate(fileName, fileType) }, enabled = fileName.isNotBlank()) {
        Text("Create")
      }
    },
    dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
  )
}
