package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
  @Query("SELECT * FROM projects ORDER BY updatedAtMs DESC")
  fun observeAllProjects(): Flow<List<ProjectEntity>>

  @Query("SELECT * FROM projects WHERE id = :id LIMIT 1")
  fun observeProjectById(id: Long): Flow<ProjectEntity?>

  @Query("SELECT * FROM projects WHERE id = :id LIMIT 1")
  suspend fun getProjectById(id: Long): ProjectEntity?

  @Query("SELECT COUNT(*) FROM projects")
  fun observeProjectCount(): Flow<Int>

  @Query("SELECT COUNT(*) FROM projects")
  suspend fun countProjects(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertProject(project: ProjectEntity): Long

  @Update
  suspend fun updateProject(project: ProjectEntity)

  @Query("DELETE FROM projects WHERE id = :id")
  suspend fun deleteProjectById(id: Long)
}

@Dao
interface ProjectFileDao {
  @Query("SELECT * FROM project_files WHERE projectId = :projectId ORDER BY fileType ASC, name ASC")
  fun observeFilesForProject(projectId: Long): Flow<List<ProjectFileEntity>>

  @Query("SELECT * FROM project_files WHERE projectId = :projectId ORDER BY fileType ASC, name ASC")
  suspend fun getFilesForProject(projectId: Long): List<ProjectFileEntity>

  @Query("SELECT * FROM project_files WHERE id = :fileId LIMIT 1")
  suspend fun getFileById(fileId: Long): ProjectFileEntity?

  @Query("SELECT COUNT(*) FROM project_files")
  fun observeTotalFileCount(): Flow<Int>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertFile(file: ProjectFileEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertFiles(files: List<ProjectFileEntity>)

  @Update
  suspend fun updateFile(file: ProjectFileEntity)

  @Query("DELETE FROM project_files WHERE id = :fileId")
  suspend fun deleteFileById(fileId: Long)
}

@Dao
interface ActivityLogDao {
  @Query("SELECT * FROM activity_logs ORDER BY timestampMs DESC LIMIT :limit")
  fun observeRecentActivities(limit: Int = 30): Flow<List<ActivityLogEntity>>

  @Query("SELECT * FROM activity_logs WHERE projectId = :projectId ORDER BY timestampMs DESC")
  fun observeProjectHistory(projectId: Long): Flow<List<ActivityLogEntity>>

  @Insert
  suspend fun insertActivity(log: ActivityLogEntity)

  @Query("DELETE FROM activity_logs")
  suspend fun clearAll()
}

@Dao
interface AiStudioDao {
  @Query("SELECT * FROM ai_conversations ORDER BY updatedAtMs DESC")
  fun observeConversations(): Flow<List<AiConversationEntity>>

  @Query("SELECT * FROM ai_messages WHERE conversationId = :conversationId ORDER BY timestampMs ASC")
  fun observeMessages(conversationId: Long): Flow<List<AiMessageEntity>>

  @Query("SELECT COUNT(*) FROM ai_messages WHERE role = 'user'")
  fun observeTotalPromptCount(): Flow<Int>

  @Insert
  suspend fun insertConversation(conversation: AiConversationEntity): Long

  @Query("UPDATE ai_conversations SET updatedAtMs = :updatedAtMs, title = :title WHERE id = :id")
  suspend fun updateConversationMeta(id: Long, title: String, updatedAtMs: Long)

  @Query("DELETE FROM ai_conversations WHERE id = :id")
  suspend fun deleteConversation(id: Long)

  @Query("DELETE FROM ai_conversations")
  suspend fun clearAllConversations()

  @Insert
  suspend fun insertMessage(message: AiMessageEntity): Long

  @Query("SELECT * FROM custom_prompts ORDER BY createdAtMs DESC")
  fun observeCustomPrompts(): Flow<List<CustomPromptEntity>>

  @Insert
  suspend fun insertCustomPrompt(prompt: CustomPromptEntity): Long

  @Query("DELETE FROM custom_prompts WHERE id = :id")
  suspend fun deleteCustomPrompt(id: Long)
}

@Dao
interface DiagnosticLogDao {
  @Query("SELECT * FROM diagnostic_logs ORDER BY timestampMs DESC LIMIT 200")
  fun observeLogs(): Flow<List<DiagnosticLogEntity>>

  @Insert
  suspend fun insertLog(log: DiagnosticLogEntity)

  @Query("DELETE FROM diagnostic_logs")
  suspend fun clearLogs()
}
