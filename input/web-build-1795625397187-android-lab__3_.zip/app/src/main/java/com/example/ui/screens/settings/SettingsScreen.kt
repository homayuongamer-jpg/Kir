package com.example.ui.screens.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.BuildConfig
import com.example.R
import com.example.core.preferences.ApiConnectionState
import com.example.core.preferences.AppLanguage
import com.example.core.preferences.GeminiModelOption
import com.example.core.preferences.ThemeMode
import com.example.ui.components.GlassCard
import com.example.ui.components.GradientActionButton
import com.example.ui.components.StatusPill
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.LocalStudioColors
import com.example.ui.theme.VioletNeon

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: SettingsViewModel) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val studio = LocalStudioColors.current

  var apiKeyInput by remember { mutableStateOf("") }
  var showKeyPlain by remember { mutableStateOf(false) }
  var confirmClearHistory by remember { mutableStateOf(false) }
  var confirmClearLogs by remember { mutableStateOf(false) }
  var showAboutSheet by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    item {
      Text(
        text = stringResource(R.string.settings_title),
        style = MaterialTheme.typography.headlineMedium,
        color = MaterialTheme.colorScheme.onBackground,
      )
      Text(
        text = "Configure studio theme, localization, Keystore credentials, and privacy",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }

    if (!uiState.statusMessage.isNullOrBlank()) {
      item {
        GlassCard(contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = uiState.statusMessage.orEmpty(),
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.primary,
              modifier = Modifier.weight(1f),
            )
            TextButton(onClick = { viewModel.clearStatus() }) { Text("OK") }
          }
        }
      }
    }

    // Appearance & Theme
    item {
      GlassCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Filled.Palette, contentDescription = null, tint = VioletNeon)
          Spacer(modifier = Modifier.width(8.dp))
          Text(stringResource(R.string.theme_section), style = MaterialTheme.typography.titleMedium)
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          ThemeMode.entries.forEach { mode ->
            FilterChip(
              selected = uiState.preferences.themeMode == mode,
              onClick = { viewModel.setThemeMode(mode) },
              label = { Text(mode.label) },
              modifier = Modifier.testTag("theme_mode_${mode.name}"),
            )
          }
        }
      }
    }

    // Language Selection
    item {
      GlassCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Filled.Language, contentDescription = null, tint = ElectricBlue)
          Spacer(modifier = Modifier.width(8.dp))
          Text(stringResource(R.string.language_section), style = MaterialTheme.typography.titleMedium)
        }
        Spacer(modifier = Modifier.height(10.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(AppLanguage.entries) { lang ->
            FilterChip(
              selected = uiState.preferences.language == lang,
              onClick = { viewModel.setLanguage(lang) },
              label = { Text(lang.displayName) },
              modifier = Modifier.testTag("lang_${lang.code}"),
            )
          }
        }
      }
    }

    // Gemini API Configuration & Keystore
    item {
      GlassCard {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Key, contentDescription = null, tint = VioletNeon)
            Spacer(modifier = Modifier.width(8.dp))
            Text(stringResource(R.string.gemini_section), style = MaterialTheme.typography.titleMedium)
          }
          StatusPill(
            text = if (uiState.keystoreReady) "KEYSTORE AES-256" else "KEYSTORE ERR",
            dotColor = if (uiState.keystoreReady) studio.success else studio.error,
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
        val connDot =
          when (uiState.preferences.apiConnectionState) {
            ApiConnectionState.VERIFIED -> studio.success
            ApiConnectionState.CONFIGURED_UNTESTED -> studio.warning
            ApiConnectionState.ERROR -> studio.error
            ApiConnectionState.NOT_CONFIGURED -> Color(0xFF94A3B8)
          }
        Row(verticalAlignment = Alignment.CenterVertically) {
          StatusPill(
            text =
              if (uiState.preferences.hasGeminiKey) {
                "Stored: ${uiState.preferences.maskedGeminiKey}"
              } else {
                "No API Key Saved"
              },
            dotColor = connDot,
          )
          if (uiState.preferences.lastLatencyMs > 0L) {
            Spacer(modifier = Modifier.width(8.dp))
            StatusPill("${uiState.preferences.lastLatencyMs}ms", ElectricBlue)
          }
        }
        if (uiState.preferences.lastConnectionMessage.isNotBlank()) {
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = uiState.preferences.lastConnectionMessage,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(
          value = apiKeyInput,
          onValueChange = { apiKeyInput = it },
          label = { Text("Enter Gemini API Key") },
          placeholder = { Text("AIza...") },
          singleLine = true,
          visualTransformation =
            if (showKeyPlain) VisualTransformation.None else PasswordVisualTransformation(),
          trailingIcon = {
            IconButton(onClick = { showKeyPlain = !showKeyPlain }) {
              Icon(
                if (showKeyPlain) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                contentDescription = "Toggle key visibility",
              )
            }
          },
          modifier = Modifier.fillMaxWidth().testTag("settings_gemini_key_input"),
        )
        Spacer(modifier = Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          GradientActionButton(
            text = "Encrypt & Save",
            icon = Icons.Filled.Lock,
            enabled = apiKeyInput.isNotBlank(),
            onClick = {
              viewModel.saveGeminiKey(apiKeyInput)
              apiKeyInput = ""
            },
            modifier = Modifier.weight(1f),
            testTag = "settings_save_key_btn",
          )
          OutlinedButton(
            onClick = { viewModel.testConnection() },
            enabled = uiState.preferences.hasGeminiKey && !uiState.isTestingConnection,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.height(48.dp).testTag("settings_test_connection_btn"),
          ) {
            if (uiState.isTestingConnection) {
              CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
            } else {
              Icon(Icons.Filled.NetworkCheck, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Test")
            }
          }
        }
        if (uiState.preferences.hasGeminiKey) {
          Spacer(modifier = Modifier.height(8.dp))
          TextButton(
            onClick = { viewModel.clearGeminiKey() },
            colors = ButtonDefaults.textButtonColors(contentColor = studio.error),
          ) {
            Icon(Icons.Filled.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Remove Stored API Key")
          }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text("Default Gemini Model", style = MaterialTheme.typography.labelMedium)
        Spacer(modifier = Modifier.height(6.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(GeminiModelOption.entries) { option ->
            FilterChip(
              selected = uiState.preferences.selectedModel == option,
              onClick = { viewModel.setModel(option) },
              label = { Text(option.displayName) },
            )
          }
        }
      }
    }

    // Privacy Settings
    item {
      GlassCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Filled.Security, contentDescription = null, tint = ElectricBlue)
          Spacer(modifier = Modifier.width(8.dp))
          Text(stringResource(R.string.privacy_section), style = MaterialTheme.typography.titleMedium)
        }
        Spacer(modifier = Modifier.height(10.dp))
        PrivacyToggleRow(
          title = "Redact secrets before sending prompts",
          subtitle = "Automatically masks AIza/sk-/Bearer tokens from prompts and attached files",
          checked = uiState.preferences.redactSecretsBeforeSend,
          onCheckedChange = { viewModel.setRedactSecrets(it) },
        )
        Spacer(modifier = Modifier.height(8.dp))
        PrivacyToggleRow(
          title = "Allow workspace file attachments",
          subtitle = "Permit attaching open Kotlin/XML/JSON files to Gemini Studio prompts",
          checked = uiState.preferences.attachActiveFileContext,
          onCheckedChange = { viewModel.setAttachActiveFileContext(it) },
        )
        Spacer(modifier = Modifier.height(8.dp))
        PrivacyToggleRow(
          title = "Log AI telemetry locally",
          subtitle = "Record token count & latency in Room Diagnostic Logs",
          checked = uiState.preferences.logAiMetadataLocally,
          onCheckedChange = { viewModel.setLogAiMetadata(it) },
        )
      }
    }

    // Cache Management
    item {
      GlassCard {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.CleaningServices, contentDescription = null, tint = VioletNeon)
            Spacer(modifier = Modifier.width(8.dp))
            Text(stringResource(R.string.cache_section), style = MaterialTheme.typography.titleMedium)
          }
          StatusPill(text = uiState.cacheSizeLabel, dotColor = ElectricBlue)
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedButton(
            onClick = { viewModel.clearTempCache() },
            modifier = Modifier.weight(1f).height(48.dp),
          ) {
            Text("Clear Cache")
          }
          OutlinedButton(
            onClick = { confirmClearLogs = true },
            modifier = Modifier.weight(1f).height(48.dp),
          ) {
            Text("Clear Logs")
          }
        }
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedButton(
          onClick = { confirmClearHistory = true },
          modifier = Modifier.fillMaxWidth().height(48.dp),
        ) {
          Text("Clear AI Conversation History", color = studio.error)
        }
      }
    }

    // App Info, Version Info & About Android Lab
    item {
      GlassCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Filled.Info, contentDescription = null, tint = ElectricBlue)
          Spacer(modifier = Modifier.width(8.dp))
          Text(stringResource(R.string.about_section), style = MaterialTheme.typography.titleMedium)
        }
        Spacer(modifier = Modifier.height(10.dp))
        InfoKeyValueRow("Application", "Android Lab")
        InfoKeyValueRow("Version", "${BuildConfig.VERSION_NAME} (Build ${BuildConfig.VERSION_CODE})")
        InfoKeyValueRow("Application ID", BuildConfig.APPLICATION_ID)
        InfoKeyValueRow("Target Platform", "Android 8.0+ (API 26 → API 36)")
        InfoKeyValueRow("Architecture", "MVVM • Clean Arch • Room • DataStore")
        Spacer(modifier = Modifier.height(10.dp))
        Button(
          onClick = { showAboutSheet = true },
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth().height(48.dp),
        ) {
          Text("View About & v2.0 Changelog")
        }
      }
    }

    item { Spacer(modifier = Modifier.height(12.dp)) }
  }

  if (confirmClearHistory) {
    AlertDialog(
      onDismissRequest = { confirmClearHistory = false },
      title = { Text("Clear AI History?") },
      text = { Text("All saved Gemini Studio sessions and messages will be permanently deleted.") },
      confirmButton = {
        Button(
          onClick = {
            viewModel.clearConversationHistory()
            confirmClearHistory = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = studio.error),
        ) {
          Text("Clear")
        }
      },
      dismissButton = {
        TextButton(onClick = { confirmClearHistory = false }) { Text("Cancel") }
      },
    )
  }

  if (confirmClearLogs) {
    AlertDialog(
      onDismissRequest = { confirmClearLogs = false },
      title = { Text("Clear Logs?") },
      text = { Text("Removes all studio diagnostic logs and recent activity items.") },
      confirmButton = {
        Button(
          onClick = {
            viewModel.clearDiagnosticLogs()
            confirmClearLogs = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = studio.error),
        ) {
          Text("Clear")
        }
      },
      dismissButton = {
        TextButton(onClick = { confirmClearLogs = false }) { Text("Cancel") }
      },
    )
  }

  if (showAboutSheet) {
    ModalBottomSheet(onDismissRequest = { showAboutSheet = false }) {
      Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Text("Android Lab 2.0", style = MaterialTheme.typography.headlineSmall)
        Text(
          "A standalone mobile Kotlin, Jetpack Compose, and Gemini AI developer studio engineered with Material 3, Room, DataStore, and Android Keystore security.",
          style = MaterialTheme.typography.bodyMedium,
        )
        Text("Version 2.0 Changelog", style = MaterialTheme.typography.titleMedium)
        val notes =
          listOf(
            "• Brand new Deep Navy, Violet & Electric Blue glassmorphic design system.",
            "• Dedicated AI Studio with 10 specialized developer modes and live Gemini REST API integration.",
            "• Android Keystore AES-256-GCM encrypted user API key storage with real connection testing.",
            "• Full Project Workspace manager with templates, metadata, history, and SAF JSON import/export.",
            "• Developer Toolkit with Kotlin/XML/JSON editors, snippet injector, log viewer, and static syntax/XmlPullParser/JSONTokener analyzer.",
          )
        notes.forEach { note ->
          Text(note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(modifier = Modifier.height(20.dp))
      }
    }
  }
}

@Composable
private fun PrivacyToggleRow(
  title: String,
  subtitle: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
      Text(title, style = MaterialTheme.typography.titleSmall)
      Text(
        subtitle,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
    Switch(checked = checked, onCheckedChange = onCheckedChange)
  }
}

@Composable
private fun InfoKeyValueRow(label: String, value: String) {
  Row(
    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text(value, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurface)
  }
}
