package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep Navy Dark Studio Palette
val NavyVoid = Color(0xFF060A18)
val NavySurface = Color(0xFF0C1226)
val NavyElevated = Color(0xFF131C3A)
val NavyCard = Color(0xFF172246)
val NavyOutline = Color(0xFF283563)

// Signature Accents: Purple, Violet, Electric Blue
val VioletNeon = Color(0xFF8B5CF6)
val PurpleGlow = Color(0xFFA855F7)
val PurpleDeep = Color(0xFF6D28D9)
val ElectricBlue = Color(0xFF38BDF8)
val ElectricCobalt = Color(0xFF2563EB)
val IndigoSoft = Color(0xFFC4B5FD)

// Semantic Status Colors
val EmeraldOk = Color(0xFF10B981)
val AmberWarn = Color(0xFFF59E0B)
val RoseError = Color(0xFFF43F5E)

// Dark Text
val InkWhite = Color(0xFFF8FAFC)
val InkMutedDark = Color(0xFF94A3B8)

// Crisp Light Studio Palette
val LightCanvas = Color(0xFFF3F6FD)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE6ECF9)
val LightOutline = Color(0xFFCBD5E1)
val InkDark = Color(0xFF0F172A)
val InkMutedLight = Color(0xFF475569)
