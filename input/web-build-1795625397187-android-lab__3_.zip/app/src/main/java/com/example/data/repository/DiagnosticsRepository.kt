package com.example.data.repository

import com.example.data.local.ActivityLogDao
import com.example.data.local.ActivityLogEntity
import com.example.data.local.DiagnosticLogDao
import com.example.data.local.DiagnosticLogEntity
import kotlinx.coroutines.flow.Flow

class DiagnosticsRepository(
  private val activityLogDao: ActivityLogDao,
  private val diagnosticLogDao: DiagnosticLogDao,
) {
  val recentActivities: Flow<List<ActivityLogEntity>> = activityLogDao.observeRecentActivities(30)
  val diagnosticLogs: Flow<List<DiagnosticLogEntity>> = diagnosticLogDao.observeLogs()

  fun observeProjectHistory(projectId: Long): Flow<List<ActivityLogEntity>> =
    activityLogDao.observeProjectHistory(projectId)

  suspend fun logActivity(
    category: String,
    title: String,
    detail: String,
    projectId: Long? = null,
  ) {
    activityLogDao.insertActivity(
      ActivityLogEntity(
        projectId = projectId,
        category = category,
        title = title,
        detail = detail,
      )
    )
  }

  suspend fun logDiagnostic(level: String, tag: String, message: String) {
    diagnosticLogDao.insertLog(
      DiagnosticLogEntity(
        level = level,
        tag = tag,
        message = message,
      )
    )
  }

  suspend fun clearDiagnostics() {
    diagnosticLogDao.clearLogs()
  }

  suspend fun clearActivities() {
    activityLogDao.clearAll()
  }
}
