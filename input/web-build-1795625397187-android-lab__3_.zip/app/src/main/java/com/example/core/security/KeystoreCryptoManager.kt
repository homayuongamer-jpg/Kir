package com.example.core.security

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Encrypts and decrypts sensitive user credentials (such as the Gemini API key)
 * using hardware-backed AES-256-GCM keys managed by Android Keystore.
 */
class KeystoreCryptoManager {

  companion object {
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val KEY_ALIAS = "android_lab_gemini_master_key_v2"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val IV_LENGTH_BYTES = 12
    private const val TAG_LENGTH_BITS = 128
  }

  private val keyStore: KeyStore by lazy {
    KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
  }

  fun isKeystoreAvailable(): Boolean {
    return runCatching {
      getOrCreateSecretKey()
      true
    }.getOrDefault(false)
  }

  fun encrypt(plainText: String): Result<String> = runCatching {
    require(plainText.isNotBlank()) { "Cannot encrypt blank secret" }
    val cipher = Cipher.getInstance(TRANSFORMATION)
    cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey())
    val iv = cipher.iv
    val cipherBytes = cipher.doFinal(plainText.toByteArray(StandardCharsets.UTF_8))
    val combined = ByteArray(iv.size + cipherBytes.size)
    System.arraycopy(iv, 0, combined, 0, iv.size)
    System.arraycopy(cipherBytes, 0, combined, iv.size, cipherBytes.size)
    Base64.encodeToString(combined, Base64.NO_WRAP)
  }

  fun decrypt(encryptedBase64: String): Result<String> = runCatching {
    require(encryptedBase64.isNotBlank()) { "Encrypted payload is empty" }
    val combined = Base64.decode(encryptedBase64, Base64.NO_WRAP)
    require(combined.size > IV_LENGTH_BYTES) { "Malformed encrypted payload" }
    val iv = combined.copyOfRange(0, IV_LENGTH_BYTES)
    val cipherBytes = combined.copyOfRange(IV_LENGTH_BYTES, combined.size)
    val cipher = Cipher.getInstance(TRANSFORMATION)
    val spec = GCMParameterSpec(TAG_LENGTH_BITS, iv)
    cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), spec)
    val plainBytes = cipher.doFinal(cipherBytes)
    String(plainBytes, StandardCharsets.UTF_8)
  }

  fun maskKey(plainKey: String): String {
    if (plainKey.length <= 8) return "••••••••"
    return "${plainKey.take(4)}••••••••${plainKey.takeLast(4)}"
  }

  private fun getOrCreateSecretKey(): SecretKey {
    val existingEntry = keyStore.getEntry(KEY_ALIAS, null) as? KeyStore.SecretKeyEntry
    if (existingEntry != null) {
      return existingEntry.secretKey
    }
    val keyGenerator =
      KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
    val spec =
      KeyGenParameterSpec.Builder(
          KEY_ALIAS,
          KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
        )
        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
        .setKeySize(256)
        .setRandomizedEncryptionRequired(true)
        .build()
    keyGenerator.init(spec)
    return keyGenerator.generateKey()
  }
}
