package com.example.core.analyzer

import com.example.data.local.ProjectFileEntity
import java.io.StringReader
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

enum class IssueSeverity {
  ERROR,
  WARNING,
  INFO,
}

data class StaticIssue(
  val fileId: Long,
  val fileName: String,
  val line: Int,
  val severity: IssueSeverity,
  val message: String,
  val ruleId: String,
)

data class StaticAnalysisReport(
  val projectName: String,
  val filesChecked: Int,
  val errorCount: Int,
  val warningCount: Int,
  val infoCount: Int,
  val issues: List<StaticIssue>,
  val timestampMs: Long = System.currentTimeMillis(),
  val summary: String,
)

/**
 * Performs honest, deterministic static syntax and structural checks across
 * Kotlin, XML, JSON, and Android project files without claiming local APK compilation.
 */
object ProjectStaticAnalyzer {

  fun analyzeProject(projectName: String, files: List<ProjectFileEntity>): StaticAnalysisReport {
    val issues = mutableListOf<StaticIssue>()

    if (files.isEmpty()) {
      issues +=
        StaticIssue(
          fileId = -1L,
          fileName = projectName,
          line = 1,
          severity = IssueSeverity.WARNING,
          message = "Project contains no files yet. Add a Kotlin, XML, or JSON file to analyze.",
          ruleId = "PROJECT_EMPTY",
        )
    } else {
      val hasManifest = files.any { it.name.equals("AndroidManifest.xml", ignoreCase = true) }
      if (!hasManifest) {
        issues +=
          StaticIssue(
            fileId = files.first().id,
            fileName = "AndroidManifest.xml",
            line = 1,
            severity = IssueSeverity.INFO,
            message = "No AndroidManifest.xml found in workspace root.",
            ruleId = "MANIFEST_MISSING",
          )
      }
    }

    files.forEach { file ->
      when (file.fileType.lowercase()) {
        "kotlin",
        "gradle" -> issues += analyzeKotlinOrGradle(file)
        "xml" -> issues += analyzeXml(file)
        "json" -> issues += analyzeJson(file)
      }
    }

    val errors = issues.count { it.severity == IssueSeverity.ERROR }
    val warnings = issues.count { it.severity == IssueSeverity.WARNING }
    val infos = issues.count { it.severity == IssueSeverity.INFO }

    val summary =
      when {
        errors > 0 ->
          "Static analysis found $errors syntax error(s) and $warnings warning(s) across ${files.size} file(s)."
        warnings > 0 ->
          "No syntax errors. $warnings warning(s) found across ${files.size} file(s)."
        else ->
          "All ${files.size} file(s) passed static Kotlin/XML/JSON checks."
      }

    return StaticAnalysisReport(
      projectName = projectName,
      filesChecked = files.size,
      errorCount = errors,
      warningCount = warnings,
      infoCount = infos,
      issues = issues,
      summary = summary,
    )
  }

  fun analyzeXml(file: ProjectFileEntity): List<StaticIssue> {
    val issues = mutableListOf<StaticIssue>()
    if (file.content.isBlank()) {
      issues +=
        StaticIssue(
          fileId = file.id,
          fileName = file.name,
          line = 1,
          severity = IssueSeverity.ERROR,
          message = "XML file is empty.",
          ruleId = "XML_EMPTY",
        )
      return issues
    }
    val parser =
      runCatching {
        val factory = XmlPullParserFactory.newInstance()
        factory.isNamespaceAware = true
        factory.newPullParser()
      }.getOrNull()

    if (parser == null) {
      issues += analyzeXmlFallback(file)
    } else {
      try {
        parser.setInput(StringReader(file.content))
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
          event = parser.next()
        }
      } catch (e: RuntimeException) {
        if (e.message?.contains("Stub", ignoreCase = true) == true) {
          issues += analyzeXmlFallback(file)
        } else {
          issues +=
            StaticIssue(
              fileId = file.id,
              fileName = file.name,
              line = extractLineNumber(e.message),
              severity = IssueSeverity.ERROR,
              message = e.message ?: "Malformed XML structure",
              ruleId = "XML_SYNTAX",
            )
        }
      } catch (e: Exception) {
        issues +=
          StaticIssue(
            fileId = file.id,
            fileName = file.name,
            line = extractLineNumber(e.message),
            severity = IssueSeverity.ERROR,
            message = e.message ?: "Malformed XML structure",
            ruleId = "XML_SYNTAX",
          )
      }
    }

    if (file.name.equals("AndroidManifest.xml", ignoreCase = true)) {
      if (
        file.content.contains("READ_EXTERNAL_STORAGE") ||
          file.content.contains("WRITE_EXTERNAL_STORAGE")
      ) {
        issues +=
          StaticIssue(
            fileId = file.id,
            fileName = file.name,
            line = findLineContaining(file.content, "EXTERNAL_STORAGE"),
            severity = IssueSeverity.WARNING,
            message =
              "Broad storage permissions are discouraged on modern Android; prefer Photo Picker or SAF.",
            ruleId = "PLAY_STORAGE_POLICY",
          )
      }
    }
    return issues
  }

  fun analyzeJson(file: ProjectFileEntity): List<StaticIssue> {
    val issues = mutableListOf<StaticIssue>()
    val trimmed = file.content.trim()
    if (trimmed.isEmpty()) {
      issues +=
        StaticIssue(
          fileId = file.id,
          fileName = file.name,
          line = 1,
          severity = IssueSeverity.ERROR,
          message = "JSON file is empty.",
          ruleId = "JSON_EMPTY",
        )
      return issues
    }
    try {
      val parsed = JSONTokener(trimmed).nextValue()
      if (parsed !is JSONObject && parsed !is JSONArray) {
        issues +=
          StaticIssue(
            fileId = file.id,
            fileName = file.name,
            line = 1,
            severity = IssueSeverity.WARNING,
            message = "Root JSON value should be an object {} or array [].",
            ruleId = "JSON_ROOT_TYPE",
          )
      }
    } catch (e: Exception) {
      issues +=
        StaticIssue(
          fileId = file.id,
          fileName = file.name,
          line = 1,
          severity = IssueSeverity.ERROR,
          message = e.message ?: "Invalid JSON syntax",
          ruleId = "JSON_SYNTAX",
        )
    }
    return issues
  }

  fun formatJson(raw: String, indentSpaces: Int = 2): Result<String> = runCatching {
    val trimmed = raw.trim()
    when (val parsed = JSONTokener(trimmed).nextValue()) {
      is JSONObject -> parsed.toString(indentSpaces)
      is JSONArray -> parsed.toString(indentSpaces)
      else -> error("Root JSON must be an object or array")
    }
  }

  fun minifyJson(raw: String): Result<String> = runCatching {
    val trimmed = raw.trim()
    when (val parsed = JSONTokener(trimmed).nextValue()) {
      is JSONObject -> parsed.toString()
      is JSONArray -> parsed.toString()
      else -> error("Root JSON must be an object or array")
    }
  }

  private fun analyzeKotlinOrGradle(file: ProjectFileEntity): List<StaticIssue> {
    val issues = mutableListOf<StaticIssue>()
    val content = file.content
    if (content.isBlank()) {
      issues +=
        StaticIssue(
          fileId = file.id,
          fileName = file.name,
          line = 1,
          severity = IssueSeverity.WARNING,
          message = "Source file is empty.",
          ruleId = "KT_EMPTY",
        )
      return issues
    }

    var braceBalance = 0
    var parenBalance = 0
    var lastOpenBraceLine = 1
    var lastOpenParenLine = 1
    var inLineComment = false
    var inBlockComment = false
    var inString = false
    var escaped = false
    var line = 1

    var i = 0
    while (i < content.length) {
      val ch = content[i]
      val next = if (i + 1 < content.length) content[i + 1] else '\u0000'

      if (ch == '\n') {
        line++
        inLineComment = false
        escaped = false
        i++
        continue
      }
      if (inLineComment) {
        i++
        continue
      }
      if (inBlockComment) {
        if (ch == '*' && next == '/') {
          inBlockComment = false
          i += 2
          continue
        }
        i++
        continue
      }
      if (inString) {
        if (escaped) {
          escaped = false
        } else if (ch == '\\') {
          escaped = true
        } else if (ch == '"') {
          inString = false
        }
        i++
        continue
      }

      if (ch == '/' && next == '/') {
        inLineComment = true
        i += 2
        continue
      }
      if (ch == '/' && next == '*') {
        inBlockComment = true
        i += 2
        continue
      }
      if (ch == '"') {
        inString = true
        i++
        continue
      }

      when (ch) {
        '{' -> {
          if (braceBalance == 0) lastOpenBraceLine = line
          braceBalance++
        }
        '}' -> {
          braceBalance--
          if (braceBalance < 0) {
            issues +=
              StaticIssue(
                fileId = file.id,
                fileName = file.name,
                line = line,
                severity = IssueSeverity.ERROR,
                message = "Unexpected closing brace '}'.",
                ruleId = "KT_BRACE_MISMATCH",
              )
            braceBalance = 0
          }
        }
        '(' -> {
          if (parenBalance == 0) lastOpenParenLine = line
          parenBalance++
        }
        ')' -> {
          parenBalance--
          if (parenBalance < 0) {
            issues +=
              StaticIssue(
                fileId = file.id,
                fileName = file.name,
                line = line,
                severity = IssueSeverity.ERROR,
                message = "Unexpected closing parenthesis ')'.",
                ruleId = "KT_PAREN_MISMATCH",
              )
            parenBalance = 0
          }
        }
      }
      i++
    }

    if (inBlockComment) {
      issues +=
        StaticIssue(
          fileId = file.id,
          fileName = file.name,
          line = line,
          severity = IssueSeverity.ERROR,
          message = "Unterminated block comment /* ... */.",
          ruleId = "KT_COMMENT_UNCLOSED",
        )
    }
    if (braceBalance > 0) {
      issues +=
        StaticIssue(
          fileId = file.id,
          fileName = file.name,
          line = lastOpenBraceLine,
          severity = IssueSeverity.ERROR,
          message = "Unclosed '{' — missing $braceBalance closing brace(s).",
          ruleId = "KT_BRACE_UNCLOSED",
        )
    }
    if (parenBalance > 0) {
      issues +=
        StaticIssue(
          fileId = file.id,
          fileName = file.name,
          line = lastOpenParenLine,
          severity = IssueSeverity.ERROR,
          message = "Unclosed '(' — missing $parenBalance closing parenthesis(es).",
          ruleId = "KT_PAREN_UNCLOSED",
        )
    }

    if (file.fileType.equals("kotlin", ignoreCase = true) && !content.contains("package ")) {
      issues +=
        StaticIssue(
          fileId = file.id,
          fileName = file.name,
          line = 1,
          severity = IssueSeverity.WARNING,
          message = "Missing package declaration at top of Kotlin file.",
          ruleId = "KT_NO_PACKAGE",
        )
    }

    val lines = content.lines()
    lines.forEachIndexed { idx, text ->
      if (text.contains("TODO(") || text.contains("// TODO")) {
        issues +=
          StaticIssue(
            fileId = file.id,
            fileName = file.name,
            line = idx + 1,
            severity = IssueSeverity.INFO,
            message = "Pending TODO marker found.",
            ruleId = "KT_TODO",
          )
      }
      if (text.contains("AIzaSy")) {
        issues +=
          StaticIssue(
            fileId = file.id,
            fileName = file.name,
            line = idx + 1,
            severity = IssueSeverity.WARNING,
            message = "Potential hardcoded Google API key detected. Store secrets via Keystore or BuildConfig.",
            ruleId = "SEC_HARDCODED_KEY",
          )
      }
    }
    return issues
  }

  private fun analyzeXmlFallback(file: ProjectFileEntity): List<StaticIssue> {
    val stack = ArrayDeque<Pair<String, Int>>()
    val tagRegex = Regex("<(/?)([A-Za-z0-9_.:-]+)(?:\\s[^>]*)?(/?)>")
    val issues = mutableListOf<StaticIssue>()
    file.content.lines().forEachIndexed { idx, lineText ->
      val lineNum = idx + 1
      tagRegex.findAll(lineText).forEach { match ->
        val isClosing = match.groupValues[1] == "/"
        val tagName = match.groupValues[2]
        val isSelfClosing = match.groupValues[3] == "/"
        if (tagName.startsWith("?") || tagName.startsWith("!")) return@forEach
        if (!isClosing && !isSelfClosing) {
          stack.addLast(tagName to lineNum)
        } else if (isClosing) {
          if (stack.isEmpty() || stack.last().first != tagName) {
            issues +=
              StaticIssue(
                fileId = file.id,
                fileName = file.name,
                line = lineNum,
                severity = IssueSeverity.ERROR,
                message = "Mismatched closing tag </$tagName>.",
                ruleId = "XML_SYNTAX",
              )
          } else {
            stack.removeLast()
          }
        }
      }
    }
    if (stack.isNotEmpty()) {
      val (unclosed, lineNum) = stack.last()
      issues +=
        StaticIssue(
          fileId = file.id,
          fileName = file.name,
          line = lineNum,
          severity = IssueSeverity.ERROR,
          message = "Unclosed XML tag <$unclosed>.",
          ruleId = "XML_SYNTAX",
        )
    }
    return issues
  }

  private fun extractLineNumber(errorMessage: String?): Int {
    if (errorMessage == null) return 1
    val regex = Regex("line[:\\s]+(\\d+)", RegexOption.IGNORE_CASE)
    return regex.find(errorMessage)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 1
  }

  private fun findLineContaining(content: String, needle: String): Int {
    content.lines().forEachIndexed { index, s ->
      if (s.contains(needle, ignoreCase = true)) return index + 1
    }
    return 1
  }
}
