package com.example.core.templates

import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
data class ExportedFileDto(
  val name: String,
  val relativePath: String,
  val fileType: String,
  val content: String,
)

@Serializable
data class ExportedProjectBundle(
  val formatVersion: Int = 2,
  val exportedBy: String = "Android Lab 2.0",
  val name: String,
  val packageName: String,
  val description: String,
  val templateType: String,
  val minSdk: Int,
  val versionName: String,
  val exportedAtMs: Long,
  val files: List<ExportedFileDto>,
)

object ProjectBundleSerializer {
  private val json = Json {
    prettyPrint = true
    ignoreUnknownKeys = true
    encodeDefaults = true
  }

  fun encode(bundle: ExportedProjectBundle): String = json.encodeToString(bundle)

  fun decode(rawJson: String): Result<ExportedProjectBundle> = runCatching {
    json.decodeFromString<ExportedProjectBundle>(rawJson)
  }
}
