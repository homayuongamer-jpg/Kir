package com.example.ui.screens.aistudio

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.preferences.GeminiModelOption
import com.example.core.preferences.StudioPreferences
import com.example.core.preferences.StudioPreferencesRepository
import com.example.data.local.AiConversationEntity
import com.example.data.local.AiMessageEntity
import com.example.data.local.CustomPromptEntity
import com.example.data.local.ProjectEntity
import com.example.data.local.ProjectFileEntity
import com.example.data.repository.AiStudioMode
import com.example.data.repository.AiStudioRepository
import com.example.data.repository.ConnectionTestResult
import com.example.data.repository.ProjectRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AiStudioUiState(
  val preferences: StudioPreferences = StudioPreferences(),
  val selectedMode: AiStudioMode = AiStudioMode.CODING_ASSISTANT,
  val conversations: List<AiConversationEntity> = emptyList(),
  val activeConversationId: Long? = null,
  val messages: List<AiMessageEntity> = emptyList(),
  val customPrompts: List<CustomPromptEntity> = emptyList(),
  val activeProject: ProjectEntity? = null,
  val projectFiles: List<ProjectFileEntity> = emptyList(),
  val attachedFileId: Long? = null,
  val isSending: Boolean = false,
  val isTestingConnection: Boolean = false,
  val connectionTestResult: ConnectionTestResult? = null,
  val snackbarMessage: String? = null,
)

class AiStudioViewModel(
  private val aiStudioRepository: AiStudioRepository,
  private val projectRepository: ProjectRepository,
  private val preferencesRepository: StudioPreferencesRepository,
) : ViewModel() {

  private val selectedMode = MutableStateFlow(AiStudioMode.CODING_ASSISTANT)
  private val activeConversationId = MutableStateFlow<Long?>(null)
  private val attachedFileId = MutableStateFlow<Long?>(null)
  private val isSending = MutableStateFlow(false)
  private val isTestingConnection = MutableStateFlow(false)
  private val connectionTestResult = MutableStateFlow<ConnectionTestResult?>(null)
  private val snackbarMessage = MutableStateFlow<String?>(null)

  @OptIn(ExperimentalCoroutinesApi::class)
  private val messagesFlow =
    activeConversationId.flatMapLatest { id ->
      if (id == null) flowOf(emptyList()) else aiStudioRepository.observeMessages(id)
    }

  @OptIn(ExperimentalCoroutinesApi::class)
  private val activeProjectFlow =
    preferencesRepository.preferencesFlow.flatMapLatest { prefs ->
      projectRepository.observeProject(prefs.activeProjectId)
    }

  @OptIn(ExperimentalCoroutinesApi::class)
  private val projectFilesFlow =
    preferencesRepository.preferencesFlow.flatMapLatest { prefs ->
      projectRepository.observeProjectFiles(prefs.activeProjectId)
    }

  val uiState: StateFlow<AiStudioUiState> =
    combine(
        preferencesRepository.preferencesFlow,
        selectedMode,
        aiStudioRepository.conversations,
        activeConversationId,
        messagesFlow,
        aiStudioRepository.customPrompts,
        activeProjectFlow,
        projectFilesFlow,
        attachedFileId,
        isSending,
        isTestingConnection,
        connectionTestResult,
        snackbarMessage,
      ) { values ->
        val prefs = values[0] as StudioPreferences
        val mode = values[1] as AiStudioMode
        @Suppress("UNCHECKED_CAST")
        val convs = values[2] as List<AiConversationEntity>
        val activeConvId = values[3] as Long?
        @Suppress("UNCHECKED_CAST")
        val msgs = values[4] as List<AiMessageEntity>
        @Suppress("UNCHECKED_CAST")
        val prompts = values[5] as List<CustomPromptEntity>
        val proj = values[6] as ProjectEntity?
        @Suppress("UNCHECKED_CAST")
        val files = values[7] as List<ProjectFileEntity>
        val attId = values[8] as Long?
        val sending = values[9] as Boolean
        val testing = values[10] as Boolean
        val testRes = values[11] as ConnectionTestResult?
        val snack = values[12] as String?

        AiStudioUiState(
          preferences = prefs,
          selectedMode = mode,
          conversations = convs,
          activeConversationId = activeConvId,
          messages = msgs,
          customPrompts = prompts,
          activeProject = proj,
          projectFiles = files,
          attachedFileId = attId,
          isSending = sending,
          isTestingConnection = testing,
          connectionTestResult = testRes,
          snackbarMessage = snack,
        )
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = AiStudioUiState(),
      )

  init {
    viewModelScope.launch {
      val convs = aiStudioRepository.conversations.first()
      if (convs.isNotEmpty() && activeConversationId.value == null) {
        activeConversationId.value = convs.first().id
      }
    }
  }

  fun selectMode(mode: AiStudioMode) {
    selectedMode.value = mode
  }

  fun selectModel(model: GeminiModelOption) {
    viewModelScope.launch { preferencesRepository.setSelectedModel(model) }
  }

  fun selectAttachedFile(fileId: Long?) {
    attachedFileId.value = if (attachedFileId.value == fileId) null else fileId
  }

  fun selectConversation(conversationId: Long) {
    activeConversationId.value = conversationId
  }

  fun startNewConversation() {
    viewModelScope.launch {
      val state = uiState.value
      val id =
        aiStudioRepository.createConversation(
          title = "${state.selectedMode.shortLabel} Session",
          mode = state.selectedMode,
          model = state.preferences.selectedModel,
          projectId = state.activeProject?.id,
        )
      activeConversationId.value = id
    }
  }

  fun deleteConversation(conversationId: Long) {
    viewModelScope.launch {
      aiStudioRepository.deleteConversation(conversationId)
      if (activeConversationId.value == conversationId) {
        activeConversationId.value = aiStudioRepository.conversations.first().firstOrNull()?.id
      }
    }
  }

  fun sendPrompt(rawPrompt: String, onSent: () -> Unit = {}) {
    val prompt = rawPrompt.trim()
    if (prompt.isEmpty() || isSending.value) return
    viewModelScope.launch {
      isSending.value = true
      val state = uiState.value
      val convId =
        state.activeConversationId
          ?: aiStudioRepository
            .createConversation(
              title = prompt.take(48),
              mode = state.selectedMode,
              model = state.preferences.selectedModel,
              projectId = state.activeProject?.id,
            )
            .also { activeConversationId.value = it }

      val attached =
        if (state.preferences.attachActiveFileContext) {
          state.projectFiles.find { it.id == state.attachedFileId }
        } else {
          null
        }

      val result =
        aiStudioRepository.sendPrompt(
          conversationId = convId,
          userPrompt = prompt,
          mode = state.selectedMode,
          model = state.preferences.selectedModel,
          attachedFileName = attached?.name,
          attachedFileContent = attached?.content,
        )
      isSending.value = false
      result.onSuccess { onSent() }.onFailure { err -> snackbarMessage.value = err.message }
    }
  }

  fun saveApiKeyAndTest(rawKey: String) {
    viewModelScope.launch {
      isTestingConnection.value = true
      val saveRes = preferencesRepository.saveGeminiApiKey(rawKey)
      if (saveRes.isFailure) {
        isTestingConnection.value = false
        snackbarMessage.value = saveRes.exceptionOrNull()?.message ?: "Failed to encrypt key"
        return@launch
      }
      val testRes = aiStudioRepository.testGeminiConnection()
      connectionTestResult.value = testRes
      isTestingConnection.value = false
      snackbarMessage.value = testRes.message
    }
  }

  fun testConnection() {
    viewModelScope.launch {
      isTestingConnection.value = true
      val res = aiStudioRepository.testGeminiConnection()
      connectionTestResult.value = res
      isTestingConnection.value = false
      snackbarMessage.value = res.message
    }
  }

  fun saveCustomPrompt(title: String, promptText: String) {
    viewModelScope.launch {
      aiStudioRepository.saveCustomPrompt(title, selectedMode.value, promptText)
      snackbarMessage.value = "Saved prompt '$title' to Prompt Library."
    }
  }

  fun deleteCustomPrompt(id: Long) {
    viewModelScope.launch { aiStudioRepository.deleteCustomPrompt(id) }
  }

  fun saveCodeSnippetToActiveProject(fileName: String, code: String) {
    viewModelScope.launch {
      val proj = uiState.value.activeProject
      if (proj == null) {
        snackbarMessage.value = "No active project selected. Create or open a project first."
        return@launch
      }
      val inferredType = projectRepository.inferFileType(fileName)
      projectRepository.createOrUpdateFile(
        projectId = proj.id,
        fileName = fileName,
        relativePath = fileName,
        fileType = inferredType,
        content = code,
      )
      snackbarMessage.value = "Saved '$fileName' to ${proj.name}."
    }
  }

  fun clearSnackbar() {
    snackbarMessage.value = null
  }
}
