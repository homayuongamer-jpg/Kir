package com.example.data.repository

import com.example.core.preferences.ApiConnectionState
import com.example.core.preferences.GeminiModelOption
import com.example.core.preferences.StudioPreferencesRepository
import com.example.data.local.AiConversationEntity
import com.example.data.local.AiMessageEntity
import com.example.data.local.AiStudioDao
import com.example.data.local.CustomPromptEntity
import com.example.data.remote.GenerateContentRequest
import com.example.data.remote.GeminiApiService
import com.example.data.remote.GeminiClientFactory
import com.example.data.remote.GeminiContentDto
import com.example.data.remote.GeminiErrorEnvelopeDto
import com.example.data.remote.GeminiPartDto
import com.example.data.remote.GenerationConfigDto
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

enum class AiStudioMode(
  val key: String,
  val title: String,
  val shortLabel: String,
  val systemInstruction: String,
) {
  CODING_ASSISTANT(
    key = "CODING_ASSISTANT",
    title = "AI Coding Assistant",
    shortLabel = "Assistant",
    systemInstruction =
      "You are a senior Android Kotlin & Jetpack Compose engineer inside Android Lab 2.0. Give accurate, idiomatic, production-ready Kotlin code and concise explanations.",
  ),
  APP_GEN(
    key = "APP_GEN",
    title = "Android App Generator",
    shortLabel = "App Gen",
    systemInstruction =
      "You are an Android app architect. Generate clean multi-file Kotlin + Jetpack Compose + Material 3 code structured with clear file headers (e.g., // File: MainActivity.kt) inside fenced code blocks.",
  ),
  KOTLIN_GEN(
    key = "KOTLIN_GEN",
    title = "Kotlin Code Generator",
    shortLabel = "Kotlin",
    systemInstruction =
      "Generate clean, null-safe, idiomatic Kotlin code using Coroutines, Flow, and modern Kotlin conventions. Wrap code in ```kotlin blocks.",
  ),
  COMPOSE_UI(
    key = "COMPOSE_UI",
    title = "Jetpack Compose UI Generator",
    shortLabel = "Compose UI",
    systemInstruction =
      "Generate modern Material 3 Jetpack Compose UI components using Modifier, WindowInsets, remember/State, and accessible contentDescription values. Wrap code in ```kotlin blocks.",
  ),
  XML_GEN(
    key = "XML_GEN",
    title = "XML Resource & Manifest Generator",
    shortLabel = "XML",
    systemInstruction =
      "Generate valid Android XML files (AndroidManifest, themes, vector drawables, adaptive icons, strings). Wrap output in ```xml blocks.",
  ),
  EXPLAIN_CODE(
    key = "EXPLAIN_CODE",
    title = "Code Explanation",
    shortLabel = "Explain",
    systemInstruction =
      "Explain the provided Android/Kotlin/XML code clearly section by section, highlighting lifecycle implications, threading, and state flow.",
  ),
  BUG_ANALYSIS(
    key = "BUG_ANALYSIS",
    title = "Bug Analysis",
    shortLabel = "Bug Scan",
    systemInstruction =
      "Audit the provided code for logic bugs, race conditions, Compose recomposition pitfalls, memory leaks, and null-safety edge cases. Provide exact fixes.",
  ),
  DEBUG_ERROR(
    key = "DEBUG_ERROR",
    title = "Error Debugging Assistant",
    shortLabel = "Debug",
    systemInstruction =
      "Diagnose the provided Android build error, runtime exception, or stacktrace. Explain the root cause and provide the exact Kotlin/Gradle/XML fix.",
  ),
  CODE_REVIEW(
    key = "CODE_REVIEW",
    title = "Code Review",
    shortLabel = "Review",
    systemInstruction =
      "Perform a thorough senior-level Android code review covering Readability, Performance, Security, Material 3 Accessibility, and Testability.",
  ),
  ARCHITECTURE(
    key = "ARCHITECTURE",
    title = "Architecture Recommendations",
    shortLabel = "Architect",
    systemInstruction =
      "Provide concrete Android Clean Architecture / MVVM recommendations covering Repository layering, Room/DataStore choices, Retrofit error modeling, and modularization.",
  ),
}

data class ConnectionTestResult(
  val success: Boolean,
  val message: String,
  val latencyMs: Long,
  val availableModels: List<String> = emptyList(),
)

class AiStudioRepository(
  private val aiStudioDao: AiStudioDao,
  private val geminiApiService: GeminiApiService,
  private val preferencesRepository: StudioPreferencesRepository,
  private val diagnosticsRepository: DiagnosticsRepository,
) {
  val conversations: Flow<List<AiConversationEntity>> = aiStudioDao.observeConversations()
  val customPrompts: Flow<List<CustomPromptEntity>> = aiStudioDao.observeCustomPrompts()
  val totalPromptCount: Flow<Int> = aiStudioDao.observeTotalPromptCount()

  fun observeMessages(conversationId: Long): Flow<List<AiMessageEntity>> =
    aiStudioDao.observeMessages(conversationId)

  suspend fun createConversation(
    title: String,
    mode: AiStudioMode,
    model: GeminiModelOption,
    projectId: Long? = null,
  ): Long {
    return aiStudioDao.insertConversation(
      AiConversationEntity(
        title = title.take(60),
        modeKey = mode.key,
        modelId = model.modelId,
        projectId = projectId,
      )
    )
  }

  suspend fun deleteConversation(conversationId: Long) {
    aiStudioDao.deleteConversation(conversationId)
  }

  suspend fun clearAllConversations() {
    aiStudioDao.clearAllConversations()
  }

  suspend fun saveCustomPrompt(title: String, mode: AiStudioMode, promptText: String) {
    if (title.isBlank() || promptText.isBlank()) return
    aiStudioDao.insertCustomPrompt(
      CustomPromptEntity(
        title = title.trim(),
        modeKey = mode.key,
        promptText = promptText.trim(),
      )
    )
  }

  suspend fun deleteCustomPrompt(id: Long) {
    aiStudioDao.deleteCustomPrompt(id)
  }

  suspend fun testGeminiConnection(): ConnectionTestResult {
    val apiKey = preferencesRepository.getDecryptedGeminiApiKey()
    if (apiKey.isNullOrBlank()) {
      val msg = "No Gemini API key stored in Android Keystore."
      preferencesRepository.updateConnectionStatus(ApiConnectionState.NOT_CONFIGURED, msg, 0L)
      return ConnectionTestResult(false, msg, 0L)
    }

    val startMs = System.currentTimeMillis()
    return try {
      val response = geminiApiService.listModels(apiKey = apiKey)
      val latency = System.currentTimeMillis() - startMs
      if (response.isSuccessful) {
        val models =
          response.body()?.models.orEmpty().mapNotNull {
            it.name?.removePrefix("models/")
          }.filter { it.contains("gemini", ignoreCase = true) }
        val msg =
          "Connected (${response.code()}) • ${models.size} Gemini model(s) accessible in ${latency}ms"
        preferencesRepository.updateConnectionStatus(ApiConnectionState.VERIFIED, msg, latency)
        diagnosticsRepository.logDiagnostic("AI", "GeminiAPI", msg)
        diagnosticsRepository.logActivity("SECURITY", "Gemini connection verified", msg)
        ConnectionTestResult(true, msg, latency, models)
      } else {
        val parsedError = parseApiError(response.code(), response.errorBody()?.string())
        preferencesRepository.updateConnectionStatus(ApiConnectionState.ERROR, parsedError, latency)
        diagnosticsRepository.logDiagnostic("ERROR", "GeminiAPI", parsedError)
        ConnectionTestResult(false, parsedError, latency)
      }
    } catch (e: Exception) {
      val latency = System.currentTimeMillis() - startMs
      val msg = mapExceptionMessage(e)
      preferencesRepository.updateConnectionStatus(ApiConnectionState.ERROR, msg, latency)
      diagnosticsRepository.logDiagnostic("ERROR", "GeminiAPI", msg)
      ConnectionTestResult(false, msg, latency)
    }
  }

  suspend fun sendPrompt(
    conversationId: Long,
    userPrompt: String,
    mode: AiStudioMode,
    model: GeminiModelOption,
    attachedFileName: String? = null,
    attachedFileContent: String? = null,
  ): Result<AiMessageEntity> {
    val prefs = preferencesRepository.preferencesFlow.first()
    val apiKey = preferencesRepository.getDecryptedGeminiApiKey()
    if (apiKey.isNullOrBlank()) {
      return Result.failure(
        IllegalStateException(
          "Gemini API key is not configured. Open Settings or tap 'Configure Gemini Key' to store your key securely in Android Keystore."
        )
      )
    }

    val sanitizedPrompt =
      if (prefs.redactSecretsBeforeSend) redactSensitiveTokens(userPrompt) else userPrompt
    val fullPromptText =
      if (!attachedFileName.isNullOrBlank() && !attachedFileContent.isNullOrBlank()) {
        val safeAttachment =
          if (prefs.redactSecretsBeforeSend) {
            redactSensitiveTokens(attachedFileContent)
          } else {
            attachedFileContent
          }
        "$sanitizedPrompt\n\n---\nAttached Workspace File: $attachedFileName\n```\n$safeAttachment\n```"
      } else {
        sanitizedPrompt
      }

    // Persist user message
    aiStudioDao.insertMessage(
      AiMessageEntity(
        conversationId = conversationId,
        role = "user",
        content = userPrompt.trim(),
        modeKey = mode.key,
        modelId = model.modelId,
      )
    )

    // Update conversation title from first prompt if still default
    val history = aiStudioDao.observeMessages(conversationId).first()
    if (history.count { it.role == "user" } <= 1) {
      aiStudioDao.updateConversationMeta(
        id = conversationId,
        title = userPrompt.trim().take(48),
        updatedAtMs = System.currentTimeMillis(),
      )
    }

    // Build contents with up to 6 prior turns for context
    val priorTurns =
      history
        .filter { it.role == "user" || it.role == "model" }
        .dropLast(1)
        .takeLast(6)
        .map { msg ->
          GeminiContentDto(
            role = if (msg.role == "user") "user" else "model",
            parts = listOf(GeminiPartDto(text = msg.content)),
          )
        }

    val request =
      GenerateContentRequest(
        systemInstruction =
          GeminiContentDto(parts = listOf(GeminiPartDto(text = mode.systemInstruction))),
        contents =
          priorTurns +
            listOf(
              GeminiContentDto(
                role = "user",
                parts = listOf(GeminiPartDto(text = fullPromptText)),
              )
            ),
        generationConfig =
          GenerationConfigDto(
            temperature = if (mode == AiStudioMode.DEBUG_ERROR || mode == AiStudioMode.BUG_ANALYSIS) 0.2 else 0.45,
            topP = 0.95,
            maxOutputTokens = 4096,
          ),
      )

    val startMs = System.currentTimeMillis()
    return try {
      val response =
        geminiApiService.generateContent(
          model = model.modelId,
          apiKey = apiKey,
          request = request,
        )
      val latency = System.currentTimeMillis() - startMs

      if (response.isSuccessful) {
        val body = response.body()
        val blockReason = body?.promptFeedback?.blockReason
        val replyText =
          body?.candidates
            ?.firstOrNull()
            ?.content
            ?.parts
            ?.mapNotNull { it.text }
            ?.joinToString("\n")
            ?.trim()

        if (replyText.isNullOrBlank()) {
          val errText =
            if (!blockReason.isNullOrBlank()) {
              "Gemini blocked this response (reason: $blockReason)."
            } else {
              "Gemini returned an empty candidate response."
            }
          val errEntity =
            AiMessageEntity(
              conversationId = conversationId,
              role = "error",
              content = errText,
              modeKey = mode.key,
              modelId = model.modelId,
              latencyMs = latency,
            )
          aiStudioDao.insertMessage(errEntity)
          return Result.failure(IllegalStateException(errText))
        }

        val tokens = body.usageMetadata?.totalTokenCount ?: 0
        val modelMessage =
          AiMessageEntity(
            conversationId = conversationId,
            role = "model",
            content = replyText,
            modeKey = mode.key,
            modelId = model.modelId,
            tokenCount = tokens,
            latencyMs = latency,
          )
        aiStudioDao.insertMessage(modelMessage)
        aiStudioDao.updateConversationMeta(
          id = conversationId,
          title = history.firstOrNull { it.role == "user" }?.content?.take(48) ?: mode.title,
          updatedAtMs = System.currentTimeMillis(),
        )

        preferencesRepository.updateConnectionStatus(
          ApiConnectionState.VERIFIED,
          "Last request succeeded (${model.displayName} • ${latency}ms)",
          latency,
        )

        if (prefs.logAiMetadataLocally) {
          diagnosticsRepository.logDiagnostic(
            level = "AI",
            tag = model.modelId,
            message = "${mode.shortLabel} completed in ${latency}ms ($tokens tokens)",
          )
          diagnosticsRepository.logActivity(
            category = "AI",
            title = "${mode.shortLabel} response",
            detail = "${model.displayName} • ${tokens} tokens • ${latency}ms",
          )
        }
        Result.success(modelMessage)
      } else {
        val errText = parseApiError(response.code(), response.errorBody()?.string())
        val errEntity =
          AiMessageEntity(
            conversationId = conversationId,
            role = "error",
            content = errText,
            modeKey = mode.key,
            modelId = model.modelId,
            latencyMs = latency,
          )
        aiStudioDao.insertMessage(errEntity)
        preferencesRepository.updateConnectionStatus(ApiConnectionState.ERROR, errText, latency)
        diagnosticsRepository.logDiagnostic("ERROR", "GeminiAPI", errText)
        Result.failure(IllegalStateException(errText))
      }
    } catch (e: Exception) {
      val latency = System.currentTimeMillis() - startMs
      val msg = mapExceptionMessage(e)
      aiStudioDao.insertMessage(
        AiMessageEntity(
          conversationId = conversationId,
          role = "error",
          content = msg,
          modeKey = mode.key,
          modelId = model.modelId,
          latencyMs = latency,
        )
      )
      preferencesRepository.updateConnectionStatus(ApiConnectionState.ERROR, msg, latency)
      diagnosticsRepository.logDiagnostic("ERROR", "GeminiAPI", msg)
      Result.failure(e)
    }
  }

  private fun parseApiError(code: Int, rawErrorBody: String?): String {
    val parsedMessage =
      runCatching {
        if (rawErrorBody.isNullOrBlank()) null
        else {
          val adapter = GeminiClientFactory.moshi.adapter(GeminiErrorEnvelopeDto::class.java)
          adapter.fromJson(rawErrorBody)?.error?.message
        }
      }.getOrNull()

    val hint =
      when (code) {
        400 -> "Bad request or unsupported parameter for this model."
        401,
        403 -> "Authentication failed. Verify your Gemini API key and API enablement."
        404 -> "Model not found or unavailable for this API key."
        429 -> "Rate limit or quota exceeded (HTTP 429). Wait briefly or check AI Studio quota."
        in 500..599 -> "Gemini service temporarily unavailable (HTTP $code)."
        else -> "HTTP $code error."
      }
    return if (!parsedMessage.isNullOrBlank()) "$hint\nDetails: $parsedMessage" else hint
  }

  private fun mapExceptionMessage(e: Exception): String {
    return when (e) {
      is UnknownHostException ->
        "Network unreachable. Check internet connectivity before calling Gemini API."
      is SocketTimeoutException ->
        "Request timed out waiting for Gemini API response. Try a smaller prompt or Gemini Flash."
      is IOException -> "Network I/O error: ${e.message ?: "connection interrupted"}."
      else -> e.message ?: "Unexpected error communicating with Gemini API."
    }
  }

  private fun redactSensitiveTokens(input: String): String {
    return input
      .replace(Regex("AIza[0-9A-Za-z\\-_]{20,}"), "[REDACTED_GOOGLE_KEY]")
      .replace(Regex("sk-[0-9A-Za-z]{20,}"), "[REDACTED_SECRET_KEY]")
      .replace(Regex("Bearer\\s+[A-Za-z0-9\\-._~+/]+=*"), "Bearer [REDACTED_TOKEN]")
  }
}
