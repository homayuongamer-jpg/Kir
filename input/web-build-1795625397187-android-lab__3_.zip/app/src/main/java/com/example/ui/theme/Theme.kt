package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.example.core.preferences.ThemeMode

@Immutable
data class StudioColors(
  val isDark: Boolean,
  val backdropStart: Color,
  val backdropMid: Color,
  val backdropEnd: Color,
  val glassFill: Color,
  val glassBorderStart: Color,
  val glassBorderEnd: Color,
  val codeSurface: Color,
  val codeBorder: Color,
  val accentGradientStart: Color,
  val accentGradientMid: Color,
  val accentGradientEnd: Color,
  val success: Color,
  val warning: Color,
  val error: Color,
)

private val DarkStudioColors =
  StudioColors(
    isDark = true,
    backdropStart = NavyVoid,
    backdropMid = Color(0xFF0D1330),
    backdropEnd = Color(0xFF071128),
    glassFill = Color(0xCC131C3A),
    glassBorderStart = Color(0x558B5CF6),
    glassBorderEnd = Color(0x4438BDF8),
    codeSurface = Color(0xFF080D1F),
    codeBorder = Color(0xFF26335E),
    accentGradientStart = PurpleDeep,
    accentGradientMid = VioletNeon,
    accentGradientEnd = ElectricCobalt,
    success = EmeraldOk,
    warning = AmberWarn,
    error = RoseError,
  )

private val LightStudioColors =
  StudioColors(
    isDark = false,
    backdropStart = LightCanvas,
    backdropMid = Color(0xFFEBEFFE),
    backdropEnd = Color(0xFFF6F9FF),
    glassFill = Color(0xE6FFFFFF),
    glassBorderStart = Color(0x447C3AED),
    glassBorderEnd = Color(0x442563EB),
    codeSurface = Color(0xFF0F172A),
    codeBorder = Color(0xFF334155),
    accentGradientStart = PurpleDeep,
    accentGradientMid = VioletNeon,
    accentGradientEnd = ElectricCobalt,
    success = Color(0xFF059669),
    warning = Color(0xFFD97706),
    error = Color(0xFFE11D48),
  )

val LocalStudioColors = staticCompositionLocalOf { DarkStudioColors }

private val DarkColorScheme =
  darkColorScheme(
    primary = VioletNeon,
    onPrimary = InkWhite,
    primaryContainer = Color(0xFF2B1E5C),
    onPrimaryContainer = IndigoSoft,
    secondary = ElectricBlue,
    onSecondary = NavyVoid,
    secondaryContainer = Color(0xFF132D4E),
    onSecondaryContainer = Color(0xFFBAE6FD),
    tertiary = PurpleGlow,
    onTertiary = InkWhite,
    background = NavyVoid,
    onBackground = InkWhite,
    surface = NavySurface,
    onSurface = InkWhite,
    surfaceVariant = NavyElevated,
    onSurfaceVariant = InkMutedDark,
    outline = NavyOutline,
    outlineVariant = Color(0xFF1D274A),
    error = RoseError,
    onError = InkWhite,
  )

private val LightColorScheme =
  lightColorScheme(
    primary = PurpleDeep,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFEDE9FE),
    onPrimaryContainer = Color(0xFF3B0764),
    secondary = ElectricCobalt,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFDBEAFE),
    onSecondaryContainer = Color(0xFF1E3A8A),
    tertiary = Color(0xFF9333EA),
    onTertiary = Color.White,
    background = LightCanvas,
    onBackground = InkDark,
    surface = LightSurface,
    onSurface = InkDark,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = InkMutedLight,
    outline = LightOutline,
    outlineVariant = Color(0xFFE2E8F0),
    error = Color(0xFFE11D48),
    onError = Color.White,
  )

@Composable
fun AndroidLabTheme(
  themeMode: ThemeMode = ThemeMode.DARK,
  content: @Composable () -> Unit,
) {
  val isDark =
    when (themeMode) {
      ThemeMode.DARK -> true
      ThemeMode.LIGHT -> false
      ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
  val colorScheme = if (isDark) DarkColorScheme else LightColorScheme
  val studioColors = if (isDark) DarkStudioColors else LightStudioColors

  CompositionLocalProvider(LocalStudioColors provides studioColors) {
    MaterialTheme(
      colorScheme = colorScheme,
      typography = AndroidLabTypography,
      shapes = AndroidLabShapes,
      content = content,
    )
  }
}
