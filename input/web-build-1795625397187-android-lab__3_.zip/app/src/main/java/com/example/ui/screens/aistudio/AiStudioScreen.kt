package com.example.ui.screens.aistudio

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.core.preferences.ApiConnectionState
import com.example.core.preferences.GeminiModelOption
import com.example.core.templates.ProjectTemplates
import com.example.data.local.AiMessageEntity
import com.example.data.repository.AiStudioMode
import com.example.ui.components.CodeDisplayBox
import com.example.ui.components.GlassCard
import com.example.ui.components.StatusPill
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.LocalStudioColors
import com.example.ui.theme.VioletNeon

private sealed interface MessageSegment {
  data class MarkdownText(val text: String) : MessageSegment

  data class CodeBlock(val language: String, val code: String) : MessageSegment
}

private fun parseMessageSegments(content: String): List<MessageSegment> {
  val segments = mutableListOf<MessageSegment>()
  val regex = Regex("```([a-zA-Z0-9_-]*)\\n([\\s\\S]*?)```")
  var lastIndex = 0
  regex.findAll(content).forEach { match ->
    if (match.range.first > lastIndex) {
      val text = content.substring(lastIndex, match.range.first).trim()
      if (text.isNotEmpty()) segments += MessageSegment.MarkdownText(text)
    }
    val lang = match.groupValues[1].ifBlank { "kotlin" }
    val code = match.groupValues[2].trimEnd()
    segments += MessageSegment.CodeBlock(lang, code)
    lastIndex = match.range.last + 1
  }
  if (lastIndex < content.length) {
    val tail = content.substring(lastIndex).trim()
    if (tail.isNotEmpty()) segments += MessageSegment.MarkdownText(tail)
  }
  return if (segments.isEmpty()) listOf(MessageSegment.MarkdownText(content)) else segments
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiStudioScreen(
  viewModel: AiStudioViewModel,
  initialMode: AiStudioMode? = null,
  initialPrompt: String? = null,
) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val studio = LocalStudioColors.current
  val clipboard = LocalClipboardManager.current

  var promptInput by remember { mutableStateOf("") }
  var showModelMenu by remember { mutableStateOf(false) }
  var showPromptLibrary by remember { mutableStateOf(false) }
  var showHistorySheet by remember { mutableStateOf(false) }
  var showKeyConfigDialog by remember { mutableStateOf(false) }
  var showAttachSheet by remember { mutableStateOf(false) }
  var saveCodeDialog by remember { mutableStateOf<Pair<String, String>?>(null) }
  var savePromptDialog by remember { mutableStateOf(false) }

  LaunchedEffect(initialMode) {
    if (initialMode != null) viewModel.selectMode(initialMode)
  }
  LaunchedEffect(initialPrompt) {
    if (!initialPrompt.isNullOrBlank()) promptInput = initialPrompt
  }

  val listState = rememberLazyListState()
  LaunchedEffect(uiState.messages.size) {
    if (uiState.messages.isNotEmpty()) {
      listState.animateScrollToItem(uiState.messages.size - 1)
    }
  }

  Column(modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp)) {
    // Header Row
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = stringResource(R.string.ai_studio_title),
          style = MaterialTheme.typography.headlineMedium,
          color = MaterialTheme.colorScheme.onBackground,
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box {
            AssistChip(
              onClick = { showModelMenu = true },
              label = { Text(uiState.preferences.selectedModel.displayName) },
              leadingIcon = {
                Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
              },
            )
            DropdownMenu(expanded = showModelMenu, onDismissRequest = { showModelMenu = false }) {
              GeminiModelOption.entries.forEach { option ->
                DropdownMenuItem(
                  text = {
                    Column {
                      Text(option.displayName, style = MaterialTheme.typography.labelLarge)
                      Text(option.tierNote, style = MaterialTheme.typography.bodySmall)
                    }
                  },
                  onClick = {
                    viewModel.selectModel(option)
                    showModelMenu = false
                  },
                )
              }
            }
          }
          Spacer(modifier = Modifier.width(6.dp))
          val dotColor =
            when (uiState.preferences.apiConnectionState) {
              ApiConnectionState.VERIFIED -> studio.success
              ApiConnectionState.CONFIGURED_UNTESTED -> studio.warning
              ApiConnectionState.ERROR -> studio.error
              ApiConnectionState.NOT_CONFIGURED -> Color(0xFF94A3B8)
            }
          StatusPill(
            text =
              when (uiState.preferences.apiConnectionState) {
                ApiConnectionState.VERIFIED -> "LIVE"
                ApiConnectionState.CONFIGURED_UNTESTED -> "UNTESTED"
                ApiConnectionState.ERROR -> "ERROR"
                ApiConnectionState.NOT_CONFIGURED -> "NO KEY"
              },
            dotColor = dotColor,
          )
        }
      }

      Row {
        IconButton(
          onClick = { showPromptLibrary = true },
          modifier = Modifier.testTag("ai_prompt_library_btn"),
        ) {
          Icon(Icons.Filled.Bookmarks, contentDescription = "Prompt Library")
        }
        IconButton(
          onClick = { showHistorySheet = true },
          modifier = Modifier.testTag("ai_history_btn"),
        ) {
          Icon(Icons.Filled.History, contentDescription = "Conversation History")
        }
        IconButton(
          onClick = { viewModel.startNewConversation() },
          modifier = Modifier.testTag("ai_new_session_btn"),
        ) {
          Icon(Icons.Filled.AddComment, contentDescription = "New Session")
        }
      }
    }

    // 10 AI Mode Selector
    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.padding(vertical = 6.dp),
    ) {
      items(AiStudioMode.entries) { mode ->
        val selected = mode == uiState.selectedMode
        FilterChip(
          selected = selected,
          onClick = { viewModel.selectMode(mode) },
          label = { Text(mode.shortLabel) },
          colors =
            FilterChipDefaults.filterChipColors(
              selectedContainerColor = VioletNeon.copy(alpha = 0.25f),
              selectedLabelColor = MaterialTheme.colorScheme.onSurface,
            ),
          modifier = Modifier.testTag("ai_mode_${mode.key}"),
        )
      }
    }

    // API Key Missing / Error Notice Banner
    if (!uiState.preferences.hasGeminiKey || uiState.preferences.apiConnectionState == ApiConnectionState.ERROR) {
      GlassCard(
        contentPadding = PaddingValues(12.dp),
        modifier = Modifier.padding(bottom = 8.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Icon(
              imageVector = if (!uiState.preferences.hasGeminiKey) Icons.Filled.Key else Icons.Filled.ErrorOutline,
              contentDescription = null,
              tint = if (!uiState.preferences.hasGeminiKey) studio.warning else studio.error,
              modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text =
                if (!uiState.preferences.hasGeminiKey) {
                  "Configure your Gemini API key (stored encrypted in Android Keystore) to run live requests."
                } else {
                  uiState.preferences.lastConnectionMessage
                },
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurface,
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Button(
            onClick = { showKeyConfigDialog = true },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.height(48.dp).testTag("ai_configure_key_btn"),
          ) {
            Text(if (!uiState.preferences.hasGeminiKey) "Set Key" else "Fix Key")
          }
        }
      }
    }

    // Snackbar / status notice
    if (!uiState.snackbarMessage.isNullOrBlank()) {
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.secondaryContainer,
        modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = uiState.snackbarMessage.orEmpty(),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSecondaryContainer,
            modifier = Modifier.weight(1f),
          )
          TextButton(onClick = { viewModel.clearSnackbar() }) { Text("OK") }
        }
      }
    }

    // Conversation Feed
    LazyColumn(
      state = listState,
      modifier = Modifier.weight(1f).fillMaxWidth(),
      verticalArrangement = Arrangement.spacedBy(10.dp),
      contentPadding = PaddingValues(vertical = 6.dp),
    ) {
      if (uiState.messages.isEmpty()) {
        item {
          GlassCard {
            Text(
              text = uiState.selectedMode.title,
              style = MaterialTheme.typography.titleMedium,
              color = MaterialTheme.colorScheme.primary,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text =
                "Powered by the official Gemini API (${uiState.preferences.selectedModel.displayName}). Responses are never simulated—you can attach a file from '${uiState.activeProject?.name ?: "Workspace"}', inspect token usage, and save generated code directly into your project.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedButton(
              onClick = { showPromptLibrary = true },
              modifier = Modifier.height(48.dp),
            ) {
              Icon(Icons.Filled.Bookmarks, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Browse Prompt Library")
            }
          }
        }
      } else {
        items(uiState.messages, key = { it.id }) { msg ->
          AiChatBubble(
            message = msg,
            onCopyCode = { code ->
              clipboard.setText(AnnotatedString(code))
            },
            onSaveCode = { lang, code ->
              val defaultExt =
                when (lang.lowercase()) {
                  "xml" -> "generated_layout.xml"
                  "json" -> "generated_config.json"
                  else -> "GeneratedComponent.kt"
                }
              saveCodeDialog = defaultExt to code
            },
          )
        }
      }

      if (uiState.isSending) {
        item {
          GlassCard(contentPadding = PaddingValues(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = "Calling ${uiState.preferences.selectedModel.displayName}...",
                style = MaterialTheme.typography.bodySmall,
              )
            }
          }
        }
      }
    }

    // Active Attachment Chip + Prompt Composer
    val attachedFile = uiState.projectFiles.find { it.id == uiState.attachedFileId }
    Row(
      modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      AssistChip(
        onClick = { showAttachSheet = true },
        label = {
          Text(
            text = attachedFile?.name ?: "Attach File",
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        },
        leadingIcon = {
          Icon(Icons.Filled.AttachFile, contentDescription = null, modifier = Modifier.size(16.dp))
        },
      )
      if (promptInput.isNotBlank()) {
        AssistChip(
          onClick = { savePromptDialog = true },
          label = { Text("Save Prompt") },
          leadingIcon = {
            Icon(Icons.Filled.BookmarkAdd, contentDescription = null, modifier = Modifier.size(16.dp))
          },
        )
      }
    }

    Row(
      modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
      verticalAlignment = Alignment.Bottom,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      OutlinedTextField(
        value = promptInput,
        onValueChange = { promptInput = it },
        placeholder = { Text(stringResource(R.string.ai_prompt_hint), maxLines = 2) },
        maxLines = 4,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.weight(1f).testTag("ai_prompt_input"),
      )
      Surface(
        onClick = {
          val textToSend = promptInput
          if (textToSend.isNotBlank() && !uiState.isSending) {
            promptInput = ""
            viewModel.sendPrompt(textToSend)
          }
        },
        shape = RoundedCornerShape(16.dp),
        color = Color.Transparent,
        modifier =
          Modifier
            .size(54.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.linearGradient(listOf(VioletNeon, ElectricBlue)))
            .testTag("ai_send_btn"),
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.Send,
            contentDescription = "Send prompt to Gemini",
            tint = Color.White,
          )
        }
      }
    }
  }

  // Configure & Test Key Dialog
  if (showKeyConfigDialog) {
    GeminiKeyQuickConfigDialog(
      currentMasked = uiState.preferences.maskedGeminiKey,
      isTesting = uiState.isTestingConnection,
      testMessage = uiState.connectionTestResult?.message,
      onDismiss = { showKeyConfigDialog = false },
      onSaveAndTest = { key -> viewModel.saveApiKeyAndTest(key) },
    )
  }

  // Prompt Library Sheet
  if (showPromptLibrary) {
    ModalBottomSheet(onDismissRequest = { showPromptLibrary = false }) {
      LazyColumn(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 28.dp),
      ) {
        item {
          Text(stringResource(R.string.prompt_library), style = MaterialTheme.typography.headlineSmall)
          Text(
            "Tap any prompt template to load it into the composer",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        items(ProjectTemplates.builtInPrompts) { preset ->
          GlassCard(
            onClick = {
              AiStudioMode.entries.find { it.key == preset.modeKey }?.let { viewModel.selectMode(it) }
              promptInput = preset.prompt
              showPromptLibrary = false
            }
          ) {
            StatusPill(text = preset.category, dotColor = ElectricBlue)
            Spacer(modifier = Modifier.height(6.dp))
            Text(preset.title, style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              preset.prompt,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              maxLines = 2,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
        if (uiState.customPrompts.isNotEmpty()) {
          item { Text("Saved Custom Prompts", style = MaterialTheme.typography.titleMedium) }
          items(uiState.customPrompts, key = { it.id }) { custom ->
            GlassCard(
              onClick = {
                AiStudioMode.entries.find { it.key == custom.modeKey }?.let { viewModel.selectMode(it) }
                promptInput = custom.promptText
                showPromptLibrary = false
              }
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Text(custom.title, style = MaterialTheme.typography.titleSmall)
                IconButton(onClick = { viewModel.deleteCustomPrompt(custom.id) }) {
                  Icon(Icons.Filled.Delete, contentDescription = "Delete prompt", tint = studio.error)
                }
              }
              Text(
                custom.promptText,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }
      }
    }
  }

  // Conversation History Sheet
  if (showHistorySheet) {
    ModalBottomSheet(onDismissRequest = { showHistorySheet = false }) {
      LazyColumn(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 28.dp),
      ) {
        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text("Conversation History", style = MaterialTheme.typography.headlineSmall)
            Button(
              onClick = {
                viewModel.startNewConversation()
                showHistorySheet = false
              }
            ) {
              Text("New Session")
            }
          }
        }
        if (uiState.conversations.isEmpty()) {
          item {
            Text(
              "No saved conversations yet.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        } else {
          items(uiState.conversations, key = { it.id }) { conv ->
            GlassCard(
              onClick = {
                viewModel.selectConversation(conv.id)
                showHistorySheet = false
              }
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    conv.title,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                  Text(
                    "${conv.modeKey} • ${conv.modelId}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary,
                  )
                }
                IconButton(onClick = { viewModel.deleteConversation(conv.id) }) {
                  Icon(Icons.Filled.Delete, contentDescription = "Delete session", tint = studio.error)
                }
              }
            }
          }
        }
      }
    }
  }

  // Attach Project File Sheet
  if (showAttachSheet) {
    ModalBottomSheet(onDismissRequest = { showAttachSheet = false }) {
      LazyColumn(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(bottom = 28.dp),
      ) {
        item {
          Text(
            "Attach File from ${uiState.activeProject?.name ?: "Workspace"}",
            style = MaterialTheme.typography.headlineSmall,
          )
          Text(
            "Selected file content is included as context in your next Gemini query.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        items(uiState.projectFiles, key = { it.id }) { file ->
          val selected = file.id == uiState.attachedFileId
          GlassCard(
            onClick = {
              viewModel.selectAttachedFile(file.id)
              showAttachSheet = false
            }
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column {
                Text(file.name, style = MaterialTheme.typography.titleSmall)
                Text(
                  "${file.relativePath} • ${file.content.lines().size} lines",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
              if (selected) StatusPill("ATTACHED", studio.success)
            }
          }
        }
      }
    }
  }

  // Save Code Block Dialog
  saveCodeDialog?.let { (suggestedName, code) ->
    var fileName by remember(suggestedName) { mutableStateOf(suggestedName) }
    AlertDialog(
      onDismissRequest = { saveCodeDialog = null },
      title = { Text("Save Generated Code to Project") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            "Target project: ${uiState.activeProject?.name ?: "None"}",
            style = MaterialTheme.typography.bodySmall,
          )
          OutlinedTextField(
            value = fileName,
            onValueChange = { fileName = it },
            label = { Text("File Name (e.g. CustomCard.kt)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.saveCodeSnippetToActiveProject(fileName, code)
            saveCodeDialog = null
          },
          enabled = fileName.isNotBlank(),
        ) {
          Text("Save File")
        }
      },
      dismissButton = {
        TextButton(onClick = { saveCodeDialog = null }) { Text("Cancel") }
      },
    )
  }

  if (savePromptDialog) {
    var title by remember { mutableStateOf("") }
    AlertDialog(
      onDismissRequest = { savePromptDialog = false },
      title = { Text("Save to Prompt Library") },
      text = {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Prompt Title") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.saveCustomPrompt(title, promptInput)
            savePromptDialog = false
          },
          enabled = title.isNotBlank(),
        ) {
          Text("Save")
        }
      },
      dismissButton = {
        TextButton(onClick = { savePromptDialog = false }) { Text("Cancel") }
      },
    )
  }
}

@Composable
private fun AiChatBubble(
  message: AiMessageEntity,
  onCopyCode: (String) -> Unit,
  onSaveCode: (String, String) -> Unit,
) {
  val studio = LocalStudioColors.current
  val isUser = message.role == "user"
  val isError = message.role == "error"

  val containerColor =
    when {
      isUser -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f)
      isError -> studio.error.copy(alpha = 0.14f)
      else -> studio.glassFill
    }
  val borderColor =
    when {
      isUser -> VioletNeon.copy(alpha = 0.45f)
      isError -> studio.error.copy(alpha = 0.55f)
      else -> studio.glassBorderEnd
    }

  Surface(
    shape = RoundedCornerShape(20.dp),
    color = containerColor,
    border = BorderStroke(1.dp, borderColor),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text =
            when {
              isUser -> "YOU • ${message.modeKey}"
              isError -> "GEMINI API ERROR"
              else -> "GEMINI • ${message.modelId}"
            },
          style = MaterialTheme.typography.labelSmall,
          color =
            when {
              isError -> studio.error
              isUser -> MaterialTheme.colorScheme.primary
              else -> ElectricBlue
            },
        )
        if (!isUser && message.latencyMs > 0L) {
          Text(
            text = "${message.tokenCount} tok • ${message.latencyMs}ms",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }

      val segments = remember(message.content) { parseMessageSegments(message.content) }
      segments.forEach { segment ->
        when (segment) {
          is MessageSegment.MarkdownText -> {
            Text(
              text = segment.text,
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurface,
            )
          }
          is MessageSegment.CodeBlock -> {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                StatusPill(text = segment.language.uppercase(), dotColor = ElectricBlue)
                Row {
                  TextButton(onClick = { onCopyCode(segment.code) }) {
                    Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Copy")
                  }
                  TextButton(onClick = { onSaveCode(segment.language, segment.code) }) {
                    Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Save")
                  }
                }
              }
              CodeDisplayBox(code = segment.code, fileType = segment.language)
            }
          }
        }
      }
    }
  }
}

@Composable
fun GeminiKeyQuickConfigDialog(
  currentMasked: String,
  isTesting: Boolean,
  testMessage: String?,
  onDismiss: () -> Unit,
  onSaveAndTest: (String) -> Unit,
) {
  var apiKeyInput by remember { mutableStateOf("") }
  var showPlain by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Configure Gemini API Key") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text =
            "Your key is encrypted locally using Android Keystore (AES-256-GCM) and never hardcoded.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (currentMasked.isNotBlank()) {
          StatusPill(text = "Stored: $currentMasked", dotColor = ElectricBlue)
        }
        OutlinedTextField(
          value = apiKeyInput,
          onValueChange = { apiKeyInput = it },
          label = { Text("Gemini API Key") },
          placeholder = { Text("AIza...") },
          singleLine = true,
          visualTransformation =
            if (showPlain) VisualTransformation.None else PasswordVisualTransformation(),
          trailingIcon = {
            IconButton(onClick = { showPlain = !showPlain }) {
              Icon(
                imageVector = if (showPlain) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                contentDescription = "Toggle key visibility",
              )
            }
          },
          modifier = Modifier.fillMaxWidth().testTag("gemini_key_dialog_input"),
        )
        if (isTesting) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Encrypting & testing Gemini connection...", style = MaterialTheme.typography.bodySmall)
          }
        } else if (!testMessage.isNullOrBlank()) {
          Text(
            text = testMessage,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.secondary,
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = { onSaveAndTest(apiKeyInput) },
        enabled = apiKeyInput.isNotBlank() && !isTesting,
        modifier = Modifier.testTag("gemini_key_save_test_btn"),
      ) {
        Text("Save & Test")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Close") }
    },
  )
}
