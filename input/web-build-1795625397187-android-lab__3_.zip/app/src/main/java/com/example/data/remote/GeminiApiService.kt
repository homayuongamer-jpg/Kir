package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

@JsonClass(generateAdapter = true)
data class GeminiPartDto(
  val text: String? = null,
)

@JsonClass(generateAdapter = true)
data class GeminiContentDto(
  val role: String? = null,
  val parts: List<GeminiPartDto> = emptyList(),
)

@JsonClass(generateAdapter = true)
data class GenerationConfigDto(
  val temperature: Double = 0.4,
  val topP: Double = 0.95,
  val maxOutputTokens: Int = 4096,
)

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(
  @Json(name = "system_instruction") val systemInstruction: GeminiContentDto? = null,
  val contents: List<GeminiContentDto>,
  val generationConfig: GenerationConfigDto = GenerationConfigDto(),
)

@JsonClass(generateAdapter = true)
data class GeminiCandidateDto(
  val content: GeminiContentDto? = null,
  val finishReason: String? = null,
)

@JsonClass(generateAdapter = true)
data class GeminiUsageMetadataDto(
  val promptTokenCount: Int? = null,
  val candidatesTokenCount: Int? = null,
  val totalTokenCount: Int? = null,
)

@JsonClass(generateAdapter = true)
data class GeminiPromptFeedbackDto(
  val blockReason: String? = null,
)

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(
  val candidates: List<GeminiCandidateDto>? = null,
  val usageMetadata: GeminiUsageMetadataDto? = null,
  val promptFeedback: GeminiPromptFeedbackDto? = null,
)

@JsonClass(generateAdapter = true)
data class GeminiModelInfoDto(
  val name: String? = null,
  val displayName: String? = null,
  val supportedGenerationMethods: List<String>? = null,
)

@JsonClass(generateAdapter = true)
data class ModelsListResponse(
  val models: List<GeminiModelInfoDto>? = null,
)

@JsonClass(generateAdapter = true)
data class GeminiErrorDetailDto(
  val code: Int? = null,
  val message: String? = null,
  val status: String? = null,
)

@JsonClass(generateAdapter = true)
data class GeminiErrorEnvelopeDto(
  val error: GeminiErrorDetailDto? = null,
)

interface GeminiApiService {
  @GET("v1beta/models")
  suspend fun listModels(
    @Query("key") apiKey: String,
    @Query("pageSize") pageSize: Int = 20,
  ): Response<ModelsListResponse>

  @POST("v1beta/models/{model}:generateContent")
  suspend fun generateContent(
    @Path("model") model: String,
    @Query("key") apiKey: String,
    @Body request: GenerateContentRequest,
  ): Response<GenerateContentResponse>
}
