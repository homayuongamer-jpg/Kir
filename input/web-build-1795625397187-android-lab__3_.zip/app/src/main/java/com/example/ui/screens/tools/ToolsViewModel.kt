package com.example.ui.screens.tools

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.analyzer.ProjectStaticAnalyzer
import com.example.core.analyzer.StaticAnalysisReport
import com.example.core.preferences.StudioPreferences
import com.example.core.preferences.StudioPreferencesRepository
import com.example.data.local.DiagnosticLogEntity
import com.example.data.local.ProjectEntity
import com.example.data.local.ProjectFileEntity
import com.example.data.repository.DiagnosticsRepository
import com.example.data.repository.ProjectRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ToolkitTab(val label: String) {
  FILES("Files"),
  EDITOR("Editor"),
  SNIPPETS("Snippets"),
  LOGS("Logs"),
  BUILD_ERRORS("Checks & Errors"),
}

data class ToolsUiState(
  val projects: List<ProjectEntity> = emptyList(),
  val activeProject: ProjectEntity? = null,
  val projectFiles: List<ProjectFileEntity> = emptyList(),
  val selectedFile: ProjectFileEntity? = null,
  val editorDraft: String = "",
  val hasUnsavedChanges: Boolean = false,
  val isPreviewMode: Boolean = false,
  val selectedTab: ToolkitTab = ToolkitTab.EDITOR,
  val analysisReport: StaticAnalysisReport? = null,
  val diagnosticLogs: List<DiagnosticLogEntity> = emptyList(),
  val statusMessage: String? = null,
)

class ToolsViewModel(
  private val projectRepository: ProjectRepository,
  private val preferencesRepository: StudioPreferencesRepository,
  private val diagnosticsRepository: DiagnosticsRepository,
) : ViewModel() {

  private val selectedFileId = MutableStateFlow<Long?>(null)
  private val editorDraft = MutableStateFlow("")
  private val hasUnsavedChanges = MutableStateFlow(false)
  private val isPreviewMode = MutableStateFlow(false)
  private val selectedTab = MutableStateFlow(ToolkitTab.EDITOR)
  private val analysisReport = MutableStateFlow<StaticAnalysisReport?>(null)
  private val statusMessage = MutableStateFlow<String?>(null)

  @OptIn(ExperimentalCoroutinesApi::class)
  private val activeProjectFlow =
    preferencesRepository.preferencesFlow.flatMapLatest { prefs ->
      projectRepository.observeProject(prefs.activeProjectId)
    }

  @OptIn(ExperimentalCoroutinesApi::class)
  private val activeFilesFlow =
    preferencesRepository.preferencesFlow.flatMapLatest { prefs ->
      projectRepository.observeProjectFiles(prefs.activeProjectId)
    }

  val uiState: StateFlow<ToolsUiState> =
    combine(
        projectRepository.allProjects,
        activeProjectFlow,
        activeFilesFlow,
        selectedFileId,
        editorDraft,
        hasUnsavedChanges,
        isPreviewMode,
        selectedTab,
        analysisReport,
        diagnosticsRepository.diagnosticLogs,
        statusMessage,
      ) { values ->
        @Suppress("UNCHECKED_CAST")
        val projects = values[0] as List<ProjectEntity>
        val activeProj = values[1] as ProjectEntity?
        @Suppress("UNCHECKED_CAST")
        val files = values[2] as List<ProjectFileEntity>
        val selFileId = values[3] as Long?
        val draft = values[4] as String
        val dirty = values[5] as Boolean
        val preview = values[6] as Boolean
        val tab = values[7] as ToolkitTab
        val report = values[8] as StaticAnalysisReport?
        @Suppress("UNCHECKED_CAST")
        val logs = values[9] as List<DiagnosticLogEntity>
        val status = values[10] as String?

        val resolvedFile = files.find { it.id == selFileId } ?: files.firstOrNull()
        val effectiveDraft =
          if (selFileId == null || files.none { it.id == selFileId }) {
            resolvedFile?.content.orEmpty()
          } else {
            draft
          }

        ToolsUiState(
          projects = projects,
          activeProject = activeProj,
          projectFiles = files,
          selectedFile = resolvedFile,
          editorDraft = effectiveDraft,
          hasUnsavedChanges = dirty,
          isPreviewMode = preview,
          selectedTab = tab,
          analysisReport = report,
          diagnosticLogs = logs,
          statusMessage = status,
        )
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = ToolsUiState(),
      )

  fun selectTab(tab: ToolkitTab) {
    selectedTab.value = tab
  }

  fun switchProject(projectId: Long) {
    viewModelScope.launch {
      selectedFileId.value = null
      hasUnsavedChanges.value = false
      projectRepository.openProject(projectId)
      runStaticAnalysisFor(projectId)
    }
  }

  fun openFile(file: ProjectFileEntity, switchToEditor: Boolean = true) {
    selectedFileId.value = file.id
    editorDraft.value = file.content
    hasUnsavedChanges.value = false
    if (switchToEditor) selectedTab.value = ToolkitTab.EDITOR
  }

  fun updateDraft(newText: String) {
    if (selectedFileId.value == null) {
      uiState.value.selectedFile?.let { selectedFileId.value = it.id }
    }
    editorDraft.value = newText
    hasUnsavedChanges.value = true
  }

  fun togglePreviewMode() {
    isPreviewMode.value = !isPreviewMode.value
  }

  fun saveActiveFile() {
    val file = uiState.value.selectedFile ?: return
    val textToSave = editorDraft.value
    viewModelScope.launch {
      projectRepository.saveFileContent(file, textToSave)
      hasUnsavedChanges.value = false
      statusMessage.value = "Saved ${file.name}"
      diagnosticsRepository.logDiagnostic("INFO", "Editor", "Saved ${file.name}")
      runStaticAnalysis()
    }
  }

  fun createNewFile(fileName: String, fileType: String) {
    val proj = uiState.value.activeProject ?: return
    val cleanName = fileName.trim()
    if (cleanName.isEmpty()) return
    val starter =
      when (fileType) {
        "xml" -> "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n</resources>"
        "json" -> "{\n  \"name\": \"$cleanName\"\n}"
        "gradle" -> "dependencies {\n}"
        else -> "package ${proj.packageName}\n\nclass ${cleanName.substringBefore('.')} {\n}"
      }
    viewModelScope.launch {
      val id =
        projectRepository.createOrUpdateFile(
          projectId = proj.id,
          fileName = cleanName,
          relativePath = cleanName,
          fileType = fileType,
          content = starter,
        )
      selectedFileId.value = id
      editorDraft.value = starter
      hasUnsavedChanges.value = false
      selectedTab.value = ToolkitTab.EDITOR
      statusMessage.value = "Created $cleanName"
    }
  }

  fun deleteFile(file: ProjectFileEntity) {
    viewModelScope.launch {
      projectRepository.deleteFile(file)
      if (selectedFileId.value == file.id) {
        selectedFileId.value = null
        hasUnsavedChanges.value = false
      }
      statusMessage.value = "Deleted ${file.name}"
    }
  }

  fun formatCurrentJson(minify: Boolean) {
    val currentText = editorDraft.value
    val result =
      if (minify) {
        ProjectStaticAnalyzer.minifyJson(currentText)
      } else {
        ProjectStaticAnalyzer.formatJson(currentText, indentSpaces = 2)
      }
    result
      .onSuccess { formatted ->
        updateDraft(formatted)
        statusMessage.value = if (minify) "JSON minified." else "JSON formatted."
      }
      .onFailure { err -> statusMessage.value = "Invalid JSON: ${err.message}" }
  }

  fun validateCurrentXml() {
    val file = uiState.value.selectedFile ?: return
    val tempFile = file.copy(content = editorDraft.value)
    val issues = ProjectStaticAnalyzer.analyzeXml(tempFile)
    if (issues.isEmpty()) {
      statusMessage.value = "XML is well-formed (XmlPullParser check passed)."
    } else {
      val first = issues.first()
      statusMessage.value = "XML line ${first.line}: ${first.message}"
    }
  }

  fun insertSnippetIntoEditor(snippetCode: String) {
    val current = editorDraft.value
    val updated =
      if (current.isBlank()) snippetCode else "$current\n\n$snippetCode"
    updateDraft(updated)
    selectedTab.value = ToolkitTab.EDITOR
    statusMessage.value = "Inserted snippet into active file."
  }

  fun runStaticAnalysis() {
    val proj = uiState.value.activeProject ?: return
    runStaticAnalysisFor(proj.id)
  }

  private fun runStaticAnalysisFor(projectId: Long) {
    viewModelScope.launch {
      val proj = uiState.value.projects.find { it.id == projectId } ?: return@launch
      val files = projectRepository.getProjectFiles(projectId).map { f ->
        if (f.id == uiState.value.selectedFile?.id && hasUnsavedChanges.value) {
          f.copy(content = editorDraft.value)
        } else {
          f
        }
      }
      val report = ProjectStaticAnalyzer.analyzeProject(proj.name, files)
      analysisReport.value = report
      diagnosticsRepository.logDiagnostic(
        level = if (report.errorCount > 0) "ERROR" else if (report.warningCount > 0) "WARN" else "INFO",
        tag = "StaticCheck",
        message = report.summary,
      )
    }
  }

  fun clearDiagnosticLogs() {
    viewModelScope.launch { diagnosticsRepository.clearDiagnostics() }
  }

  fun clearStatus() {
    statusMessage.value = null
  }
}
