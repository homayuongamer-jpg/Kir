package com.example.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.preferences.StudioPreferences
import com.example.core.preferences.StudioPreferencesRepository
import com.example.core.security.KeystoreCryptoManager
import com.example.core.templates.ProjectTemplateType
import com.example.data.local.ActivityLogEntity
import com.example.data.local.ProjectEntity
import com.example.data.repository.AiStudioRepository
import com.example.data.repository.DiagnosticsRepository
import com.example.data.repository.ProjectRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeUiState(
  val preferences: StudioPreferences = StudioPreferences(),
  val recentProjects: List<ProjectEntity> = emptyList(),
  val projectCount: Int = 0,
  val totalFiles: Int = 0,
  val totalAiPrompts: Int = 0,
  val recentActivities: List<ActivityLogEntity> = emptyList(),
  val keystoreReady: Boolean = true,
)

class HomeViewModel(
  private val projectRepository: ProjectRepository,
  private val aiStudioRepository: AiStudioRepository,
  private val diagnosticsRepository: DiagnosticsRepository,
  private val preferencesRepository: StudioPreferencesRepository,
  cryptoManager: KeystoreCryptoManager,
) : ViewModel() {

  private val keystoreReady = cryptoManager.isKeystoreAvailable()

  val uiState: StateFlow<HomeUiState> =
    combine(
        preferencesRepository.preferencesFlow,
        projectRepository.allProjects,
        projectRepository.projectCount,
        projectRepository.totalFileCount,
        aiStudioRepository.totalPromptCount,
        diagnosticsRepository.recentActivities,
      ) { values ->
        val prefs = values[0] as StudioPreferences
        @Suppress("UNCHECKED_CAST")
        val projects = values[1] as List<ProjectEntity>
        val projCount = values[2] as Int
        val fileCount = values[3] as Int
        val promptCount = values[4] as Int
        @Suppress("UNCHECKED_CAST")
        val activities = values[5] as List<ActivityLogEntity>

        HomeUiState(
          preferences = prefs,
          recentProjects = projects.take(4),
          projectCount = projCount,
          totalFiles = fileCount,
          totalAiPrompts = promptCount,
          recentActivities = activities.take(6),
          keystoreReady = keystoreReady,
        )
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = HomeUiState(keystoreReady = keystoreReady),
      )

  fun quickCreateProject(
    name: String,
    packageName: String,
    template: ProjectTemplateType,
    onCreated: (Long) -> Unit,
  ) {
    viewModelScope.launch {
      val id =
        projectRepository.createProjectFromTemplate(
          name = name,
          packageName = packageName,
          description = "Quick-created from Home Dashboard",
          template = template,
        )
      onCreated(id)
    }
  }

  fun openProject(projectId: Long, onOpened: () -> Unit) {
    viewModelScope.launch {
      projectRepository.openProject(projectId)
      onOpened()
    }
  }
}
