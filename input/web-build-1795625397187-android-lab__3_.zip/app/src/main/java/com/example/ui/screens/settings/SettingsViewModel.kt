package com.example.ui.screens.settings

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.preferences.AppLanguage
import com.example.core.preferences.GeminiModelOption
import com.example.core.preferences.StudioPreferences
import com.example.core.preferences.StudioPreferencesRepository
import com.example.core.preferences.ThemeMode
import com.example.core.security.KeystoreCryptoManager
import com.example.data.repository.AiStudioRepository
import com.example.data.repository.ConnectionTestResult
import com.example.data.repository.DiagnosticsRepository
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class SettingsUiState(
  val preferences: StudioPreferences = StudioPreferences(),
  val keystoreReady: Boolean = true,
  val isTestingConnection: Boolean = false,
  val connectionTestResult: ConnectionTestResult? = null,
  val cacheSizeLabel: String = "0 KB",
  val statusMessage: String? = null,
)

class SettingsViewModel(
  private val appContext: Context,
  private val preferencesRepository: StudioPreferencesRepository,
  private val aiStudioRepository: AiStudioRepository,
  private val diagnosticsRepository: DiagnosticsRepository,
  cryptoManager: KeystoreCryptoManager,
) : ViewModel() {

  private val keystoreReady = cryptoManager.isKeystoreAvailable()
  private val isTestingConnection = MutableStateFlow(false)
  private val connectionTestResult = MutableStateFlow<ConnectionTestResult?>(null)
  private val cacheSizeLabel = MutableStateFlow("Calculating...")
  private val statusMessage = MutableStateFlow<String?>(null)

  val uiState: StateFlow<SettingsUiState> =
    combine(
        preferencesRepository.preferencesFlow,
        isTestingConnection,
        connectionTestResult,
        cacheSizeLabel,
        statusMessage,
      ) { prefs, testing, testRes, cacheLbl, status ->
        SettingsUiState(
          preferences = prefs,
          keystoreReady = keystoreReady,
          isTestingConnection = testing,
          connectionTestResult = testRes,
          cacheSizeLabel = cacheLbl,
          statusMessage = status,
        )
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SettingsUiState(keystoreReady = keystoreReady),
      )

  init {
    refreshCacheStats()
  }

  fun setThemeMode(mode: ThemeMode) {
    viewModelScope.launch { preferencesRepository.setThemeMode(mode) }
  }

  fun setLanguage(language: AppLanguage) {
    viewModelScope.launch {
      preferencesRepository.setLanguage(language)
      statusMessage.value = "Language set to ${language.displayName}."
    }
  }

  fun setModel(model: GeminiModelOption) {
    viewModelScope.launch { preferencesRepository.setSelectedModel(model) }
  }

  fun saveGeminiKey(rawKey: String) {
    viewModelScope.launch {
      preferencesRepository
        .saveGeminiApiKey(rawKey)
        .onSuccess { masked ->
          statusMessage.value = "Encrypted & saved key ($masked) in Android Keystore."
          diagnosticsRepository.logDiagnostic("INFO", "Security", "Saved encrypted Gemini API key")
        }
        .onFailure { err ->
          statusMessage.value = "Key error: ${err.message}"
        }
    }
  }

  fun clearGeminiKey() {
    viewModelScope.launch {
      preferencesRepository.clearGeminiApiKey()
      connectionTestResult.value = null
      statusMessage.value = "Gemini API key removed from Keystore storage."
    }
  }

  fun testConnection() {
    viewModelScope.launch {
      isTestingConnection.value = true
      val res = aiStudioRepository.testGeminiConnection()
      connectionTestResult.value = res
      isTestingConnection.value = false
      statusMessage.value = res.message
    }
  }

  fun setAttachActiveFileContext(enabled: Boolean) {
    viewModelScope.launch { preferencesRepository.setAttachActiveFileContext(enabled) }
  }

  fun setRedactSecrets(enabled: Boolean) {
    viewModelScope.launch { preferencesRepository.setRedactSecretsBeforeSend(enabled) }
  }

  fun setLogAiMetadata(enabled: Boolean) {
    viewModelScope.launch { preferencesRepository.setLogAiMetadataLocally(enabled) }
  }

  fun clearTempCache() {
    viewModelScope.launch {
      withContext(Dispatchers.IO) {
        appContext.cacheDir?.deleteRecursively()
        appContext.cacheDir?.mkdirs()
      }
      refreshCacheStats()
      statusMessage.value = "Temporary cache cleared."
    }
  }

  fun clearConversationHistory() {
    viewModelScope.launch {
      aiStudioRepository.clearAllConversations()
      refreshCacheStats()
      statusMessage.value = "AI Studio conversation history cleared."
    }
  }

  fun clearDiagnosticLogs() {
    viewModelScope.launch {
      diagnosticsRepository.clearDiagnostics()
      diagnosticsRepository.clearActivities()
      refreshCacheStats()
      statusMessage.value = "Diagnostic & activity logs cleared."
    }
  }

  fun clearStatus() {
    statusMessage.value = null
  }

  fun refreshCacheStats() {
    viewModelScope.launch {
      val bytes =
        withContext(Dispatchers.IO) {
          val cacheBytes = dirSize(appContext.cacheDir)
          val dbFile = appContext.getDatabasePath("android_lab_studio_v2.db")
          val dbBytes = if (dbFile.exists()) dbFile.length() else 0L
          cacheBytes + dbBytes
        }
      cacheSizeLabel.value =
        when {
          bytes >= 1024 * 1024 -> String.format("%.2f MB", bytes / (1024f * 1024f))
          bytes >= 1024 -> "${bytes / 1024} KB"
          else -> "$bytes B"
        }
    }
  }

  private fun dirSize(dir: File?): Long {
    if (dir == null || !dir.exists()) return 0L
    var total = 0L
    dir.listFiles()?.forEach { f ->
      total += if (f.isDirectory) dirSize(f) else f.length()
    }
    return total
  }
}
